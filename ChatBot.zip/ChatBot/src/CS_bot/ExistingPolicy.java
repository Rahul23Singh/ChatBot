package CS_bot;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import screenshot.ScreenShot;

public class ExistingPolicy {
	WebDriver driver;
	String name = "Abcd";

	// PreCondition starts here
	@BeforeClass
	public void PreConditions() throws IOException {
			System.setProperty("webdriver.chrome.driver", "D:\\Eclipse\\ChatBot\\All exe\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get("https://max-chat-bot.herokuapp.com/cs");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			ScreenShot.getPassedScreenShot(driver, "PreConditions");
	}
	@Test
	public void existingProduct() throws IOException, InterruptedException{
		try{
			WebElement existingPolicy = driver.findElement(By.xpath("//span[text()='Existing Policy']"));
			if(existingPolicy.isDisplayed()==true)
			{
				existingPolicy.click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				boolean happyToHelpYou = driver.findElement(By.xpath("//p[contains(text(),'m happy to help you with the following options.')]")).isDisplayed();
				WebElement policyPack = driver.findElement(By.xpath("//span[text()='Policy Pack']"));
				policyPack.isDisplayed();
				Thread.sleep(1000);
				policyPack.click();
				WebElement recognized = driver.findElement(By.xpath("//p[contains(text(),'recognized you yet. Let me know your policy number so that i can verify your identity.')]"));
				recognized.isDisplayed();
				driver.findElement(By.xpath("//input[@placeholder='Write here...']")).sendKeys("889490314");
				driver.findElement(By.xpath("//button[@type='submit']")).click();
				driver.findElement(By.xpath("//p[text()='OTP has been sent on your registered mobile number. Please enter it here to verify its your policy123456']"));
				driver.findElement(By.xpath("//input[@placeholder='Write here...']")).sendKeys("123456");
				driver.findElement(By.xpath("//button[@type='submit']")).click();
				driver.findElement(By.xpath("//p[contains(text(),'Your request is under process. Policy document will be emailed within next 60 mins on your regi')]"));
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				WebElement yesElemenet = driver.findElement(By.xpath("//span[text()='Yes']"));
				Thread.sleep(1000);
				yesElemenet.click();
				WebElement helpOnPolicy = driver.findElement(By.xpath("//p[contains(text(),'m happy to help you with the following options.')]"));
				helpOnPolicy.isDisplayed();
				Thread.sleep(1000);
				WebElement existingPolicy1 = driver.findElement(By.xpath("//span[text()='Existing Policy']"));
				existingPolicy1.click();
				WebElement policyTerm = driver.findElement(By.xpath("//span[text()='Policy Term']"));
				policyTerm.isDisplayed();
				policyTerm.click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				WebElement maturity = driver.findElement(By.xpath("//p[contains(text(),'The maturity/expiry date of your policy  889490314 is  31-Jul-2049 and the term is  35 years.')]"));
				maturity.isDisplayed();
				System.out.println(maturity.getText());
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				WebElement noElement = driver.findElement(By.xpath("//span[text()='No']"));
				Thread.sleep(1000);
				noElement.click();
				WebElement feedback = driver.findElement(By.xpath("//span[text()='Helpful']"));
				feedback.isDisplayed();
				feedback.click(); 
	}}
		catch (Exception e) {
			// TODO: handle exception
		}
	
}
	@AfterClass
	public void postCondition() {
		driver.quit();
	}
}
