package CS_bot;

import java.io.IOException;
import java.time.chrono.ThaiBuddhistEra;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.remote.server.handler.GetAllWindowHandles;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import screenshot.ScreenShot;

public class NewProduct {
	WebDriver driver;
	String name = "Abcd";

	// PreCondition starts here
	@BeforeClass
	public void PreConditions() throws IOException {
			System.setProperty("webdriver.chrome.driver", "D:\\Eclipse\\ChatBot\\All exe\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get("https://max-chat-bot.herokuapp.com/cs");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	@Test
	public void newProducts() throws IOException, InterruptedException{
		try{
		WebElement helloMessage = driver.findElement(By.xpath("//p[text()='Hello I am Priyanka, your Max Life Assistant. Please select from the options below.']"));
		WebElement newMessage = driver.findElement(By.xpath("//span[text()='New Products']"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(helloMessage.isDisplayed()==true	&& newMessage.isDisplayed()==true){
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		newMessage.click();
		WebElement helpMeAssisst = driver.findElement(By.xpath("//p[text()='To help me assist you better, please choose your current life stage:']"));
		WebElement marriageWithYoungChildren = driver.findElement(By.xpath("//span[text()='Married with young  children']"));
		if(helpMeAssisst.isDisplayed()==true && marriageWithYoungChildren.isDisplayed()==true){
			Assert.assertTrue(true);
		}
		else{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		marriageWithYoungChildren.click();
		WebElement thankYouElement = driver.findElement(By.xpath("//p[starts-with(text(),'Thank you. I am sure your kids ')]"));
		if(thankYouElement.isDisplayed()==true){
			Assert.assertTrue(true);
		}
		else{
			Assert.assertTrue(false);
		}
		  List<WebElement> ListOfElements = driver.findElements(By.xpath("//ul[@class='buttonsList']//span"));
		  String storeElements[] = new String[ListOfElements.size()];
		  int size = ListOfElements.size();
		  if(size==4){
			  int i=0;
			  for(WebElement e: ListOfElements){
				  System.out.println(storeElements[i]=e.getText());
			  }
		  }
		  WebElement regularSaving = driver.findElement(By.xpath("//ul[@class='buttonsList']//span[text()='Regular Savings']"));
		  if(regularSaving.isDisplayed()==true){
			Assert.assertTrue(true, "Webelemwent is verified");
			Thread.sleep(1000);
			regularSaving.click();
		  }
		  else{
			  Assert.assertTrue(false);
		  }
		  WebElement specificGoal = driver.findElement(By.xpath("//p[contains(text(),'what I have to meet your specific goal:')]"));
		  if(specificGoal.isDisplayed()==true){
			  Assert.assertTrue(true, "Webelement is displayed and verified");
		  }
		  else{
			  Assert.assertTrue(false);
		  }
		  List<WebElement> suggestedPlan = driver.findElements(By.xpath("//ul[@class='buttonsList']//span"));
		  String suggestedPlans[] = new String[suggestedPlan.size()];
		  int size1 = suggestedPlan.size();
		  if(size1==4){
			  int j=0;
			  for(WebElement e: suggestedPlan){
				  System.out.println(suggestedPlans[j]=e.getText());
			  }
		  }
		  WebElement maxLifeOnline = driver.findElement(By.xpath("//ul[@class='buttonsList']//span[text()='Max Life Online Savings Plan']"));
		  Thread.sleep(1000);
		  maxLifeOnline.click();
		  WebElement greatChoice = driver.findElement(By.xpath("//p[contains(text(),'a great choice!')]"));
		  if(greatChoice.isDisplayed()==true){
			 Assert.assertTrue(true);
		  }
		  else{
			  Assert.assertTrue(false);
		  }
		  List<WebElement> KnowMoreAndBuyNow = driver.findElements(By.xpath("//ul[@class='buttonsList']//span"));
		  int size2 = KnowMoreAndBuyNow.size();
		  String storeElement1[] = new String[size2]; 
		  if(size2==2){
			  int a=0;
			  for(WebElement e: KnowMoreAndBuyNow){
				  System.out.println(storeElement1[a]=e.getText());
			  }
		  }
		  WebElement buyNow = driver.findElement(By.xpath("//ul[@class='buttonsList']//span[text()='Buy Now']"));
		  if(buyNow.isDisplayed()==true){
			  Assert.assertTrue(true);
		  }
		  else{
			  Assert.assertTrue(false);
		  }
		  Thread.sleep(1000);
		  buyNow.click();
		  ArrayList<String> handleWindow = new ArrayList<String>(driver.getWindowHandles());
		  driver.switchTo().window(handleWindow.get(1));
		  String newWindowURL = driver.getCurrentUrl();
		  System.out.println(newWindowURL);
		  String expectedURL = "https://www.maxlifeinsurance.com/ulip-saving-plan/savings-plan-calculator";
		  
		  Assert.assertEquals(newWindowURL, expectedURL, "Both URL are not same");
		  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		  driver.switchTo().window(handleWindow.get(0));
		  WebElement thankYouForChooseingMax = driver.findElement(By.xpath("//p[text()='Thank you for choosing Max Life Insurance. Is there anything else I can assist you with?']"));
		  if(thankYouForChooseingMax.isDisplayed()==true){
			  Assert.assertTrue(true);
		  }
		  else{
			  Assert.assertTrue(false);
		  }
		  WebElement noElement = driver.findElement(By.xpath("//span[text()='No']"));
		  WebElement thankYouElement1 = driver.findElement(By.xpath("//p[text()='Thank you for choosing Max Life Insurance. Is there anything else I can assist you with?']"));
		  if(noElement.isDisplayed()==true && thankYouElement1.isDisplayed()==true){
			  Assert.assertTrue(true);
		  }
		  else{
			  Assert.assertTrue(false);
		  }
		  Thread.sleep(1000);
		  noElement.click();
		  WebElement helpfulToday = driver.findElement(By.xpath("//p[text()='Please let me know how helpful I was today?']"));
		  if(helpfulToday.isDisplayed()==true){
			  Assert.assertTrue(true);
		  }
		  else{
			  Assert.assertTrue(false);
		  }
		  WebElement isDisplayed = driver.findElement(By.xpath("//span[text()='Helpful']"));
		  Thread.sleep(1000);
		  isDisplayed.click();
	}
	catch (Exception e) {
		// TODO: handle exception
	}	
	}

		
	@AfterClass
	public void postCondition() {
		driver.quit();
	}	
	
	
}
