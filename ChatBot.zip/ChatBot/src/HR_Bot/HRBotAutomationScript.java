package HR_Bot;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import javax.lang.model.element.Element;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class HRBotAutomationScript {

	public WebDriver driver;

	// heroku
	// URL:https://max-bot-hr.herokuapp.com/empapp?key1=authorize_eapp_001&key2=pmhom3698&key3=IOS&key4=eapp;
	@BeforeClass
	public void PreCondition() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\Eclipse\\ChatBot\\All exe\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.navigate().to(
				"https://botuat.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=pmhom3698&key3=IOS&key4=eapp");
		driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@Test(priority = 1)
	public void childHealthCarePolicy() throws InterruptedException {

		WebElement HiPriyankaDefaultMessage = driver.findElement(By.xpath("//p[text()='Hi Priyanka']"));
		WebElement howCanIHelp = driver
				.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (HiPriyankaDefaultMessage.isDisplayed() == true && howCanIHelp.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		WebElement checkHRPolicies = driver.findElement(By.xpath("//a[contains(text(),'HR Policies')]"));
		if (checkHRPolicies.isDisplayed()) {
			checkHRPolicies.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement HRPolicyDefaultMessage = driver
					.findElement(By.xpath("//p[contains(text(),'How can I help you with HR Policies today?')]"));
			if (HRPolicyDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement childHealthCareWebelement = driver
					.findElement(By.xpath("(//a[contains(text(),'Child Healthcare Policy')])[1]"));
			if (childHealthCareWebelement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			childHealthCareWebelement.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement childHealthCareDefaultMessage = driver.findElement(By.xpath(
					"(//p[contains(text(),'How can I help you with Child Healthcare Policy? Please select from following options or just type in...')])[1]"));
			if (childHealthCareDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			WebElement eligibility = driver.findElement(By.xpath("//a[contains(text(),'Eligibility')]"));
			if (eligibility.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			eligibility.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement EligibilityResponse = driver
					.findElement(By.xpath("//p[contains(text(),'Please note that only children of employee')]"));
			if (EligibilityResponse.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement TravelExpenses = driver.findElement(By.xpath("//a[contains(text(),'Travel Expenses')]"));
			if (TravelExpenses.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			TravelExpenses.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement TravelExpensesResponse = driver.findElement(By.xpath(
					"//p[contains(text(),'One parent will be provided accommodation and travel expenses. The other parent can come and stay on his or her own cost.')]"));
			if (TravelExpensesResponse.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement SupportTenure = driver.findElement(By.xpath("//a[contains(text(),'Support Tenure')]"));
			if (SupportTenure.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			SupportTenure.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement SupportTenureResponse = driver.findElement(By.xpath(
					"//p[contains(text(),'There is no time limit to the hospitalization provided. But this is primarily for surgery purposes and if any specific treatment is required')]"));
			if (SupportTenureResponse.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement TreatmentEligibility = driver
					.findElement(By.xpath("//a[contains(text(),'Treatment Eligibility')]"));
			if (TreatmentEligibility.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			TreatmentEligibility.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement TreatmentEligibilityResponse = driver.findElement(By.xpath(
					"//p[contains(text(),'Employe cannot avail of reimbursements for treatment done elsewhere. This benefit is meant for supporting an employee during his time of need. The employee will need to come to Max Hospitals in Delhi for medical care for his child.')]"));
			if (TreatmentEligibilityResponse.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement SupportingDocuments = driver
					.findElement(By.xpath("//a[contains(text(),'Supporting Documents')]"));
			if (SupportingDocuments.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			SupportingDocuments.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement SupportingDocumentsResponse = driver.findElement(By.xpath(
					"//p[contains(text(),'The MIF rep in MAXLI will require you to provide us with the birth certificate of the child along with the case history of the problem and the doctor�s recommendation. Please also provide your contact details so that MIF or a Max doctor can get in touch with you directly for clarifying any questions that they might have.')]"));
			if (SupportingDocumentsResponse.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement AdmissionProcess = driver.findElement(By.xpath("//a[contains(text(),'Admission Process')]"));
			if (AdmissionProcess.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			AdmissionProcess.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement AdmissionProcessResponse = driver.findElement(By.xpath(
					"//p[contains(text(),'Please note that the process of checking and clarifying can take upto 7 working days to speed up the process employees are requested to share details of medical care / history and doctor recommendation upfront with the OH who will share the same with us.')]"));
			if (AdmissionProcessResponse.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement DiseasesCoverage = driver.findElement(By.xpath("//a[contains(text(),'Diseases Coverage')]"));
			if (DiseasesCoverage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			DiseasesCoverage.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement DiseasesCoverageResponse = driver
					.findElement(By.xpath("//p[contains(text(),'As per the initiative any MAXLI employee')]"));
			if (DiseasesCoverageResponse.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement PostTreatment = driver.findElement(By.xpath("//a[contains(text(),'Post Treatment')]"));
			if (PostTreatment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			PostTreatment.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement PostTreatmentResponse = driver.findElement(
					By.xpath("//p[contains(text(),'Post treatment medication is not included in this benefit.')]"));
			if (PostTreatmentResponse.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
//			WebElement PolicyDocument = driver.findElement(By.xpath("//a[contains(text(),'Policy Document')]"));
//			if (PolicyDocument.isDisplayed() == true) {
//				Assert.assertTrue(true);
//			} else {
//				Assert.assertFalse(false);
//			}
//			Thread.sleep(1000);
//			PolicyDocument.click();
//			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//			WebElement PolicyDocumentResponse = driver.findElement(
//					By.xpath("//p[contains(text(),'Here is the Child Healthcare Policy document for your perusal.')]"));
//			if (PolicyDocumentResponse.isDisplayed() == true) {
//				Assert.assertTrue(true);
//			} else {
//				Assert.assertFalse(false);
//			}
			Thread.sleep(1000);
			WebElement inputTextField = driver.findElement(By.xpath("//input[@ng-model='inputText']"));
			inputTextField.sendKeys("fjjjjjkkxkfxkfxkfxkxk36436");
			WebElement clickButton = driver.findElement(By.xpath("//img[@class='send']"));
			clickButton.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement sorryMessage = driver.findElement(By.xpath(
					"//p[contains(text(),'Sorry we could not find an answer. Please check policy document on Disha/e-Cube for more details.')]"));
//			WebElement PDFDocument = driver
//					.findElement(By.xpath("//u[contains(text(),'Child Healthcare Policy Document')]"));
			if (sorryMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(500);
			WebElement RefreshButton = driver.findElement(By.xpath("//img[@src='img/homeicon.svg']"));
			RefreshButton.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} else {
			System.out.println("HR Policies is not present");
		}

	}

	@Test(priority = 2)
	public void companyAssetPolicy() throws InterruptedException {

		WebElement HiPriyankaDefaultMessage = driver.findElement(By.xpath("//p[text()='Hi Priyanka']"));
		WebElement howCanIHelp = driver
				.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (HiPriyankaDefaultMessage.isDisplayed() == true && howCanIHelp.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		WebElement checkHRPolicies = driver.findElement(By.xpath("//a[contains(text(),'HR Policies')]"));
		if (checkHRPolicies.isDisplayed()) {
			checkHRPolicies.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement HRPolicyDefaultMessage = driver
					.findElement(By.xpath("//p[contains(text(),'How can I help you with HR Policies today?')]"));
			if (HRPolicyDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement companyAssetPolicyButton = driver
					.findElement(By.xpath("(//a[text()='Company Asset Policy'])[1]"));

			if (companyAssetPolicyButton.isDisplayed() == true) {
				companyAssetPolicyButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement companyAssetPolicyClickDefaultMessage = driver.findElement(By.xpath(
						"(//p[contains(text(),'How can I help you with Company Asset Policy? Please select from following options or just type in...')])[1]"));
				if (companyAssetPolicyClickDefaultMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				// Checking cloud button and clicking in queue
				WebElement eligibility = driver.findElement(By.xpath("//a[contains(text(),'Eligibility')]"));
				if (eligibility.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				eligibility.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement EligibilityResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'All full time employees on the payroll of Max Life at Band 3 or above have an option to purchase furniture, electronics or car through the Company Asset Scheme. ')]"));
				if (EligibilityResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement process = driver.findElement(By.xpath("//a[contains(text(),'Process')]"));
				if (process.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				process.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement processResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Employees wishing to purchase assets are required to submit filled Asset Purchase Requisition form where they undertake to buy back the asset at the end of the stipulated period or if they resign at the buyback value as determined by Max Life.')]"));
				if (processResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement TaxCompanyScheme = driver
						.findElement(By.xpath("//a[contains(text(),'Tax Company Scheme')]"));
				if (TaxCompanyScheme.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				TaxCompanyScheme.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement TaxCompanySchemeResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'As per Rule 3(7) (vii) of the new perquisite rules, the value of any personal benefit to the employee from the use by the employee or any member of his household of furniture and other appliances (other than laptops and computers) shall be determined to be 10% of the original cost of such asset paid or payable by Max Life , as reduced by the amount, if any, paid or recovered from the employee for such use')]"));
				if (TaxCompanySchemeResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement RecoveryScheme = driver.findElement(By.xpath("//a[contains(text(),'Recovery Scheme')]"));
				if (RecoveryScheme.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				RecoveryScheme.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement RecoverySchemeResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Company will recover 10% of original cost of the asset in the beginning of the year')]"));
				if (RecoverySchemeResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement ExitScheme = driver.findElement(By.xpath("//a[contains(text(),'Exit Scheme')]"));
				if (ExitScheme.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				ExitScheme.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ExitSchemeResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'If employees leaves before the depreciation period is over for the asset purchased under the company asset scheme, employee will have to buy back the asset from Max Life.')]"));
				if (ExitSchemeResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Assetbuyback = driver.findElement(By.xpath("//a[contains(text(),'Asset buyback')]"));
				if (Assetbuyback.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Assetbuyback.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement AssetbuybackResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. In case, for any reason, including but not limited to the termination/resignation of the employee, employee should buy back all assets purchased under the company asset scheme.')]"));
				if (AssetbuybackResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Relocate = driver.findElement(By.xpath("//a[contains(text(),'Relocate')]"));
				if (Relocate.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Relocate.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement RelocateResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Any and all costs incurred on account of movement � transportation, registration, any taxes, service tax will have to be borne by the employee.')]"));
				if (RelocateResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement UpgradeAsset = driver.findElement(By.xpath("//a[contains(text(),'Upgrade Asset')]"));
				if (UpgradeAsset.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				UpgradeAsset.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement UpgradeAssetResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Employee can upgrade to a new car/asset before the depreciation period is over but the employee would need to first buy back the asset from Max Life.')]"));
				if (UpgradeAssetResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement PersonalAssets = driver.findElement(By.xpath("//a[contains(text(),'Personal Assets')]"));
				if (PersonalAssets.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				PersonalAssets.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement PersonalAssetsResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Employee cannot avail reimbursement under the Flexible Benefits Plan for personal assets.')]"));
				if (PersonalAssetsResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Movement = driver.findElement(By.xpath("//a[contains(text(),'Movement')]"));
				if (Movement.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Movement.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement MovementREsponse = driver.findElement(By.xpath(
						"//p[contains(text(),'In case employee moves to other Max Group company,  employee/the new company would have to buy back the asset from Max Life.')]"));
				if (MovementREsponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
//				Thread.sleep(1000);
//				WebElement PolicyDocument = driver.findElement(By.xpath("//a[contains(text(),'Policy Document')]"));
//				if (PolicyDocument.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
//				Thread.sleep(1000);
//				PolicyDocument.click();
//				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//				WebElement PolicyDocumentResponse = driver.findElement(By
//						.xpath("//p[contains(text(),'Here is the Company Asset Policy document for your perusal.')]"));
//				if (PolicyDocumentResponse.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
				Thread.sleep(1000);
				WebElement inputTextField = driver.findElement(By.xpath("//input[@ng-model='inputText']"));
				inputTextField.sendKeys("ksikffwgfiwfgifgwigfig53525");
				WebElement clickButton = driver.findElement(By.xpath("//img[@class='send']"));
				clickButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement sorryMessage = driver.findElement(By.xpath(
						"//p[contains(text(),'Sorry we could not find an answer. Please check policy document on Disha/e-Cube for more details.')]"));
//				WebElement PDFDocument = driver
//						.findElement(By.xpath("//u[contains(text(),'Company Asset Policy Document')]"));
				if (sorryMessage.isDisplayed() == true ) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(500);
				WebElement RefreshButton = driver.findElement(By.xpath("//img[@src='img/homeicon.svg']"));
				RefreshButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else {
				System.out.println("HR Policies is not present");
			}

		}

	}

	@Test(priority = 3)
	public void WorkingHourPolicy() throws InterruptedException {
		WebElement HiPriyankaDefaultMessage = driver.findElement(By.xpath("//p[text()='Hi Priyanka']"));
		WebElement howCanIHelp = driver
				.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (HiPriyankaDefaultMessage.isDisplayed() == true && howCanIHelp.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		WebElement checkHRPolicies = driver.findElement(By.xpath("//a[contains(text(),'HR Policies')]"));
		if (checkHRPolicies.isDisplayed()) {
			checkHRPolicies.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement HRPolicyDefaultMessage = driver
					.findElement(By.xpath("//p[contains(text(),'How can I help you with HR Policies today?')]"));
			if (HRPolicyDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement WorkingHourPolicyButton = driver
					.findElement(By.xpath("(//a[contains(text(),'Working Hour Policy')])[1]"));
			if (WorkingHourPolicyButton.isDisplayed()) {
				WorkingHourPolicyButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement WorkingHourPolicyClickDefaultMessage = driver.findElement(By.xpath(
						"(//p[contains(text(),'How can I help you with Working Hour Policy? Please select from following options or just type in...')])[1]"));
				if (WorkingHourPolicyClickDefaultMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				// Checking cloud button and clicking in queue
				WebElement LightsOut = driver.findElement(By.xpath("//a[contains(text(),'Lights-Out')]"));
				if (LightsOut.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				LightsOut.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement LightsOutResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Lights-out means that all offices would be closed on the 1st & 3rd Wednesday of every month at 6:30 pm (GO) & 6:00 pm (HO).')]"));
				if (LightsOutResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Applicability = driver.findElement(By.xpath("//a[contains(text(),'Applicability')]"));
				if (Applicability.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Applicability.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ApplicabilityResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Lights-out is only applicable on the first & third Wednesday of every month.')]"));
				if (ApplicabilityResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement WorkTimings = driver.findElement(By.xpath("//a[contains(text(),'Work Timings')]"));
				if (WorkTimings.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WorkTimings.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement WorkTimingsResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Max Life has defined working hours for all offices and the office head cannot change the work timings.  ')]"));
				if (WorkTimingsResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement LateWorking = driver.findElement(By.xpath("//a[contains(text(),'Late Working')]"));
				if (LateWorking.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				LateWorking.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement LateWorkingResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'No female employee, contractors, advisors or agents should be working beyond 8:00 pm in any day of the year')]"));
				if (LateWorkingResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement WorkingHours = driver.findElement(By.xpath("//a[contains(text(),'Working Hours')]"));
				if (WorkingHours.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WorkingHours.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement WorkingHoursResponse = driver
						.findElement(By.xpath("//p[contains(text(),'Work hours are mentioned below:')]"));
				if (WorkingHoursResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
//				Thread.sleep(1000);
//				WebElement PolicyDocument = driver.findElement(By.xpath("//a[contains(text(),'Policy Document')]"));
//				if (PolicyDocument.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
//				Thread.sleep(1000);
//				PolicyDocument.click();
//				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//				WebElement PolicyDocumentResponse = driver.findElement(
//						By.xpath("//p[contains(text(),'Here is the Working Hour Policy document for your perusal.')]"));
//				if (PolicyDocumentResponse.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
				Thread.sleep(1000);
				WebElement inputTextField = driver.findElement(By.xpath("//input[@ng-model='inputText']"));
				inputTextField.sendKeys("hdjejdjdjdj3252hsh");
				WebElement clickButton = driver.findElement(By.xpath("//img[@class='send']"));
				clickButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement sorryMessage = driver.findElement(By.xpath(
						"//p[contains(text(),'Sorry we could not find an answer. Please check policy document on Disha/e-Cube for more details.')]"));
//				WebElement PDFDocument = driver
//						.findElement(By.xpath("//u[contains(text(),'Working Hour Policy Document')]"));
				if (sorryMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}

			} else {
				System.out.println("HR Policies is not present");
			}
			Thread.sleep(500);
			WebElement RefreshButton = driver.findElement(By.xpath("//img[@src='img/homeicon.svg']"));
			RefreshButton.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		}

	}

	@Test(priority = 4)
	public void RecruitmentPolicy() throws InterruptedException {

		WebElement HiPriyankaDefaultMessage = driver.findElement(By.xpath("//p[text()='Hi Priyanka']"));
		WebElement howCanIHelp = driver
				.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (HiPriyankaDefaultMessage.isDisplayed() == true && howCanIHelp.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		WebElement checkHRPolicies = driver.findElement(By.xpath("//a[contains(text(),'HR Policies')]"));
		if (checkHRPolicies.isDisplayed()) {
			checkHRPolicies.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement HRPolicyDefaultMessage = driver
					.findElement(By.xpath("//p[contains(text(),'How can I help you with HR Policies today?')]"));
			if (HRPolicyDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement RecruitmentPolicyButton = driver.findElement(By.xpath("(//a[text()='Recruitment Policy'])[1]"));

			if (RecruitmentPolicyButton.isDisplayed() == true) {
				RecruitmentPolicyButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement RecruitmentPolicyClickDefaultMessage = driver.findElement(By.xpath(
						"(//p[contains(text(),'How can I help you with Recruitment Policy? Please select from following options or just type in...')])[1]"));
				if (RecruitmentPolicyClickDefaultMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				// Checking cloud button and clicking in queue
				WebElement JobEligibility = driver.findElement(By.xpath("//a[contains(text(),'Job Eligibility')]"));
				if (JobEligibility.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				JobEligibility.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement EligibilityResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Employees can apply for any job within and across departments. However, they should meet the eligibility criteria in the Internal Job Posting Policy ')]"));
				if (EligibilityResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement SalaryChange = driver.findElement(By.xpath("//a[contains(text(),'Salary Change')]"));
				if (SalaryChange.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				SalaryChange.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement SalaryChangeResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Salary is a function of job size, market benchmark and performance.')]"));
				if (SalaryChangeResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement AppraisalProcess = driver.findElement(By.xpath("//a[contains(text(),'Appraisal Process')]"));
				if (AppraisalProcess.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				AppraisalProcess.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement AppraisalProcessResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'The employee will have two appraisals, one for the role he/she is leaving and the other for the new role. The performance appraisal for the earlier job should be completed and recorded before the employee moves into the new role. A weighted average of the scores of the two appraisals will be calculated to arrive at a final score/rating. ')]"));
				if (AppraisalProcessResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement TransferBenefits = driver.findElement(By.xpath("//a[contains(text(),'Transfer Benefits')]"));
				if (TransferBenefits.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				TransferBenefits.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement TransferBenefitsResponse = driver.findElement(
						By.xpath("//p[contains(text(),' The relocation policy will be applicable in such cases. ')]"));
				if (TransferBenefitsResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement NonselectionFeedback = driver
						.findElement(By.xpath("//a[contains(text(),'Non-selection Feedback')]"));
				if (NonselectionFeedback.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				NonselectionFeedback.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ExitSchemeResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'We believe in fair and transparent feedback. In case of non-selection, reporting manager will share feedback with employee. However this will not be up for debate.   ')]"));
				if (ExitSchemeResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement MinimumTenure = driver.findElement(By.xpath("//a[contains(text(),'Minimum Tenure')]"));
				if (MinimumTenure.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				MinimumTenure.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement MinimumTenureResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Minimum tenure for role change will be basis the IJP policy. Employees are urged to do all their thinking and research before applying for and accepting the new assignment. ')]"));
				if (MinimumTenureResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement DecisionProcess = driver.findElement(By.xpath("//a[contains(text(),'Decision Process')]"));
				if (DecisionProcess.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				DecisionProcess.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement DecisionProcessResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'The Hiring Team will take the final decision on selection while following the approval hierarchy defined for recruitments. ')]"));
				if (DecisionProcessResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement RehirePolicy = driver.findElement(By.xpath("//a[contains(text(),'Rehire Policy')]"));
				if (RehirePolicy.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				RehirePolicy.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement RehirePolicyResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Employee can be hired within 1 month of leaving Max Life provided the candidates meets the eligibility criteria listed in the Rehire Policy. ')]"));
				if (RehirePolicyResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement ExemployeeProcess = driver
						.findElement(By.xpath("//a[contains(text(),'Ex-employee Process')]"));
				if (ExemployeeProcess.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				ExemployeeProcess.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement PersonalAssetsResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Ex-employee can be rehired in a different department or role basis fitment the ex employee can be hired in any department or role. ')]"));
				if (PersonalAssetsResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement ReferralPayment = driver.findElement(By.xpath("//a[contains(text(),'Referral Payment')]"));
				if (ReferralPayment.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				ReferralPayment.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ReferralPaymentREsponse = driver.findElement(By.xpath(
						"//p[contains(text(),'The payment will be made in the next month, of the month when the referred employee completes 90 calendar days of service with Max Life and is not serving notice period')]"));
				if (ReferralPaymentREsponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
//				Thread.sleep(1000);
//				WebElement PolicyDocument = driver.findElement(By.xpath("//a[contains(text(),'Policy Document')]"));
//				if (PolicyDocument.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
//				Thread.sleep(1000);
//				PolicyDocument.click();
//				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//				WebElement PolicyDocumentResponse = driver.findElement(
//						By.xpath("//p[contains(text(),'Here is the Recruitment Policy document for your perusal.')]"));
//				if (PolicyDocumentResponse.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
				Thread.sleep(1000);
				WebElement inputTextField = driver.findElement(By.xpath("//input[@ng-model='inputText']"));
				inputTextField.sendKeys("ksikffwgfiwfgifgwigfig53525");
				WebElement clickButton = driver.findElement(By.xpath("//img[@class='send']"));
				clickButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement sorryMessage = driver.findElement(By.xpath(
						"//p[contains(text(),'Sorry we could not find an answer. Please check policy document on Disha/e-Cube for more details.')]"));
//				WebElement PDFDocument = driver.findElement(By.xpath("//u[contains(text(),'Recruitment Policy')]"));
				if (sorryMessage.isDisplayed() == true ) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(500);
				WebElement RefreshButton = driver.findElement(By.xpath("//img[@src='img/homeicon.svg']"));
				RefreshButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else {
				System.out.println("HR Policies is not present");
			}

		}

	}

	@Test(priority = 5)
	public void WorkingMotherPolicy() throws InterruptedException {

		WebElement HiPriyankaDefaultMessage = driver.findElement(By.xpath("//p[text()='Hi Priyanka']"));
		WebElement howCanIHelp = driver
				.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (HiPriyankaDefaultMessage.isDisplayed() == true && howCanIHelp.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		WebElement checkHRPolicies = driver.findElement(By.xpath("//a[contains(text(),'HR Policies')]"));
		if (checkHRPolicies.isDisplayed()) {
			checkHRPolicies.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement HRPolicyDefaultMessage = driver
					.findElement(By.xpath("//p[contains(text(),'How can I help you with HR Policies today?')]"));
			if (HRPolicyDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement nextButton = driver.findElement(By.xpath("//button[text()='Next']"));
			nextButton.click();
			Thread.sleep(500);
			WebElement WorkingMotherPolicyButton = driver
					.findElement(By.xpath("//a[contains(text(),'Working Mother')]"));

			if (WorkingMotherPolicyButton.isDisplayed() == true) {
				WorkingMotherPolicyButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement RecruitmentPolicyClickDefaultMessage = driver
						.findElement(By.xpath("//p[contains(text(),'How can I help you with Working Mother')]"));
				if (RecruitmentPolicyClickDefaultMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				// Checking cloud button and clicking in queue
				WebElement SickLeave = driver.findElement(By.xpath("//a[contains(text(),'Sick Leave')]"));
				if (SickLeave.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				SickLeave.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement SickLeaveResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Sick leave can be availed in case of ailment related to maternity before or after delivery based on the registered medical practitioner�s certificate. You should be judicious while using up your leave balance should you need to take leaves for any future exigencies.')]"));
				if (SickLeaveResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Entitlement = driver.findElement(By.xpath("//a[contains(text(),'Entitlement')]"));
				if (Entitlement.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Entitlement.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement EntitlementResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Your maternity leave entitlement as per the policy is upto 26 weeks plus available privilege leave balance. You can therefore avail a maximum of 26 weeks plus 5 privilege leaves.')]"));
				if (EntitlementResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Bonus = driver.findElement(By.xpath("//a[contains(text(),'Bonus')]"));
				if (Bonus.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Bonus.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement AppraisalProcessResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Employee will receive bonus for the entire maternity leave period as per policy basis your performance for the year.')]"));
				if (AppraisalProcessResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement HalfDayHalfPay = driver.findElement(By.xpath("//a[contains(text(),'Half Day- Half Pay')]"));
				if (HalfDayHalfPay.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				HalfDayHalfPay.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement HalfDayHalfPayResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Working mothers can opt to work for �Half Day� i.e 5 hours in a day at any time between 8.00 a.m. to 8.00')]"));
				if (HalfDayHalfPayResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Workfromhome = driver.findElement(By.xpath("//a[contains(text(),'Work from home')]"));
				if (Workfromhome.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Workfromhome.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement WorkfromhomeResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Effective July 1,2017,the female employees availing maternity leave may be allowed the facility of work from')]"));
				if (WorkfromhomeResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement FlexibleWorking = driver.findElement(By.xpath("//a[contains(text(),'Flexible Working')]"));
				if (FlexibleWorking.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				FlexibleWorking.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement MinimumTenureResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Max Life will also provide flexible working hours for working mothers who have children below 5 years.')]"));
				if (MinimumTenureResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
//				Thread.sleep(1000);
//				WebElement PolicyDocument = driver.findElement(By.xpath("//a[contains(text(),'Policy Document')]"));
//				if (PolicyDocument.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
//				Thread.sleep(1000);
//				PolicyDocument.click();
//				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//				WebElement PolicyDocumentResponse = driver
//						.findElement(By.xpath("//p[contains(text(),'Here is the Working Mother')]"));
//				if (PolicyDocumentResponse.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
				Thread.sleep(1000);
				WebElement inputTextField = driver.findElement(By.xpath("//input[@ng-model='inputText']"));
				inputTextField.sendKeys("ksikffwgfiwfgifgwigfig53525");
				WebElement clickButton = driver.findElement(By.xpath("//img[@class='send']"));
				clickButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement sorryMessage = driver.findElement(By.xpath(
						"//p[contains(text(),'Sorry we could not find an answer. Please check policy document on Disha/e-Cube for more details.')]"));
//				WebElement PDFDocument = driver.findElement(By.xpath("(//u[contains(text(),'Working Mother')])[2]"));
				if (sorryMessage.isDisplayed() == true ) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(500);
				WebElement RefreshButton = driver.findElement(By.xpath("//img[@src='img/homeicon.svg']"));
				RefreshButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else {
				System.out.println("HR Policies is not present");
			}

		}

	}

	@Test(priority = 6)
	public void BusinessDressCodePolicy() throws InterruptedException {

		WebElement HiPriyankaDefaultMessage = driver.findElement(By.xpath("//p[text()='Hi Priyanka']"));
		WebElement howCanIHelp = driver
				.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (HiPriyankaDefaultMessage.isDisplayed() == true && howCanIHelp.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		WebElement checkHRPolicies = driver.findElement(By.xpath("//a[contains(text(),'HR Policies')]"));
		if (checkHRPolicies.isDisplayed()) {
			checkHRPolicies.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement HRPolicyDefaultMessage = driver
					.findElement(By.xpath("//p[contains(text(),'How can I help you with HR Policies today?')]"));
			if (HRPolicyDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement nextButton = driver.findElement(By.xpath("//button[text()='Next']"));
			nextButton.click();
			Thread.sleep(500);
			WebElement BusinessDressCodePolicyButton = driver
					.findElement(By.xpath("(//a[text()='Business Dress Code Policy'])[1]"));

			if (BusinessDressCodePolicyButton.isDisplayed() == true) {
				BusinessDressCodePolicyButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement BusinessDressCodePolicyClickDefaultMessage = driver.findElement(By.xpath(
						"(//p[contains(text(),'How can I help you with Business Dress Code Policy? Please select from following options or just type in...')])[1]"));
				if (BusinessDressCodePolicyClickDefaultMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				// Checking cloud button and clicking in queue
				WebElement DressCode = driver.findElement(By.xpath("//a[contains(text(),'Dress Code')]"));
				if (DressCode.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				DressCode.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement SickLeaveResponse = driver.findElement(
						By.xpath("//p[contains(text(),'1. Max Life�s official dress code is business formals.')]"));
				if (SickLeaveResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement FridayDressCode = driver.findElement(By.xpath("//a[contains(text(),'Friday Dress Code')]"));
				if (FridayDressCode.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				FridayDressCode.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement EntitlementResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Fridays in Head Office and Saturdays in GOs are dress down days where employees can choose to dress more casually.')]"));
				if (EntitlementResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement NonCompliance = driver.findElement(By.xpath("//a[contains(text(),'Non-Compliance')]"));
				if (NonCompliance.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				NonCompliance.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement NonComplianceResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'In case of non-compliance or a complaint, employees supervisor and HR Business Partner will counsel the employee to follow the business dress code guidelines. In case of repeat offense it can lead to disciplinary proceedings.')]"));
				if (NonComplianceResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
//				Thread.sleep(1000);
//				WebElement PolicyDocument = driver.findElement(By.xpath("//a[contains(text(),'Policy Document')]"));
//				if (PolicyDocument.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
//				Thread.sleep(1000);
//				PolicyDocument.click();
//				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//				WebElement PolicyDocumentResponse = driver.findElement(By.xpath(
//						"//p[contains(text(),'Here is the Business Dress Code Policy document for your perusal.')]"));
//				if (PolicyDocumentResponse.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
				Thread.sleep(1000);
				WebElement inputTextField = driver.findElement(By.xpath("//input[@ng-model='inputText']"));
				inputTextField.sendKeys("ksikffwgfiwfgifgwigfig53525");
				WebElement clickButton = driver.findElement(By.xpath("//img[@class='send']"));
				clickButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement sorryMessage = driver.findElement(By.xpath(
						"//p[contains(text(),'Sorry we could not find an answer. Please check policy document on Disha/e-Cube for more details.')]"));
//				WebElement PDFDocument = driver
//						.findElement(By.xpath("//u[contains(text(),'Business Dress Code Policy Document')]"));
				if (sorryMessage.isDisplayed() == true ) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(500);
				WebElement RefreshButton = driver.findElement(By.xpath("//img[@src='img/homeicon.svg']"));
				RefreshButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else {
				System.out.println("HR Policies is not present");
			}

		}

	}

	@Test(priority = 7)
	public void FBPPolicy() throws InterruptedException {

		WebElement HiPriyankaDefaultMessage = driver.findElement(By.xpath("//p[text()='Hi Priyanka']"));
		WebElement howCanIHelp = driver
				.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (HiPriyankaDefaultMessage.isDisplayed() == true && howCanIHelp.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		WebElement checkHRPolicies = driver.findElement(By.xpath("//a[contains(text(),'HR Policies')]"));
		if (checkHRPolicies.isDisplayed()) {
			checkHRPolicies.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement HRPolicyDefaultMessage = driver
					.findElement(By.xpath("//p[contains(text(),'How can I help you with HR Policies today?')]"));
			if (HRPolicyDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement nextButton = driver.findElement(By.xpath("//button[text()='Next']"));
			nextButton.click();
			Thread.sleep(500);
			WebElement FBPPolicyButton = driver.findElement(By.xpath("(//a[text()='FBP Policy'])[1]"));

			if (FBPPolicyButton.isDisplayed() == true) {
				FBPPolicyButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement FBPPolicyButtonClickDefaultMessage = driver.findElement(By.xpath(
						"(//p[contains(text(),'How can I help you with FBP Policy? Please select from following options or just type in...')])[1]"));
				if (FBPPolicyButtonClickDefaultMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				// Checking cloud button and clicking in queue
				WebElement Eligibility = driver.findElement(By.xpath("//a[contains(text(),'Eligibility')]"));
				if (Eligibility.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Eligibility.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement EligibilityResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Flexible Benefits is applicable to all regular full time employees on the payroll of Max Life with Total Fixed Pay (TFP) of above Rs. 6 lakhs.')]"));
				if (EligibilityResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement FBPDefinition = driver.findElement(By.xpath("//a[contains(text(),'FBP Definition')]"));
				if (FBPDefinition.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				FBPDefinition.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement FBPDefinitionResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Flexible Benefit plan (FBP) is that portion of salary that can be received as against different expenses, to primarily save on income tax.')]"));
				if (FBPDefinitionResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement FBPComponents = driver.findElement(By.xpath("//a[contains(text(),'FBP Components')]"));
				if (FBPComponents.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				FBPComponents.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement FBPComponentsResponse = driver
						.findElement(By.xpath("//p[contains(text(),'Following are the components of the FBP:')]"));
				if (FBPComponentsResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement BandwiseLimit = driver.findElement(By.xpath("//a[contains(text(),'Band-wise Limit')]"));
				if (BandwiseLimit.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				BandwiseLimit.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement BandwiseLimitResponse = driver.findElement(By.xpath(
						"//p[text()='Please click on Policy Document icon in the bot  to know the band wise limit']"));
				if (BandwiseLimitResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement DeclarationProcess = driver
						.findElement(By.xpath("//a[contains(text(),'Declaration Process')]"));
				if (DeclarationProcess.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				DeclarationProcess.click();
				Thread.sleep(1000);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement DeclarationProcessResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Employees should declare FBP component in Disha at the beginning of year or post salary revision.')]"));
				if (DeclarationProcessResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement ClaimProcess = driver.findElement(By.xpath("//a[contains(text(),'Claim Process')]"));
				if (ClaimProcess.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				ClaimProcess.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ClaimProcessResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Claims raised till 15th of the month is credited to employees salary account by 25th of the same month. FBP claim module is closed in Disha for submission from 16th � 25th of the month.')]"));
				if (ClaimProcessResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement UnclaimedFBP = driver.findElement(By.xpath("//a[contains(text(),'Unclaimed FBP')]"));
				if (UnclaimedFBP.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				UnclaimedFBP.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement MinimumTenureResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Unclaimed FBP will be paid under Cost Control Award (CCA) along with March salary post tax deduction.')]"));
				if (MinimumTenureResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement DriverClaim = driver.findElement(By.xpath("//a[contains(text(),'Driver Claim')]"));
				if (DriverClaim.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				DriverClaim.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement DriverClaimResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Fuel, Car Maintenance and Driver Salary can be claimed only by employees using company leased car or car availed under the company asset scheme')]"));
				if (DriverClaimResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement CarMaintenanceClaim = driver
						.findElement(By.xpath("//a[contains(text(),'Car Maintenance Claim')]"));
				if (CarMaintenanceClaim.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				CarMaintenanceClaim.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement CarMaintenanceClaimResponse = driver.findElement(By.xpath(
						"(//p[contains(text(),'1. Fuel, Car Maintenance and Driver Salary can be claimed only by employees using company leased car or car availed under the company asset scheme')])[2]"));
				if (CarMaintenanceClaimResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement FuelClaim = driver.findElement(By.xpath("//a[contains(text(),'Fuel Claim')]"));
				if (FuelClaim.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				FuelClaim.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement FuelClaimResponse = driver.findElement(By.xpath(
						"(//p[contains(text(),'1. Fuel, Car Maintenance and Driver Salary can be claimed only by employees using company leased car or car availed under the company asset scheme')])[3]"));
				if (FuelClaimResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement TravelCoverage = driver.findElement(By.xpath("//a[contains(text(),'Travel Coverage')]"));
				if (TravelCoverage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				TravelCoverage.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement TravelCoverageResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Only domestic travel is considered for exemption i.e., travels within India. Therefore, no international travel is covered under LTA.')]"));
				if (TravelCoverageResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
//				Thread.sleep(1000);
//				WebElement PolicyDocument = driver.findElement(By.xpath("//a[contains(text(),'Policy Document')]"));
//				if (PolicyDocument.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
//				Thread.sleep(1000);
//				PolicyDocument.click();
//				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//				WebElement PolicyDocumentResponse = driver.findElement(
//						By.xpath("//p[contains(text(),'Here is the FBP Policy document for your perusal.')]"));
//				if (PolicyDocumentResponse.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
				Thread.sleep(1000);
				WebElement inputTextField = driver.findElement(By.xpath("//input[@ng-model='inputText']"));
				inputTextField.sendKeys("ksikffwgfiwfgifgwigfig53525");
				WebElement clickButton = driver.findElement(By.xpath("//img[@class='send']"));
				clickButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement sorryMessage = driver.findElement(By.xpath(
						"//p[contains(text(),'Sorry we could not find an answer. Please check policy document on Disha/e-Cube for more details.')]"));
//				WebElement PDFDocument = driver.findElement(By.xpath("//u[contains(text(),'FBP Policy Document')]"));
				if (sorryMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(500);
				WebElement RefreshButton = driver.findElement(By.xpath("//img[@src='img/homeicon.svg']"));
				RefreshButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else {
				System.out.println("HR Policies is not present");
			}

		}

	}

	@Test(priority = 8)
	public void MedicalPolicy() throws InterruptedException {

		WebElement HiPriyankaDefaultMessage = driver.findElement(By.xpath("//p[text()='Hi Priyanka']"));
		WebElement howCanIHelp = driver
				.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (HiPriyankaDefaultMessage.isDisplayed() == true && howCanIHelp.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		WebElement checkHRPolicies = driver.findElement(By.xpath("//a[contains(text(),'HR Policies')]"));
		if (checkHRPolicies.isDisplayed()) {
			checkHRPolicies.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement HRPolicyDefaultMessage = driver
					.findElement(By.xpath("//p[contains(text(),'How can I help you with HR Policies today?')]"));
			if (HRPolicyDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement nextButton = driver.findElement(By.xpath("//button[text()='Next']"));
			nextButton.click();
			Thread.sleep(500);
			WebElement MedicalPolicy = driver.findElement(By.xpath("(//a[text()='Medical Policy'])[1]"));

			if (MedicalPolicy.isDisplayed() == true) {
				MedicalPolicy.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement MedicalPolicykDefaultMessage = driver.findElement(By.xpath(
						"(//p[contains(text(),'How can I help you with Medical Policy? Please select from following options or just type in...')])[1]"));
				if (MedicalPolicykDefaultMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				// Checking cloud button and clicking in queue
				WebElement Eligibility = driver.findElement(By.xpath("//a[contains(text(),'Eligibility')]"));
				if (Eligibility.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Eligibility.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement EligibilityResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'All regular full time employees on the payroll of Max Life and')]"));
				if (EligibilityResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement SumInsured = driver.findElement(By.xpath("//a[contains(text(),'Sum Insured')]"));
				if (SumInsured.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				SumInsured.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement SumInsuredResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'a) Family: Sum Insured is Rs. 2 lacs per life and premium is sponsored by Max Life.')]"));
				if (SumInsuredResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Floater = driver.findElement(By.xpath("//a[contains(text(),'Floater')]"));
				if (Floater.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Floater.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement FloaterResponse = driver.findElement(By.xpath("//p[contains(text(),'Family Floater:')]"));
				if (FloaterResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement RoomRentcapping = driver.findElement(By.xpath("//a[contains(text(),'Room Rent capping')]"));
				if (RoomRentcapping.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				RoomRentcapping.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement RoomRentcappingResponse = driver
						.findElement(By.xpath("//p[contains(text(),'Location Maximum Room Rent per night (Rs.)')]"));
				if (RoomRentcappingResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement ContactDetails = driver.findElement(By.xpath("//a[contains(text(),'Contact Details')]"));
				if (ContactDetails.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				ContactDetails.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ContactDetailsResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1) Paramount Health Services ( 1800-22-6655/ Varun Tomar (Ph 7042391023)')]"));
				if (ContactDetailsResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement PolicyConditions = driver.findElement(By.xpath("//a[contains(text(),'Policy Conditions')]"));
				if (PolicyConditions.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				PolicyConditions.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement PolicyConditionsResponse = driver.findElement(By
						.xpath("//p[contains(text(),'a) Pre-existing diseases covered without any waiting period')]"));
				if (PolicyConditionsResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement MemberAdditionandDeletion = driver
						.findElement(By.xpath("//a[contains(text(),'Member Addition and Deletion')]"));
				if (MemberAdditionandDeletion.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				MemberAdditionandDeletion.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement MemberAdditionandDeletionResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Employees are covered from date of joining. For new joins family/parents should be enrolled online within 30 days from date of joining in Paramount Health Services portal.')]"));
				if (MemberAdditionandDeletionResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement ClaimIntimation = driver.findElement(By.xpath("//a[contains(text(),'Claim Intimation')]"));
				if (ClaimIntimation.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				ClaimIntimation.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ClaimIntimationResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. In case of planned and emergency hospitalization, claim intimation should be done within 7 days from date of admission. Claim Intimation Form should be emailed to medinsurance.helpdesk@maxlifeinsurance.com/ pradeep.singh@arioninsurancebrokers.com and varun.tomar@paramounttpa.com.')]"));
				if (ClaimIntimationResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement ClaimTimelines = driver.findElement(By.xpath("//a[contains(text(),'Claim Timelines')]"));
				if (ClaimTimelines.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				ClaimTimelines.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ClaimTimelinesResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1.  Pre -hospitalization and hospitalization expenses: All claim documents for reimbursement should be submitted within 30 days from the date of discharge.')]"));
				if (ClaimTimelinesResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement HospitalNetwork = driver.findElement(By.xpath("//a[contains(text(),'Hospital Network')]"));
				if (HospitalNetwork.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				HospitalNetwork.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement HospitalNetworkResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'You can check the network of hospital from the link https://www.paramounttpa.com/Home/ProviderNetwork.aspx')]"));
				if (HospitalNetworkResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement CashlessProcess = driver.findElement(By.xpath("//a[contains(text(),'Cashless Process')]"));
				if (CashlessProcess.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				CashlessProcess.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement CashlessProcessResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Incase the treatment is taken from network of hospital then the employee or claimant needs to submit copy of below')]"));
				if (CashlessProcessResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement NonCashlessProcess = driver
						.findElement(By.xpath("//a[contains(text(),'Non Cashless Process')]"));
				if (NonCashlessProcess.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				NonCashlessProcess.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement NonCashlessProcessResponse = driver.findElement(
						By.xpath("//p[contains(text(),'a) In case the treatment is taken from any non network')]"));
				if (NonCashlessProcessResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
//				Thread.sleep(1000);
//				WebElement PolicyDocument = driver.findElement(By.xpath("//a[contains(text(),'Policy Document')]"));
//				if (PolicyDocument.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
//				Thread.sleep(1000);
//				PolicyDocument.click();
//				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//				WebElement PolicyDocumentResponse = driver.findElement(
//						By.xpath("//p[contains(text(),'Here is the Medical Policy document for your perusal.')]"));
//				if (PolicyDocumentResponse.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
				Thread.sleep(1000);
				WebElement inputTextField = driver.findElement(By.xpath("//input[@ng-model='inputText']"));
				inputTextField.sendKeys("ksikffwgfiwfgifgwigfig53525");
				WebElement clickButton = driver.findElement(By.xpath("//img[@class='send']"));
				clickButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement sorryMessage = driver.findElement(By.xpath(
						"//p[contains(text(),'Sorry we could not find an answer. Please check policy document on Disha/e-Cube for more details.')]"));
//				WebElement PDFDocument = driver
//						.findElement(By.xpath("//u[contains(text(),'Medical Policy Document')]"));
				if (sorryMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(500);
				WebElement RefreshButton = driver.findElement(By.xpath("//img[@src='img/homeicon.svg']"));
				RefreshButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else {
				System.out.println("HR Policies is not present");
			}

		}

	}

	@Test(priority = 9)
	public void CarLeasePolicy() throws InterruptedException {

		WebElement HiPriyankaDefaultMessage = driver.findElement(By.xpath("//p[text()='Hi Priyanka']"));
		WebElement howCanIHelp = driver
				.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (HiPriyankaDefaultMessage.isDisplayed() == true && howCanIHelp.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		WebElement checkHRPolicies = driver.findElement(By.xpath("//a[contains(text(),'HR Policies')]"));
		if (checkHRPolicies.isDisplayed()) {
			checkHRPolicies.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement HRPolicyDefaultMessage = driver
					.findElement(By.xpath("//p[contains(text(),'How can I help you with HR Policies today?')]"));
			if (HRPolicyDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement nextButton = driver.findElement(By.xpath("//button[text()='Next']"));
			nextButton.click();
			Thread.sleep(500);
			nextButton.click();
			Thread.sleep(500);
			WebElement CarLeasePolicy = driver.findElement(By.xpath("(//a[text()='Car Lease Policy'])[2]"));
			if (CarLeasePolicy.isDisplayed() == true) {
				CarLeasePolicy.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement CarLeasePolicyDefaultMessage = driver.findElement(By.xpath(
						"(//p[contains(text(),'How can I help you with Car Lease Policy? Please select from following options or just type in...')])[1]"));
				if (CarLeasePolicyDefaultMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				// Checking cloud button and clicking in queue
				WebElement Eligibility = driver.findElement(By.xpath("//a[contains(text(),'Eligibility')]"));
				if (Eligibility.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Eligibility.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement EligibilityResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. This policy is applicable to all regular full time employees on the payroll of Max Life and with a Total Fixed Pay (TFP) of above Rs. 6 lacs.')]"));
				if (EligibilityResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Limits = driver.findElement(By.xpath("//a[contains(text(),'Limits')]"));
				if (Limits.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Limits.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement LimitsResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Employees can avail upto 60% of their Flexible Benefits Plan (FBP) towards the car lease rental')]"));
				if (LimitsResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Vendors = driver.findElement(By.xpath("//a[contains(text(),'Vendors')]"));
				if (Vendors.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Vendors.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement VendorsResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Employee has a choice to choose between Tranzlease (TZL) and Leasingiq (LIQ)')]"));
				if (VendorsResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement EnrollmentProcess = driver
						.findElement(By.xpath("//a[contains(text(),'Enrollment Process')]"));
				if (EnrollmentProcess.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				EnrollmentProcess.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement EnrollmentProcessResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Please reach out to  Tranzlease (TZL) by sending email to arjun.talwar@tranzlease.com with copy to')]"));
				if (EnrollmentProcessResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Entitlements = driver.findElement(By.xpath("//a[contains(text(),'Entitlements')]"));
				if (Entitlements.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Entitlements.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement EntitlementsResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Employees are eligible for Fuel, Car Maintenance and Driver')]"));
				if (EntitlementsResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement CarUpgrade = driver.findElement(By.xpath("//a[contains(text(),'Car Upgrade')]"));
				if (CarUpgrade.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				CarUpgrade.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement CarUpgradeResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Employees can upgrade to a new car before the lease period is over. Employee needs to first foreclose the existing car under the car lease scheme and then he can apply for car upgrade')]"));
				if (CarUpgradeResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Relocation = driver.findElement(By.xpath("//a[contains(text(),'Relocation')]"));
				if (Relocation.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Relocation.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement RelocationnResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Any and all costs incurred on account of movement � transportation, registration, any taxes, service tax on the monthly lease rental will be debited to employees.')]"));
				if (RelocationnResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement Foreclosure = driver.findElement(By.xpath("//a[contains(text(),'Foreclosure')]"));
				if (Foreclosure.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				Foreclosure.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ForeclosureResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Employee will have to sign a fresh agreement with the vendor or need to foreclose the lease. Max Life will be no longer a party to the same.')]"));
				if (ForeclosureResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement CarModels = driver.findElement(By.xpath("//a[contains(text(),'Car Models')]"));
				if (CarModels.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				CarModels.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement CarModelsResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Employee should be careful to ensure that the car model is in line not only with the employee�s choice but the corresponding monthly lease rental so it can be deducted conveniently from Flexible Benefits Plan balance.')]"));
				if (CarModelsResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement HigherValueCar = driver.findElement(By.xpath("//a[contains(text(),'Higher Value Car')]"));
				if (HigherValueCar.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				HigherValueCar.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement HigherValueCarResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Employees can take car of higher value by paying the differential up front.  This is possible through appropriate adjustment to the upfront deposit amount to be paid to dealer. However, Tranzlease (TZL) / Leasingiq (LIQ) would have the absolute discretion in this regard.')]"));
				if (HigherValueCarResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement DeliveryProcess = driver.findElement(By.xpath("//a[contains(text(),'Delivery  Process')]"));
				if (DeliveryProcess.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				DeliveryProcess.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement DeliveryProcessResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Subject to the documentation being complete as per the process outlined in the policy, it would take around 5-8 days for the process to be completed.')]"));
				if (DeliveryProcessResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
//				Thread.sleep(1000);
//				WebElement PolicyDocument = driver.findElement(By.xpath("//a[contains(text(),'Policy Document')]"));
//				if (PolicyDocument.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
//				Thread.sleep(1000);
//				PolicyDocument.click();
//				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//				WebElement PolicyDocumentResponse = driver.findElement(
//						By.xpath("//p[contains(text(),'Here is the Car Lease Policy document for your perusal.')]"));
//				if (PolicyDocumentResponse.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
				Thread.sleep(1000);
				WebElement inputTextField = driver.findElement(By.xpath("//input[@ng-model='inputText']"));
				inputTextField.sendKeys("ksikffwgfiwfgifgwigfig53525");
				WebElement clickButton = driver.findElement(By.xpath("//img[@class='send']"));
				clickButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement sorryMessage = driver.findElement(By.xpath(
						"//p[contains(text(),'Sorry we could not find an answer. Please check policy document on Disha/e-Cube for more details.')]"));
//				WebElement PDFDocument = driver
//						.findElement(By.xpath("//u[contains(text(),'Car Lease Policy Document')]"));
				if (sorryMessage.isDisplayed() == true ) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(500);
				WebElement RefreshButton = driver.findElement(By.xpath("//img[@src='img/homeicon.svg']"));
				RefreshButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else {
				System.out.println("HR Policies is not present");
			}

		}

	}

	@Test(priority = 10)
	public void TermLifeInsurancePolicy() throws InterruptedException {

		WebElement HiPriyankaDefaultMessage = driver.findElement(By.xpath("//p[text()='Hi Priyanka']"));
		WebElement howCanIHelp = driver
				.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (HiPriyankaDefaultMessage.isDisplayed() == true && howCanIHelp.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		WebElement checkHRPolicies = driver.findElement(By.xpath("//a[contains(text(),'HR Policies')]"));
		if (checkHRPolicies.isDisplayed()) {
			checkHRPolicies.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement HRPolicyDefaultMessage = driver
					.findElement(By.xpath("//p[contains(text(),'How can I help you with HR Policies today?')]"));
			if (HRPolicyDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement nextButton = driver.findElement(By.xpath("//button[text()='Next']"));
			nextButton.click();
			Thread.sleep(500);
			nextButton.click();
			Thread.sleep(500);
			WebElement TermLifeInsurancePolicy = driver
					.findElement(By.xpath("(//a[text()='Term Life Insurance Policy'])[2]"));
			if (TermLifeInsurancePolicy.isDisplayed() == true) {
				TermLifeInsurancePolicy.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement TermLifeInsurancePolicyDefaultMessage = driver.findElement(By.xpath(
						"(//p[contains(text(),'How can I help you with Term Life Insurance Policy? Please select from following options or just type in...')])[1]"));
				if (TermLifeInsurancePolicyDefaultMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				// Checking cloud button and clicking in queue
				WebElement SumAssuredValue = driver.findElement(By.xpath("//a[contains(text(),'Sum Assured Value')]"));
				if (SumAssuredValue.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				SumAssuredValue.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement SumAssuredValueResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Sum assured across all the Bands are 2.5 times of Total Fixed Pay. Minimum Sum Assured is Rs. 10 lacs for any employee.')]"));
				if (SumAssuredValueResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement PremiumPayment = driver.findElement(By.xpath("//a[contains(text(),'Premium Payment')]"));
				if (PremiumPayment.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				PremiumPayment.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement PremiumPaymentResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Premium for Group Term Life Insurance Policy is paid by Max Life.')]"));
				if (PremiumPaymentResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement SumAssuredPayment = driver
						.findElement(By.xpath("//a[contains(text(),'Sum Assured Payment')]"));
				if (SumAssuredPayment.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				SumAssuredPayment.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement SumAssuredPaymentResponse = driver.findElement(By
						.xpath("//p[contains(text(),'Sum Assured will be payable to the nominee of the employee.')]"));
				if (SumAssuredPaymentResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement NomineeProcess = driver.findElement(By.xpath("//a[contains(text(),'Nominee Process')]"));
				if (NomineeProcess.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				NomineeProcess.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement NomineeProcessResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'Employee needs to update the nominee details. In case of the nominee details are not available then the legal heir will be considered as nominee.')]"));
				if (NomineeProcessResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement AccidentalDeathBenefit = driver
						.findElement(By.xpath("//a[contains(text(),'Accidental Death Benefit')]"));
				if (AccidentalDeathBenefit.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				AccidentalDeathBenefit.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement AccidentalDeathBenefitResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Employees can voluntary opt for Accidental Death Benefit Rider by paying premium at the time of policy renewal.')]"));
				if (AccidentalDeathBenefitResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement ContactPerson = driver.findElement(By.xpath("//a[contains(text(),'Contact Person')]"));
				if (ContactPerson.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				ContactPerson.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ContactPersonResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'HR Business Partner is the contact person for group term life insurance policy.')]"));
				if (ContactPersonResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
//				Thread.sleep(1000);
//				WebElement PolicyDocument = driver.findElement(By.xpath("//a[contains(text(),'Policy Document')]"));
//				if (PolicyDocument.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
//				Thread.sleep(1000);
//				PolicyDocument.click();
//				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//				WebElement PolicyDocumentResponse = driver.findElement(By.xpath(
//						"//p[contains(text(),'Here is the Term Life Insurance Policy document for your perusal.')]"));
//				if (PolicyDocumentResponse.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
				Thread.sleep(1000);
				WebElement inputTextField = driver.findElement(By.xpath("//input[@ng-model='inputText']"));
				inputTextField.sendKeys("ksikffwgfiwfgifgwigfig53525");
				WebElement clickButton = driver.findElement(By.xpath("//img[@class='send']"));
				clickButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement sorryMessage = driver.findElement(By.xpath(
						"//p[contains(text(),'Sorry we could not find an answer. Please check policy document on Disha/e-Cube for more details.')]"));
//				WebElement PDFDocument = driver
//						.findElement(By.xpath("//u[contains(text(),'Term Life Insurance Policy Document')]"));
				if (sorryMessage.isDisplayed() == true ) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(500);
				WebElement RefreshButton = driver.findElement(By.xpath("//img[@src='img/homeicon.svg']"));
				RefreshButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else {
				System.out.println("HR Policies is not present");
			}

		}

	}

	@Test(priority = 11)
	public void LeaveandAttendancePolicy() throws InterruptedException {

		WebElement HiPriyankaDefaultMessage = driver.findElement(By.xpath("//p[text()='Hi Priyanka']"));
		WebElement howCanIHelp = driver
				.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (HiPriyankaDefaultMessage.isDisplayed() == true && howCanIHelp.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		WebElement checkHRPolicies = driver.findElement(By.xpath("//a[contains(text(),'HR Policies')]"));
		if (checkHRPolicies.isDisplayed()) {
			checkHRPolicies.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebElement HRPolicyDefaultMessage = driver
					.findElement(By.xpath("//p[contains(text(),'How can I help you with HR Policies today?')]"));
			if (HRPolicyDefaultMessage.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertFalse(false);
			}
			Thread.sleep(1000);
			WebElement nextButton = driver.findElement(By.xpath("//button[text()='Next']"));
			nextButton.click();
			Thread.sleep(500);
			nextButton.click();
			Thread.sleep(500);
			WebElement LeaveandAttendancePolicy = driver
					.findElement(By.xpath("(//a[text()='Leave and Attendance Policy'])[2]"));
			if (LeaveandAttendancePolicy.isDisplayed() == true) {
				LeaveandAttendancePolicy.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement LeaveandAttendancePolicyDefaultMessage = driver.findElement(
						By.xpath("//p[contains(text(),'How can I help you with Leave and Attendance Policy? ')]"));
				if (LeaveandAttendancePolicyDefaultMessage.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				// Checking cloud button and clicking in queue
				WebElement ApplyLeave = driver.findElement(By.xpath("//a[contains(text(),'Apply Leave')]"));
				if (ApplyLeave.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				ApplyLeave.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ApplyLeaveResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Please login to Disha in http://disha.maxindia.com and  go to following path:')]"));
				if (ApplyLeaveResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement CancelLeave = driver.findElement(By.xpath("//a[contains(text(),'Cancel Leave')]"));
				if (CancelLeave.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				CancelLeave.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement CancelLeaveResponse = driver.findElement(By.xpath(
						"(//p[contains(text(),'1. Please login to Disha in http://disha.maxindia.com and  go to following path:')])[2]"));
				if (CancelLeaveResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement ViewLeave = driver.findElement(By.xpath("//a[contains(text(),'View Leave')]"));
				if (ViewLeave.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				ViewLeave.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ViewLeaveResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Please login to Disha in http://disha.maxindia.com and  go to following path: Main Menu >> Self Service >> time reporting.')]"));
				if (ViewLeaveResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement ViewAttendance = driver.findElement(By.xpath("//a[contains(text(),'View Attendance')]"));
				if (ViewAttendance.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				ViewAttendance.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement ViewAttendanceResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Please login to Disha in http://disha.maxindia.com and  go to following path: Main Menu-> HRMS Administration->Time and Labor-> Reports-> Employee wise attendance Report  . From here you can download the attendance report of all the employees from your patch.')]"));
				if (ViewAttendanceResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				WebElement LeaveRegularizationHistory = driver
						.findElement(By.xpath("//a[contains(text(),'Leave/Regularization History')]"));
				if (LeaveRegularizationHistory.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(1000);
				LeaveRegularizationHistory.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement LeaveRegularizationHistoryResponse = driver.findElement(By.xpath(
						"//p[contains(text(),'1. Please login to Disha in http://disha.maxindia.com and  go to following path: Main Menu >> Self Service >> Time Reporting >> View Time >> Leave/Regularization History')]"));
				if (LeaveRegularizationHistoryResponse.isDisplayed() == true) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
//				Thread.sleep(1000);
//				WebElement PolicyDocument = driver.findElement(By.xpath("//a[contains(text(),'Policy Document')]"));
//				if (PolicyDocument.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
//				Thread.sleep(1000);
//				PolicyDocument.click();
//				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//				WebElement PolicyDocumentResponse = driver.findElement(By.xpath(
//						"//p[contains(text(),'Here is the Leave and Attendance Policy document for your perusal.')]"));
//				if (PolicyDocumentResponse.isDisplayed() == true) {
//					Assert.assertTrue(true);
//				} else {
//					Assert.assertFalse(false);
//				}
				Thread.sleep(1000);
				WebElement inputTextField = driver.findElement(By.xpath("//input[@ng-model='inputText']"));
				inputTextField.sendKeys("ksikffwgfiwfgifgwigfig53525");
				WebElement clickButton = driver.findElement(By.xpath("//img[@class='send']"));
				clickButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				WebElement sorryMessage = driver.findElement(By.xpath(
						"//p[contains(text(),'Sorry we could not find an answer. Please check policy document on Disha/e-Cube for more details.')]"));
//				WebElement PDFDocument = driver
//						.findElement(By.xpath("//u[contains(text(),'Leave and Attendance Policy Document')]"));
				if (sorryMessage.isDisplayed() == true ) {
					Assert.assertTrue(true);
				} else {
					Assert.assertFalse(false);
				}
				Thread.sleep(500);
				WebElement RefreshButton = driver.findElement(By.xpath("//img[@src='img/homeicon.svg']"));
				RefreshButton.click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else {
				System.out.println("HR Policies is not present");
			}

		}

	}
}