package NA_bot;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import screenshot.ScreenShot;

public class DreemWeddingOfChild {
	// Global Variable
	WebDriver driver;
	String name = "Rahul";
	// PreCondition starts here

	@BeforeClass
	public void PreConditions() throws IOException {
			System.setProperty("webdriver.chrome.driver", "D:\\Eclipse\\ChatBot\\All exe\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get("https://bot.maxlifeinsurance.com/need-analysis");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} 
	
	@Test
	public void dreemWeedingOfChild() throws IOException, InterruptedException{
		try{
		WebElement dreemWedding = driver.findElement(By.xpath("//span[text()='dream wedding of child']"));	
		if(dreemWedding.isDisplayed()==true	)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		dreemWedding.click();
		WebElement proceed = driver.findElement(By.xpath("//span[text()='Proceed']"));
		Thread.sleep(1000);
		proceed.click();

		WebElement createWealthElement = driver.findElement(By.xpath("//span[text()='DREAM WEDDING OF CHILD']"));
		WebElement nameVerify = driver.findElement(By.xpath("//p[text()=' What is your name?']"));
		if (createWealthElement.isDisplayed() == true && nameVerify.isDisplayed() == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write here....']")).sendKeys(name);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		boolean verfiName = driver.findElement(By.xpath("//p[contains(text(),' How old are you,')]")).isDisplayed();
		boolean defaultAge = driver.findElement(By.xpath("//input[@value='30']")).isDisplayed();
		if (verfiName == true && defaultAge == true) {
			Assert.assertTrue(true, "What is your name and default Age is verified");
		} else {
			Assert.assertFalse(true, "One of thr webelement is not displayed or may be both");
		}
		driver.findElement(By.xpath("//img[@class='send']")).click();
		boolean verifyMobile = driver.findElement(By.xpath("//p[contains(text(),'your mobile number?')]")).isDisplayed();
		if (verifyMobile == true) {
			Assert.assertTrue(true, "Element is displayed");
		} else {
			Assert.assertTrue(false, "Webelement is not displayed");
		}
		driver.findElement(By.xpath("//input[@placeholder='XXXXXXXXXX']")).sendKeys("9999999999");

		driver.findElement(By.xpath("//img[@class='send']")).click();
		WebElement verifyWebElement = driver.findElement(By.xpath("//p[contains(text(),'What is your child')]"));
		if (verifyWebElement.isDisplayed() == true) {
			Reporter.log("Curent Annual Income is Displayed and verified");
		} else {
			Reporter.log("Curent Annual Income is not verified");
		}
		driver.findElement(By.xpath("//input[@placeholder='Write here....']")).sendKeys(name);
		driver.findElement(By.xpath("//img[@class='send']")).click();
		boolean defaultIncome = driver.findElement(By.xpath("//p[contains(text(),' How old is ')]")).isDisplayed();
		if (defaultIncome == true) {
			Reporter.log("Webelement is displayed");
		}

		else {
			Reporter.log("Webelement is not displayed");
		}

		driver.findElement(By.xpath("//img[@class='send']")).click();
		boolean target = driver.findElement(By.xpath("//p[contains(text(),' When do you want ')]")).isDisplayed();
		boolean childMarriageAge = driver.findElement(By.xpath("//span[text()='32']")).isDisplayed();
		if (target == true && childMarriageAge==true) {
			Reporter.log("Get married element is verified");
		} else {
			Reporter.log("Get married webelement is not verified");
		}
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean elementDisplayed = driver.findElement(By.xpath("//p[contains(text(),' was getting married today, how much money was needed?')]")).isDisplayed();
		if (elementDisplayed == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "What is your currently income webelement is not displayed");
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//img[@class='send']")).click();
		boolean checkDisplay = driver.findElement(By.xpath("//p[contains(text(),'How much have you saved for Rahul')]")).isDisplayed();
		if (checkDisplay == true) {
			Assert.assertTrue(true, "How much saving have you done text is displayed");
		} else {
			Assert.assertTrue(false, "Webelement is not displayed");
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean currentAnnualIncome = driver.findElement(By.xpath("//p[contains(text(),' What is your current annual income?')]")).isDisplayed();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		boolean checkElementPresent = driver.findElement(By.xpath("//p[contains(text(),' Inflation rate, which will impact the wedding cost, should be (8%). Do you want to edit this?')]")).isDisplayed();
		if (checkElementPresent == true) {
			Assert.assertTrue(true, "Webelement is present");
		} else {

			Assert.assertFalse(false);
		}
		List<WebElement> listOfWebelements = driver.findElements(By.xpath("//ul[@class='list-inline']//span[2]"));
		String[] elements = new String[listOfWebelements.size()];
		int listSize = listOfWebelements.size();
		int i = 0;
		if (listSize == 2) {
			for (WebElement e : listOfWebelements) {
				System.out.println(elements[i] = e.getText());
			}
		}
		WebElement verifyElementPresent = driver.findElement(By.xpath("//ul[@class='list-inline']//span[text()='No']"));
		if (verifyElementPresent.isDisplayed() == true) {
			Assert.assertTrue(true, "Webelement is present and verified");
		} else {
			Assert.assertTrue(false, "Web element is not present");
		}
		Thread.sleep(1000);
		verifyElementPresent.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement rateOfReturn = driver.findElement(By.xpath("//p[text()=' Rate of return on your money should be (8%). Do you want to edit this?']"));
		if (rateOfReturn.isDisplayed() == true) {
			Assert.assertTrue(true, "Rate of Interest text is displayed");
		} else {
			Assert.assertTrue(false, "Rate of Interest text is not displayed");
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//ul[@class='list-inline']//span[text()='No']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		boolean webelementDisplay = driver.findElement(By.xpath("//p[text()=' What is your risk preference when investing money?']")).isDisplayed();
		WebElement checkWebelemtPresent = driver.findElement(By.xpath("//span[text()=' Medium']"));

		if (webelementDisplay == true && checkWebelemtPresent.isDisplayed() == true) {
			Assert.assertTrue(true, "Webelement is present");
		} else {
			Assert.assertFalse(true, "Webelement is not present");
		}

		Thread.sleep(1000);
		checkWebelemtPresent.click();
		List<WebElement> storeListOfWebelement = driver.findElements(By.xpath("//div[@class='protect']//div"));
		String[] store = new String[storeListOfWebelement.size()];
		int size = storeListOfWebelement.size();
		if (size == 3) {
			for (WebElement e : storeListOfWebelement) {
				System.out.println(store[i] = e.getText());
			}

		}
		WebElement seePlanElement = driver.findElement(By.xpath("//div[text()='SEE PLAN']"));
		seePlanElement.click();
		boolean thankYouDisplay = driver.findElement(By.xpath("//p[contains(text(),'Thank you ')]")).isDisplayed();
		boolean personalizedDetailedElement = driver.findElement(By.xpath("//p[contains(text(),' Here is your personalised financial summary.')]")).isDisplayed();
		if (thankYouDisplay == true && personalizedDetailedElement == true) {
			Assert.assertTrue(true, "Webelement is disaplayed and verified");
		} else {
			Assert.assertTrue(false, "webelement is not verified");
		}
		List<WebElement> onlineTermPlanPlus = driver.findElements(By.xpath("//div[@class='benefits']//div//*"));
		int listSizeOfOnlineTermOlan = onlineTermPlanPlus.size();
		String saveAllListData[] = new String[listSizeOfOnlineTermOlan];
		if (listSizeOfOnlineTermOlan == 7) {
			int j = 0;
			for (WebElement e : onlineTermPlanPlus) {
				System.out.println(saveAllListData[j] = e.getText());
			}
		} else {
			Assert.assertTrue(false, "Loop terminated");
		}

		WebElement getACallElement = driver.findElement(By.xpath("//p[text()='Get A Call']"));
		if (getACallElement.isDisplayed() == true)
		{
			Assert.assertTrue(true, "Webelement is verified");
		}
		else
		{
			Assert.assertTrue(false, "Element is not verified");
		}
		Thread.sleep(1000);
		getACallElement.click();

		WebElement emailIDElement = driver.findElement(By.xpath("//input[@placeholder='example@gmail.com']"));
		emailIDElement.sendKeys("abcd@gmail.com");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*//p[text()='Send']")).click();
		ArrayList<String> list = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(list.get(0));
		boolean thankYouElement = driver.findElement(By.xpath("//p[text()='Thank you Rahul. We have sent the financial summary to your email address.']")).isDisplayed();
		WebElement startANewJourny = driver.findElement(By.xpath("//span[text()='Start a new journey']"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if (thankYouElement == true && startANewJourny.isDisplayed() == true) {
			Assert.assertTrue(true, "Element is verified");
		} else {
			Assert.assertTrue(false, "Webelement is not verified");
		}

		Thread.sleep(1000);
		startANewJourny.click();
	}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@AfterClass
	public void postCondition() {
		driver.quit();
	}
}
