package BPMA_Bot;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class BPMA_CR_Bot {
	WebDriver driver;
	
	@BeforeClass
	public void PreConditions() throws IOException {
		System.setProperty("webdriver.chrome.driver", "E:\\chatBot\\exeFolder\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://botuat.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=hvhom1028&key3=IOS&key4=eapp");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	@Test
	public void AgencySuperZoneAutomation()
	{		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
			WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
			if(hiHarsh.isDisplayed()==true && howCanIHelp.isDisplayed())
			{
				Assert.assertTrue(true);
			}
			else
			{
				Assert.assertTrue(false);
			}
			
			//First KPI- BIG Update starts Here
			
			WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
			if(verifybiZUpdate.isDisplayed()==true)
			{
				Assert.assertTrue(true);
				verifybiZUpdate.click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				
				WebElement channel = driver.findElement(By.xpath("//p[contains(text(),'the Business update for MLI is') and contains(text(),'Agency, Axis Bank, Banca, CAT, Ecomm, IM/IMF, SPARC, POSP')]"));
				if(channel.isDisplayed()==true)
				{
					Assert.assertTrue(true);
					System.out.println("Channel is displayed and verified");
				}
				else
				{
					Assert.assertTrue(false);
					System.out.println("channel is not displayed or verified");
				}
				
				WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
				//First Channel starts here
				nameElement.sendKeys("Agency");
				WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Agency is :')]"));
				if(channelData.isDisplayed()==true)
				{
					Assert.assertTrue(true);
					System.out.println("Sub Channel is data is displayed and verified");
				}
				else
				{
					Assert.assertTrue(false);
					System.out.println("Sub channel is not displayed");
				}				
				//Sub Channel starts here
				nameElement.sendKeys("Defence");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement subChannelUpdate = driver.findElement(By.xpath("//p[contains(text(),'the Business update for SubChannel Defence is :')]"));
				if(subChannelUpdate.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				nameElement.sendKeys("Super Zone 1");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement superZone1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Super Zone 1 is :')]"));
				if(superZone1.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				verifybiZUpdate.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Super Zone 1:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Super Zone 1 is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level Super Zone 1 has achieved')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 has witnessed paid Business growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Super Zone 1')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Super Zone 1 is:')]")).isDisplayed();
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Super Zone 1:')]")).isDisplayed();
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Super Zone 1 is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 Defence has witnessed applied Business growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 Case Size acheivement MTD:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Super Zone 1 is Annual:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Super Zone 1 is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Super Zone 1 is :')]")).isDisplayed();
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Super Zone 1')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Super Zone 1 is')]")).isDisplayed();
				verifybiZUpdate.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				nameElement.sendKeys("Super Zone 2");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement superZone2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Super Zone 2 is :')]"));
				if(superZone2.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				verifybiZUpdate.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Super Zone 2:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Super Zone 2 is :')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level Super Zone 2 has achieved')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Super Zone 2')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Super Zone 2 is:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Super Zone 2:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Super Zone 2 is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 Defence has witnessed applied Business growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 has witnessed case size growth of')]")).isDisplayed();				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Super Zone 2 is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Super Zone 2 is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Super Zone 2 is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Super Zone 2')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Super Zone 2 is')]")).isDisplayed();							
	   }		
	}
	@Test
	public void AxisRegionAndKeyMarketAutomation() throws InterruptedException
	{	driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("close");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("hvhom1028");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("1111");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		if(hiHarsh.isDisplayed()==true && howCanIHelp.isDisplayed())
		{
				Assert.assertTrue(true);
			}
			else
			{
				Assert.assertTrue(false);
			}
			
			//First KPI- BIG Update starts Here
			
			WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
			if(verifybiZUpdate.isDisplayed()==true)
			{
				Assert.assertTrue(true);
				verifybiZUpdate.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement channel = driver.findElement(By.xpath("//p[contains(text(),'the Business update for MLI is')]"));
				if(channel.isDisplayed()==true)
				{
					Assert.assertTrue(true);
					System.out.println("Channel is displayed and verified");
				}
				else
				{
					Assert.assertTrue(false);
					System.out.println("channel is not displayed or verified");
				}
				
				WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
				
				//First Channel starts here
				nameElement.sendKeys("Axis");
				WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for AXIS is :')]"));
				if(channelData.isDisplayed()==true)
				{
					Assert.assertTrue(true);
					System.out.println("Sub Channel is data is displayed and verified");
				}
				else
				{
					Assert.assertTrue(false);
					System.out.println("Sub channel is not displayed");
				}
				nameElement.sendKeys("East Region");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement eastRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for East Region is :')]"));
				if(eastRegion.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				nameElement.sendKeys("west Region");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement westRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for West Region is :')]"));
				if(westRegion.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				nameElement.sendKeys("North Region");
				sendButton.click();
				WebElement northRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]"));
				if(northRegion.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				nameElement.sendKeys("East Region");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				boolean eastRegionAppliedBusiness = driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For East Region:')]")).isDisplayed();
				if(eastRegionAppliedBusiness==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Biz Update']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the Business update for East Region is :')]")).isDisplayed();	
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for East Region is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level East Region has achieved')]")).isDisplayed();			
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'East Region has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'East Region Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for East Region is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for East Region is:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For East Region:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for East Region is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'East Region Axis Bank has witnessed applied Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'East Region has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'East Region Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'East Region Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'East Region has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for East Region is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for East Region is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for East Region is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for East Region')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for East Region is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				verifybiZUpdate.click();
				nameElement.sendKeys("West Region");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				boolean westRegionAppliedBusiness = driver.findElement(By.xpath("//p[contains(text(),'the Business update for West Region is :')]")).isDisplayed();
				if(westRegionAppliedBusiness==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Biz Update']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the Business update for West Region is :')]")).isDisplayed();	
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for West Region is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level West Region has achieved')]")).isDisplayed();			
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'West Region has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'West Region Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for West Region is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for West Region is:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For West Region:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for West Region is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'West Region Axis Bank has witnessed applied Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'West Region has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'West Region Case Size acheivement MTD:')]")).isDisplayed();
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'West Region Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'West Region has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for West Region is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for West Region is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for West Region is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for West Region')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for West Region is')]")).isDisplayed();
				verifybiZUpdate.click();
				nameElement.sendKeys("North Region");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				boolean northRegionAppliedBusiness = driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]")).isDisplayed();
				if(northRegionAppliedBusiness==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Biz Update']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level North Region has achieved')]")).isDisplayed();			
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'North Region has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'North Region Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for North Region is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for North Region is:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For North Region:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for North Region is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'North Region Axis Bank has witnessed applied Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'North Region has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'North Region Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'North Region Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'North Region has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for North Region is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for North Region is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for North Region is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for North Region')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for North Region is')]")).isDisplayed();
				verifybiZUpdate.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				nameElement.sendKeys("South Region");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				boolean southsRegionAppliedBusiness = driver.findElement(By.xpath("//p[contains(text(),'the Business update for South Region is :')]")).isDisplayed();
				if(southsRegionAppliedBusiness==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Biz Update']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the Business update for South Region is :')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for South Region is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level South Region has achieved')]")).isDisplayed();			
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'South Region has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'South Region Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for South Region is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for South Region is:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For South Region:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for South Region is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'South Region Axis Bank has witnessed applied Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'South Region has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'South Region Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'South Region Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'South Region has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for South Region is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for South Region is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for South Region is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for South Region')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for South Region is')]")).isDisplayed();
				// Key Market Scripts		
				verifybiZUpdate.click();
				nameElement.sendKeys("Axis");
				WebElement sendButton1 = driver.findElement(By.xpath("//img[@class='send']"));
				sendButton1.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement channelData1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for AXIS is :')]"));
				if(channelData1.isDisplayed()==true)
				{
					Assert.assertTrue(true);
					System.out.println("Sub Channel is data is displayed and verified");
				}
				else
				{
					Assert.assertTrue(false);
					System.out.println("Sub channel is not displayed");
				}
				//Sub Channel starts here
				nameElement.sendKeys("East Region");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement eastRegion1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for East Region is :')]"));
				if(eastRegion1.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				nameElement.sendKeys("East");
				sendButton.click();
				WebElement eastZone = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone east is :')]"));
				if(eastZone.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				nameElement.sendKeys("KM Kolkata");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement KMKolkata = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Kolkata is :')]"));
				if(KMKolkata.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Biz Update']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Kolkata is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Kolkata is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Kolkata has achieved')]")).isDisplayed();			
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Kolkata is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Kolkata is:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Kolkata:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Kolkata is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata Axis Bank has witnessed applied Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Kolkata is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Kolkata is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Kolkata is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Kolkata')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				Thread.sleep(2000);
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Kolkata is')]")).isDisplayed();
				verifybiZUpdate.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				nameElement.sendKeys("KM West Bengal");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement KMWestBengal = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM West Bengal is :')]"));
				if(KMWestBengal.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				verifybiZUpdate.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Biz Update']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM West Bengal is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM West Bengal is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM West Bengal has achieved')]")).isDisplayed();			
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM West Bengal is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM West Bengal is:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM West Bengal:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM West Bengal is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal Axis Bank has witnessed applied Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM West Bengal is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM West Bengal is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM West Bengal is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM West Bengal')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM West Bengal is')]")).isDisplayed();
				verifybiZUpdate.click();
				nameElement.sendKeys("west Region");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement westRegion1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for West Region is :')]"));
				if(westRegion1.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				
				nameElement.sendKeys("KM Mumbai");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement KMMumbai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Mumbai is :')]"));
				if(KMMumbai.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Biz Update']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Mumbai is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Mumbai is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Mumbai has achieved')]")).isDisplayed();			
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Mumbai is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Mumbai is:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Mumbai:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Mumbai is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai Axis Bank has witnessed applied Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Mumbai is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Mumbai is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Mumbai is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Mumbai')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Mumbai is')]")).isDisplayed();
				verifybiZUpdate.click();
				nameElement.sendKeys("North Region");
				sendButton.click();
				Thread.sleep(2000);
				WebElement northRegion1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]"));
				if(northRegion1.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				
				nameElement.sendKeys("North 1");
				sendButton.click();
				Thread.sleep(2000);
				WebElement north1Zone = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 1 is :')]"));
				if(north1Zone.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				
				nameElement.sendKeys("KM Delhi1");
				sendButton.click();
				Thread.sleep(2000);
				WebElement KMDelhi1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Delhi 1 is :')]"));
				if(KMDelhi1.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Biz Update']")).click();
				driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Delhi 1 is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Delhi 1 is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Delhi 1 has achieved')]")).isDisplayed();			
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Delhi 1 is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Delhi 1 is:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Delhi 1:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Delhi 1 is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 Axis Bank has witnessed applied Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Delhi 1 is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Delhi 1 is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Delhi 1 is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Delhi 1')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				Thread.sleep(2000);
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Delhi 1 is')]")).isDisplayed();
				verifybiZUpdate.click();
				nameElement.sendKeys("North 2");
				sendButton.click();
				Thread.sleep(2000);
				WebElement north2Zone = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 2 is :')]"));
				if(north2Zone.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				
				nameElement.sendKeys("KM Punjab");
				sendButton.click();
				Thread.sleep(2000);
				WebElement KMPunjab = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Punjab is :')]"));
				if(KMPunjab.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Biz Update']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Punjab is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Punjab is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Punjab has achieved')]")).isDisplayed();			
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Punjab has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Punjab Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Punjab is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Punjab is:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Punjab:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Punjab is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Punjab Axis Bank has witnessed applied Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Punjab has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Punjab Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Punjab Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Punjab has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Punjab is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Punjab is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Punjab is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Punjab')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Punjab is')]")).isDisplayed();
				verifybiZUpdate.click();
				nameElement.sendKeys("South Region");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement southRegion1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for South Region is :')]"));
				if(southRegion1.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				
				nameElement.sendKeys("South 1");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement south1Zone = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 1 is :')]"));
				if(south1Zone.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				
				nameElement.sendKeys("KM Bangalore");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement KMBangalore = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Bangalore is :')]"));
				if(KMBangalore.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Biz Update']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Bangalore is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Bangalore is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Bangalore has achieved')]")).isDisplayed();			
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Bangalore is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);				
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Bangalore is:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Bangalore:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Bangalore is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore Axis Bank has witnessed applied Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore has witnessed paid cases growth of')]")).isDisplayed();
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Bangalore is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Bangalore is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Bangalore is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Bangalore')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Bangalore is')]")).isDisplayed();
				verifybiZUpdate.click();
				nameElement.sendKeys("South 2");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement southZone2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 2 is :')]"));
				if(southZone2.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				
				nameElement.sendKeys("KM Chennai");
				sendButton.click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				WebElement KMChennai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Chennai is :')]"));
				if(KMChennai.isDisplayed()==true)
				{
					Assert.assertTrue(true);
				}
				else
				{
					Assert.assertTrue(false);
				}
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Biz Update']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Chennai is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Chennai is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='wip']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Current WIP as ')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Chennai has achieved')]")).isDisplayed();			
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='growth']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Chennai has witnessed paid Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Chennai Protection Penetration is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[@data-value='nop']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Chennai is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);		
				driver.findElement(By.xpath("//a[@data-value='protection']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Chennai is:')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Chennai:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Chennai is')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Chennai Axis Bank has witnessed applied Business growth of')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Chennai has witnessed paid cases growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Chennai Case Size acheivement MTD:')]")).isDisplayed();
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Chennai Case Size acheivement MTD:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'KM Chennai has witnessed case size growth of')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Chennai is Annual:')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Chennai is')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Chennai is :')]")).isDisplayed();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Chennai')]")).isDisplayed();				
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
				driver.findElement(By.xpath("//img[@class='send']")).click();
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Chennai is')]")).isDisplayed();		
			}
		}
	
	@AfterClass
	public void postCondition() {
		driver.quit();
	}
	
}


