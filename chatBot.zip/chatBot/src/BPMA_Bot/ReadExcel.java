package BPMA_Bot;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ReadExcel {
	String filePath = "E:\\chatBot\\ExcelData\\Zone & Regions.xlsx";
	
	public void readExcelData(String rowNum, String coloumnNum) throws IOException
	{
		FileInputStream fis= new FileInputStream(new File(filePath));

		
		
	}
	

}
