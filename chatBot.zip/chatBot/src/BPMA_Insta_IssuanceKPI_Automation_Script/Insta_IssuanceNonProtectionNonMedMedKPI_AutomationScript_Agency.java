package BPMA_Insta_IssuanceKPI_Automation_Script;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Insta_IssuanceNonProtectionNonMedMedKPI_AutomationScript_Agency {
WebDriver driver;
    
	@BeforeClass
	public void PreCondition() throws InterruptedException
	{	
		System.setProperty("webdriver.chrome.driver", "E:\\chatBot\\exeFolder\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.navigate().to("https://botuat.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=hvhom1028&key3=IOS&key4=eapp");
		driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Thread.sleep(4000);
	}
	
	@Test(priority=1, enabled=true)
	public void InstaIssuanceKPIResponseforchannelAgency() throws InterruptedException
	{
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance Med");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceForMLI = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for MLI is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') "
						+ "and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :')]"));		
		if (InstaIssuanceForMLI.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		WebElement InstaIssuanceFTDForMLI = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for MLI is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') "
						+ "and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :')]"));		
		if (InstaIssuanceFTDForMLI.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDForMLI = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for MLI is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') "
						+ "and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :')]"));		
		if (InstaIssuanceYTDForMLI.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') "
						+ "and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') "
						+ "and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') "
						+ "and contains(text(),'Insta-Issuance 6hrs :') and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=2, enabled=true)
	public void InstaIssuanceKPIResponseforAllSubChannels() throws InterruptedException
	{
		Thread.sleep(4000);
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		Thread.sleep(2000);
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance Med");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("OWO");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForOWOSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Office within Office is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForOWOSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Office within Office is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForOWOSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Office within Office is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Greenfield");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForGreenfieldSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Greenfield is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGreenfieldSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForGreenfieldSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Greenfield is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDResponseForGreenfieldSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForGreenfieldSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Greenfield is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGreenfieldSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("APC");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForAPCSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for APC is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForAPCSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForAPCSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for APC is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDResponseForAPCSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForAPCSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for APC is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForAPCSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Defence");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForDefenceSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Defence is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForDefenceSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForDefenceSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Defence is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDResponseForDefenceSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForDefenceSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Defence is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForDefenceSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}	
	}
	
	@Test(priority=3, enabled=true)
	public void InstaIssuanceKPIResponseforAllSUperZones() throws InterruptedException
	{
		Thread.sleep(4000);
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		Thread.sleep(2000);
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance Med");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("OWO");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForOWOSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Office within Office is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForOWOSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("APC");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForAPCSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for APC is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForAPCSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSubchannelAPCAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelAPCAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForSubchannelAPCAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDResponseForSubchannelAPCAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForSubchannelAPCAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelAPCAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Defence");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForDefenceSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Defence is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForDefenceSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForSubchannelDefenceAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med) FTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelDefenceAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForSubchannelDefenceAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDResponseForSubchannelDefenceAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSubchannelDefenceAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelDefenceAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Greenfield");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForGreenfieldSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Greenfield is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGreenfieldSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForSubchannelGreenfieldAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelGreenfieldAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForSubchannelGreenfieldAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDResponseForSubchannelGreenfieldAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSubchannelGreenfieldAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelGreenfieldAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("OWO");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		if (InstaIssuanceMTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDResponseForSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForOWOSubchanne2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOWOSubchanne2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("APC");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		if (InstaIssuanceFTDResponseForAPCSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSubchannelAPCAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelAPCAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForSubchannelAPCAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDResponseForSubchannelAPCAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForSubchannelAPCAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelAPCAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Defence");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		if (InstaIssuanceFTDResponseForDefenceSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForSubchannelDefenceAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelDefenceAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForSubchannelDefenceAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSubchannelDefenceAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSubchannelDefenceAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelDefenceAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Greenfield");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		if (InstaIssuanceFTDResponseForGreenfieldSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForSubchannelGreenfieldAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelGreenfieldAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForSubchannelGreenfieldAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSubchannelGreenfieldAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSubchannelGreenfieldAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelGreenfieldAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}		
	}
	
	@Test(priority=4, enabled=true)
	public void InstaIssuanceKPIResponseforAllZones() throws InterruptedException
	{
		Thread.sleep(4000);
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		Thread.sleep(2000);
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance Med");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForwest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Zone west 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForwest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForWest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) YTD for Zone west 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDResponseForWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForwest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Zone west 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForwest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Zone North 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Zone North 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Zone North 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Zone North 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Zone North 3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Zone North 3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("east");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForEastZone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Zone east is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForEastZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForEastZone = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForEastZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForEastZone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Zone east is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForEastZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		if (InstaIssuanceMTDResponseForEastZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Zone west 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Zone west 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Zone west 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		if (InstaIssuanceMTDResponseForWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("south");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSouthZone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Zone south is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSouthZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForSouthZone = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSouthZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForSouthZone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Zone south is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSouthZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		if (InstaIssuanceMTDResponseForSouthZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("south 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDResponseForSouth2Zone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Zone south 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSouth2Zone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDResponseForSouth2Zone = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSouth2Zone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForSouth2Zone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) FTD for Zone south 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSouth2Zone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		if (InstaIssuanceMTDResponseForSouth2Zone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
		
	@Test(priority=5, enabled=true)
	public void InstaIssuanceKPIResponseforAllRegions() throws InterruptedException
	{
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForwest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone west 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForwest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest3 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest4 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone North 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for REGION NORTH1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for REGION NORTH1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth4 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone North 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth5 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North6");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth6 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North7");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth7 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North8");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth8 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North8 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth8 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth8 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North8 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone north 3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North9");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth9 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North9 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth9 = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth9.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth9 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North9 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth9.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth9.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 4");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
//		Thread.sleep(1000);
//		WebElement InstaIssuanceMTDResponseForNorth4 = driver.findElement(By.xpath
//				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone North 4 is:') "
//						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
//						+ "and contains(text(),'Insta-Issuance 12hrs :') "
//						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
//		if (InstaIssuanceMTDResponseForNorth4.isDisplayed() == true) 
//		{
//			Assert.assertTrue(true);
//		}
//		else 
//		{
//			Assert.assertTrue(false);
//		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North10");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth10 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North10 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth10.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth10 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth10.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth10 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North10 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth10.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth10.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("east");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForEast = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone east is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForEast.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region East 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionEast1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for REGION EAST 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionEast1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionEast1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionEast1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionEast1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for REGION EAST 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionEast1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionEast1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region East2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionEast2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region East2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionEast2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionEast2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionEast2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionEast2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region East2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionEast2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionEast2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone west 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest5= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest5 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West6");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest6 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		WebElement InstaIssuanceFTDResponseForRegionWest6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West7");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest7 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West8");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest8 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West8 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest8 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest8 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West8 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("south");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSouth = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone south is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSouth.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for REGION SOUTH 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for REGION SOUTH 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth2= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth3= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth3 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("south2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSouth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone south 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth4= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth4 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth5= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth5 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South6");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth6= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth6 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South7");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth7= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth7 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}	
	}
	@Test(priority=6, enabled=true)
	public void InstaIssuanceKPIResponseforAllGOs() throws InterruptedException
	{
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForwest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Zone west 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForwest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Region West1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AAHM4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOABRU1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med & Med) MTD for Office AAHM4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOABRU1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
		
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOABRU1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOABRU1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOABRU1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med & Med & Med) FTD for Office ABRU1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOABRU1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOABRU1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
		
	}
	
		@AfterClass
		public void PostConditions()
		{
			//driver.quit();
		}
}
