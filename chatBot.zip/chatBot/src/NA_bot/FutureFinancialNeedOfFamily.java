package NA_bot;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Spliterator;
import java.util.concurrent.TimeUnit;

import javax.security.auth.callback.ChoiceCallback;
import javax.swing.text.ChangedCharSetException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.seleniumhq.jetty9.security.authentication.SpnegoAuthenticator;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.internal.junit.ArrayAsserts;

import okio.Timeout;
import screenshot.ScreenShot;

public class FutureFinancialNeedOfFamily 
{
	// Global Variable
	WebDriver driver;
	String name= "Rahul";
	// PreCondition starts here

	@BeforeClass
	public void PreConditions() throws IOException {
		System.setProperty("webdriver.chrome.driver", "E:\\chatBot\\exeFolder\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://bot.maxlifeinsurance.com/need-analysis");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	// First TestCase starts here
	@Test(priority=1)
	public void verifyTextEnabled() throws IOException, InterruptedException 
	{
		try{
		Thread.sleep(1000);
		WebElement verify = driver.findElement(By.xpath("//p[contains(text(),'Hi. I am ')]/span"));
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		boolean xpathDisplayed = verify.isDisplayed();
		if (xpathDisplayed == true) 
		{
			Assert.assertTrue(true, "Webelement is displayed");
			Reporter.log("Webelement is Displayed");
		} 
		else
		{
			Reporter.log("WebElement is not Displayed");
		}
	}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	// Second TestCase starts here
	@Test(priority=2)
	public void refreshButtonHitButton() throws IOException, InterruptedException {
		try{
		WebElement webelement = driver.findElement(By.xpath("//p[text()='Refresh']"));
		Thread.sleep(1000);
		boolean checkelement = webelement.isDisplayed();
		if (checkelement == true) {
			System.out.println(checkelement);
			Reporter.log("Webelement is Displayed");
		} else {
			Reporter.log("Webelement is bot Displayed");

		}
		webelement.click();
		Reporter.log("Refresh button is Displyaed and clicking on refresh button cleared data");
	}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	// Third TestCase starts here
	@Test(priority=3)
	public void verifyQuestionAsked() throws IOException, InterruptedException {
	try{
		driver.findElement(By.xpath("//p[text()='Refresh']")).click();
		Thread.sleep(1000);
		WebElement xpath = driver.findElement(By.xpath("//span[text()='top concern']"));
		boolean checkWebelement = xpath.isDisplayed();
		if (checkWebelement == true) {
			System.out.println(checkWebelement);
			Reporter.log("Webelement is Displayed and text is mateched with expected text");
		} else {
			Reporter.log("Webelement is not displayed");
		}
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	}

	// Fourth testCases starts here
	@Test(priority=4)
	public void verifyAllOptionsDisplayed() throws IOException, InterruptedException {
			try{
		driver.findElement(By.xpath("//p[text()='Refresh']")).click();
		Thread.sleep(1000);
		List<WebElement> selectAllOptions = driver.findElements(By.xpath("//p[@class='jss30 jss39 jss53']"));
		String[] text = new String[selectAllOptions.size()];
		int allLinks = selectAllOptions.size();
		if (allLinks == 5) {
			int i = 0;
			System.out.println(allLinks);
			for (WebElement e : selectAllOptions) {
				System.out.println(text[i]=e.getText());
			}
			Reporter.log("All desired links are displayed and matched");
		} else {

			Reporter.log("All links are not matched");
		}
			}
			catch (Exception e) {
				// TODO: handle exception
			}
	}

	// Fifth Test starts here
	@Test(priority=5)
	public void selectOptions() throws IOException, InterruptedException {	
		try{
		driver.findElement(By.xpath("//p[text()='Refresh']")).click();
		Thread.sleep(1000);
		WebElement xpath = driver.findElement(By.xpath("//p[text()=' Who will take care in my absence?']"));
		boolean select = xpath.isDisplayed();
		if (select == true) {
			System.out.println(select);
			Reporter.log("Webelement is displayed");
		}
		xpath.click();
		if (xpath.isEnabled() == true) {
			System.out.println("webelement is enabled");
		} else {

			System.out.println("webelement is not enable");
		}
		boolean proceedButtonIsDisplayed = driver.findElement(By.xpath("//span[text()='Proceed']")).isDisplayed();
		System.out.println("Proceed button is displayed");
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

	// Six Test starts here
	@Test(priority=6)
	public void elementNotSelectedVerify() throws InterruptedException, IOException {
		try{
		driver.findElement(By.xpath("//p[text()='Refresh']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[text()=' Who will take care in my absence?']")).click();
		WebElement element = driver.findElement(By.xpath("//span[text()='Proceed']"));
		boolean webelementIsDisable = element.isEnabled();
		if (webelementIsDisable == false) {
			System.err.println("webelement is disable due to webelement is not selected");
		} else {
			System.out.println("Element is visable and selected");
		}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		}


	// Seven Test starts here
	@Test(priority=7)
	public void verifyQuestion() throws InterruptedException, IOException {
		try{
		Thread.sleep(1000);
		driver.findElement(By.xpath("//p[text()='Refresh']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement element = driver.findElement(By.xpath("//span[text()='future financial needs of family']"));
		if (element.isDisplayed() == true) {
			System.out.println("Webelement is displayed and verified");
			driver.findElement(By.xpath("//p[text()=' Who will take care in my absence?']")).click();

		} else {
			System.out.println("Webelement is not visible");
		}

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		String waitforelement = "//span[contains(text(),'Proceed')]";

//		WebDriverWait wait = new WebDriverWait(driver, 30);
//		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(waitforelement)));
		driver.findElement(By.xpath(waitforelement)).click();
		WebElement verifyElement = driver.findElement(By.xpath("//p[text()=' What is your name?']"));
		boolean ele = verifyElement.isDisplayed();
		if (ele == true) {
			System.out.println("Please enter your name");
			
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys(name);
		} else {
			System.out.println("webelement could not find");
		}
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[contains(@placeholder,'Enter your value here (only in digits)...')]"))
				.isDisplayed();
		driver.findElement(By.xpath("//p[contains(text(),' How old are you, Rahul?')]")).isDisplayed();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//div[@class='chat bot col-sm-10 col-xs-10']//p")).isDisplayed();
		driver.findElement(By.xpath("//p[contains(text(),'your mobile number?')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='XXXXXXXXXX']")).sendKeys("9999999999");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean verifyWebElement = driver.findElement(By.xpath("//p[text()=' What is your current annual income?']"))
				.isDisplayed();
		if (verifyWebElement == true) {
			Reporter.log("Curent Annual Income is Displayed and verified");
		} else {
			Reporter.log("Curent Annual Income is not verified");
		}
		boolean defaultIncome = driver.findElement(By.xpath("//input[@value='100000']")).isDisplayed();
		if (defaultIncome == true) {
			Reporter.log("Default income is Displayed as 100000");
		}

		else {

			Reporter.log("Default amount is not as 100000");
		}

		driver.findElement(By.xpath("//img[@class='send']")).click();
		boolean costOfGoal = driver
				.findElement(By
						.xpath("//p[contains(text(),' How much do you need to save for future goals (Buy home, Car, ')]"))
				.isDisplayed();
		boolean defaultCostOfGoal = driver.findElement(By.xpath("//input[@value='100000']")).isDisplayed();
		if (costOfGoal == true && defaultCostOfGoal == true) {
			Reporter.log("Cost of Goal and Defalut cost of goal is Displayed and both verfied");
		} else {
			Reporter.log("Default cost of Goal or Cost of Goal is not verified");
		}
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean elementDisplayed = driver.findElement(By.xpath("//p[text()=' What is your current monthly expense?']"))
				.isDisplayed();
		if (elementDisplayed == true) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "What is your currently income webelement is not displayed");
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//img[@class='send']")).click();
		boolean checkDisplay = driver.findElement(By.xpath("//p[text()=' How much savings have you done till now?']"))
				.isDisplayed();
		if (checkDisplay == true) {
			Assert.assertTrue(true, "How much saving have you done text is displayed");
		} else {
			Assert.assertTrue(false, "Webelement is not displayed");
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement loanAmonut = driver
				.findElement(By.xpath("//p[contains(text(),'What is the total amount of all loans you have taken currently?')]"));
		if (loanAmonut.isDisplayed() == true) {
			Assert.assertTrue(true, "Webelement is displayed");
		} else {
			Assert.assertTrue(false, "Webelement is not displayed");
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//img[@class='send']")).click();
		boolean labelIsDisplayed = driver.findElement(By.xpath("//p[@id='label' and text()='Life Insurance Amount' ]"))
				.isDisplayed();
		if (labelIsDisplayed == true) {
			Assert.assertTrue(true, "Life Insurance Ammount label is displayed");
		} else {
			Assert.assertFalse(true, "Life Insurance Amount is not displayed");
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean checkElementPresent = driver
				.findElement(By
						.xpath("//p[contains(text(),' Inflation rate, which will impact savings, should be (8%). Do you want to edit this?')]"))
				.isDisplayed();
		if (checkElementPresent == true)
		{
			Assert.assertTrue(true, "Webelement is present");
		} else {

			Assert.assertFalse(false);
		}
		List<WebElement> listOfWebelements = driver
				.findElements(By.xpath("//ul[@class='list-inline']//span[2]"));
		String[] elements = new String[listOfWebelements.size()];
		int listSize = listOfWebelements.size();
		int i = 0;
		if (listSize == 2) 
		{
			for (WebElement e : listOfWebelements)
			{
				System.out.println(elements[i] = e.getText());
			}
		}
		 WebElement verifyElementPresent = driver
				.findElement(By
						.xpath("//ul[@class='list-inline']//span[text()='No']"));
		if (verifyElementPresent.isDisplayed() == true) {
			Assert.assertTrue(true, "Webelement is present and verified");
		} else {
			Assert.assertTrue(false, "Web element is not present");
		}
		verifyElementPresent.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement rateOfReturn = driver.findElement(
				By.xpath("//p[text()=' Rate of return on your money should be (8%). Do you want to edit this?']"));
		if (rateOfReturn.isDisplayed() == true) {
			Assert.assertTrue(true, "Rate of Interest text is displayed");
		}
		else
		{
			Assert.assertTrue(false, "Rate of Interest text is not displayed");
		}
		Thread.sleep(1000);
		driver.findElement(
				By.xpath("//ul[@class='list-inline']//span[text()='No']"))
				.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean webelementDisplay = driver.findElement(By.xpath("//p[starts-with(text(),'Thank you "+name+"')]")).isDisplayed();
		boolean checkWebelemtPresent = driver.findElement(By.xpath("//p[text()=' Here is your personalised financial summary.']")).isDisplayed();
		if(webelementDisplay==true && checkWebelemtPresent==true){
			Assert.assertTrue(true, "Webelement is present");
		}
		else{
			Assert.assertFalse(true, "Webelement is not present");
		}
		List<WebElement> storeListOfWebelement = driver.findElements(By.xpath("//div[@class='protect']//div"));
		String[] store = new String[storeListOfWebelement.size()];
		int size= storeListOfWebelement.size();
		if(size==3)
		{
			for(WebElement e:storeListOfWebelement ){
				System.out.println(store[i]=e.getText());
			}
			
		}
		WebElement seePlanElement = driver.findElement(By.xpath("//div[text()='SEE PLAN']"));
		seePlanElement.click();
		boolean thankYouDisplay = driver.findElement(By.xpath("//p[contains(text(),'Thank you ')]")).isDisplayed();
		boolean personalizedDetailedElement = driver.findElement(By.xpath("//p[contains(text(),' Here is your personalised financial summary.')]")).isDisplayed();
		if(thankYouDisplay==true && personalizedDetailedElement==true)
		{
			Assert.assertTrue(true, "Webelement is disaplayed and verified");
		}
		else
		{
			Assert.assertTrue(false, "webelement is not verified");
		}
		 List<WebElement> onlineTermPlanPlus = driver.findElements(By.xpath("//div[@class='benefits']//div//*"));
		  int listSizeOfOnlineTermOlan = onlineTermPlanPlus.size();
		 String saveAllListData[] = new String[listSizeOfOnlineTermOlan];
		if(listSizeOfOnlineTermOlan==7)
		{
			int j=0;
			for(WebElement e: onlineTermPlanPlus){
				System.out.println(saveAllListData[j]=e.getText());
			}
		}
		else
		{
			Assert.assertTrue(false, "Loop terminated");
		}
		
		WebElement getQuoteElement = driver.findElement(By.xpath("//p[text()='GET QUOTE']"));
		if(getQuoteElement.isDisplayed()==true)
		{
			Assert.assertTrue(true, "Webelement is verified");
		}
		else
		{
			Assert.assertTrue(false, "Element is not verified");
		}
		Thread.sleep(1000);
		getQuoteElement.click();
		
		 WebElement emailIDElement = driver.findElement(By.xpath("//input[@placeholder='example@gmail.com']"));
		 emailIDElement.sendKeys("abcd@gmail.com");
		 Thread.sleep(1000);
		 driver.findElement(By.xpath("//*//p[text()='Send']")).click();
		 ArrayList<String> list = new ArrayList<String>(driver.getWindowHandles());
		 driver.switchTo().window(list.get(0));
		 boolean thankYouElement = driver.findElement(By.xpath("//p[text()='Thank you Rahul. We have sent the financial summary to your email address.']")).isDisplayed();
		 WebElement startANewJourny = driver.findElement(By.xpath("//span[text()='Start a new journey']"));
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 if(thankYouElement ==true && startANewJourny.isDisplayed()==true){
			Assert.assertTrue(true, "Element is verified");
		}
		else{
			Assert.assertTrue(false, "Webelement is not verified");
		}
		 
		Thread.sleep(1000);
		startANewJourny.click(); 	
	}
		catch (Exception e) {
			// TODO: handle exception
		}}
	

	@AfterClass
	public void postCondition() 
	{
		driver.quit();
	}
}

