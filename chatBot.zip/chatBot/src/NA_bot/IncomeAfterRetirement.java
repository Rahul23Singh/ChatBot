package NA_bot;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import screenshot.ScreenShot;

public class IncomeAfterRetirement {

	public WebDriver driver;
	String name = "Abcd";

	@BeforeClass
	
	public void PreConditions() throws IOException {
	
			System.setProperty("webdriver.chrome.driver", "E:\\chatBot\\exeFolder\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get("https://bot.maxlifeinsurance.com/need-analysis");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	@Test
	public void verifyFifthTab() throws IOException, InterruptedException {
		try{
		//	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			Thread.sleep(2000);
			WebElement storeElement = driver.findElement(By.xpath("//span[text()='future financial needs of family']"));
			WebElement check = driver.findElement(By.xpath("//span[text()='income after retirement']"));
			boolean checkRetirementElement = check.isDisplayed();
			if (storeElement.isDisplayed() == true && checkRetirementElement==true) 
			{
				Assert.assertTrue(true, "Element is displayed");
			} 
			else
			{
				Assert.assertFalse(true, "Element is not displayed");
			}
			check.click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//span[text()='Proceed']")).click();
			boolean nameIsDisplay = driver.findElement(By.xpath("//p[text()=' What is your name?']")).isDisplayed();
			if (nameIsDisplay == true) 
			{
				Assert.assertTrue(true, "Both element is displayed");
			}
			else
			{
				Assert.assertFalse(true, "one of the webelement is not verified or both");
			}
					
			driver.findElement(By.xpath("//input[@placeholder='Write here....']")).sendKeys(name);	
			Thread.sleep(1000);
			driver.findElement(By.xpath("//img[@class='send']")).click();
			boolean verfiName = driver.findElement(By.xpath("//p[contains(text(),' How old are you,')]")).isDisplayed();
			boolean defaultAge = driver.findElement(By.xpath("//input[@value='30']")).isDisplayed();
			if (verfiName == true && defaultAge == true) 
			{
				Assert.assertTrue(true, "What is your name and default Age is verified");
			} 
			else 
			{
				Assert.assertFalse(true, "One of thr webelement is not displayed or may be both");
			}
			driver.findElement(By.xpath("//img[@class='send']")).click();
			boolean verifyMobile = driver.findElement(By.xpath("//p[contains(text(),'your mobile number?')]"))
					.isDisplayed();
			if (verifyMobile == true) 
			{
				Assert.assertTrue(true, "Element is displayed");
			}
			else
			{
				Assert.assertTrue(false, "Webelement is not displayed");
			}
			driver.findElement(By.xpath("//input[@placeholder='XXXXXXXXXX']")).sendKeys("9999999999");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			boolean verifyRetirement = driver
					.findElement(By.xpath("//p[contains(text(),'When do you plan to retire?')]")).isDisplayed();
			if (verifyRetirement == true)
			{
				Assert.assertTrue(true, "Retirement text is verified");
			}
			else
			{
				Assert.assertFalse(true, "Retirement text is not verified");
			}

			List<WebElement> RetirementDefaultAge = driver.findElements(By.xpath("//div[@class='postLabel']//p"));
			int count = RetirementDefaultAge.size();
			String saveListElement[] = new String[count];
			if (count == 2)
			{
				int i = 0;
				for (WebElement e : RetirementDefaultAge)
				{
					System.out.println(saveListElement[i] = e.getText());
				}
			}
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.findElement(By.xpath("//input[@placeholder='Enter your value here (only in digits)...']"))
					.sendKeys("100000");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			boolean verfiySaving = driver
					.findElement(By.xpath("//p[text()=' How much savings have you done till now, for retirement?']"))
					.isDisplayed();
			boolean verfiyDefaultAmount = driver.findElement(By.xpath("//input[@value='1000000']")).isDisplayed();
			if (verfiyDefaultAmount == true && verifyRetirement == true) 
			{
				Assert.assertTrue(true, "Element is Displayed");
			}
			else
			{
				Assert.assertTrue(false, "Element either not exit or not verified");
			}
			driver.findElement(By.xpath("//img[@class='send']")).click();
			boolean verfiyCurrentlyExpense = driver
					.findElement(By.xpath("//p[text()=' What is your current monthly expense?']")).isDisplayed();
			boolean verfiyDefaultMonthlyAmount = driver.findElement(By.xpath("//input[@value='500000']")).isDisplayed();
			if (verfiyCurrentlyExpense == true && verfiyDefaultMonthlyAmount == true) 
			{
				Assert.assertTrue(true, "Webelement is verified");
			}
			else
			{
				Assert.assertFalse(true, "Webelement is not verified");
			}
			Thread.sleep(1000);
			driver.findElement(By.xpath("//img[@class='send']")).click();
			boolean verifyCurrentMontthExpense = driver
					.findElement(By
							.xpath("//p[text()=' How much %age of your current monthly expense will continue after retirement?']"))
					.isDisplayed();
			boolean verifyDefaultcurrentAgePercentage = driver.findElement(By.xpath("//input[@value='50']"))
					.isDisplayed();
			if (verifyCurrentMontthExpense == true && verifyDefaultcurrentAgePercentage == true)
			{
				Assert.assertTrue(true, "Both webelement is verified");
			}
			else
			{
				Assert.assertTrue(false, "Either webelement is not present or not verified");
			}
			Thread.sleep(2000);
			driver.findElement(By.xpath("//img[@class='send']")).click();
			boolean verifyInflationRAte = driver
					.findElement(By
							.xpath("//p[text()=' Inflation rate, which will impact your retirement funds, should be (8%), Do you want to edit this?']"))
					.isDisplayed();
			Thread.sleep(2000);
			if (verifyInflationRAte == true) 
			{
				Assert.assertTrue(true, "Inflation rate is verified");
			}
			else 
			{
				Assert.assertTrue(false, "Inflation rate is not verfied");
			}
			List<WebElement> listOfButtons = driver.findElements(By.xpath("//ul[@class='list-inline']/button"));
			int countOfButton = listOfButtons.size();
			String storeElementOfButton[] = new String[countOfButton];
			if (countOfButton == 2) 
			{
				int i = 0;
				for (WebElement e : listOfButtons) 
				{
					System.out.println(storeElementOfButton[i] = e.getText());
				}
			} 
			else 
			{
				Assert.assertFalse(true, "Condition failed and loop could not continued");
			}
			driver.findElement(By.xpath("//span[text()='No']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//span[text()='No']")).click();
			List<WebElement> riskElements = driver.findElements(By.xpath("//ul[@class='list-inline']//span[text()]"));
			int size = riskElements.size();
			String riskSize[] = new String[size];
			if (size == 3) 
			{
				int i = 0;
				for (WebElement e : riskElements) {
					System.out.println(riskSize[i] = e.getText());
				}

			}
			else
			{
				Assert.assertTrue(false, "Loop terminated");
			}

			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//ul[@class='list-inline']//span[text()]")).click();
			boolean verifyThankYouText = driver.findElement(By.xpath("//p[contains(text(),'Thank you ')]"))
					.isDisplayed();
			boolean verifySummary = driver
					.findElement(By.xpath("//p[contains(text(),' Here is your personalised financial summary.')]"))
					.isDisplayed();
			if (verifyThankYouText == true && verifySummary == true) 
			{
				Assert.assertTrue(true, "Thank you text is verified");
			}
			else
			{
				Assert.assertTrue(false, "Thank you text is not verfied");
			}
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

			List<WebElement> verifyResult = driver.findElements(By.xpath("//div[@class='nameAndMonth']//span"));
			int counts = verifyResult.size();
			String showCounts[] = new String[counts];
			if (counts == 5)
			{
				int i = 0;
				for (WebElement e : verifyResult) {
					System.out.println(showCounts[i] = e.getText());
				}
			}
			else
			{
				Assert.assertTrue(false, "Result count not displayed");
			}
			boolean detailsElement = driver.findElement(By.xpath("//div[text()='Details']")).isDisplayed();
			WebElement seeDetailsElement = driver.findElement(By.xpath("//div[@class='seePlanBtn']"));
			if(detailsElement==true && seeDetailsElement.isDisplayed()==true){
				Assert.assertTrue(true, "Both webelement is verified");
			}
			else{
				Assert.assertFalse(true, "One or both Webelement is not displayed");
			}
			Thread.sleep(1000);
			seeDetailsElement.click();
			List<WebElement> seeDetailsAllElements = driver.findElements(By.xpath("//div[@class='chat bot productdetail']//div//p"));
			int findSize = seeDetailsAllElements.size();
			String storeSeeDetailsAllElements[] =new String[findSize]; 
			if(findSize==5){
				int i=0;
				for(WebElement e: seeDetailsAllElements){
					System.out.println(storeSeeDetailsAllElements[i]= e.getText());
				}
			}
			else{
				Assert.assertTrue(false, "Guranteed income plan has not been verified");
			}
			WebElement knowMoreElement = driver.findElement(By.xpath("//a[text()='Know More']"));
			WebElement getACall = driver.findElement(By.xpath("//p[text()='Get A Call']"));
			if(knowMoreElement.isDisplayed()==true && getACall.isDisplayed()==true){
				Assert.assertTrue(true, "Knonw More and Get A Call webelement is verified");
			}
			else
			{
				Assert.assertTrue(false, "Knonw More and Get A Call webelement is not verified");
			}
			Thread.sleep(2000);
			getACall.click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			WebElement shareEmail = driver.findElement(By.xpath("//p[contains(text(),'Please share your Email id and press send to receive a detailed copy of your financial needs analysis result')]"));
			if(shareEmail.isDisplayed()==true){
				Assert.assertTrue(true, "Webelement is displayed and verified");
			}
			else
			{
			Assert.assertTrue(false, "Webelement is not displayed");	
			}	
			WebElement emailIDElement = driver.findElement(By.xpath("//input[@placeholder='example@gmail.com']"));
			emailIDElement.sendKeys("abcd@gmail.com");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*//p[text()='Send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 boolean thankYouElement = driver.findElement(By.xpath("//*//p[text()='Thank you Abcd. We have sent the financial summary to your email address.']")).isDisplayed();
			 WebElement startANewJourny = driver.findElement(By.xpath("//span[text()='Start a new journey']"));
			if(thankYouElement ==true && startANewJourny.isDisplayed()==true){
				Assert.assertTrue(true, "Element is verified");
			}
			else{
				Assert.assertTrue(false, "Webelement is not verified");
			}
			Thread.sleep(2000);
			startANewJourny.click();
	}
	
	catch (Exception e) {
		// TODO: handle exception
	
	}
		}
	

	@AfterClass
	public void postCondition() {
		driver.quit();
	}
}
