package SVGBot_Lead_First;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.ScreenshotException;
import org.openqa.selenium.remote.server.handler.SendKeys;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import screenshot.ScreenShot;

public class CalculateMyTermInsurancePremimm {
	WebDriver driver;
	@BeforeClass
		public void PreConditions() throws IOException {
			System.setProperty("webdriver.chrome.driver", "./exeFolder/chromedriver.exe");
			driver = new ChromeDriver();
			driver.get("https://bot.maxlifeinsurance.com/leadfirst?source=LeadBOT&channel=34&company=Display&category=WebsiteDirect&utm_source=SVG&utm_medium=1&utm_campaign=2&utm_term=test&utm_content=test2");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			ScreenShot.getPassedScreenShot(driver, "PreConditions");
			
	}
	@Test(priority=1)
	public void verifyHeader() throws IOException
	{
		try{
		String pageTitle = driver.findElement(By.xpath("//h5[text()='Calculate my term insurance premium']")).getText();
		if(pageTitle.equalsIgnoreCase("Calculate my term insurance premium")){
			Assert.assertTrue(true, "Header is  verified");
		}
		else{
			Assert.assertFalse(false, "Header is not verified");
		}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	@Test(priority =2)
	public void greetingMessage() throws IOException{
		
		try{
			boolean greetingMessage = driver.findElement(By.xpath("//p[text()='  Hi, Thanks for showing interest in Max Life Term insurance. I am your online assistant.   ']")).isDisplayed();
		if(greetingMessage==true){
			Assert.assertTrue(true, "Greeting message is displayed");
		}
		else{
			Assert.assertTrue(false, "Greeting message is not displayed");
		}
		
	}
catch (Exception e) {
	// TODO: handle exception
}
}
	@Test(priority=3)
	public void calculateCustomizePremimum() throws InterruptedException, IOException{
		
		try{
		boolean calculatePremimum = driver.findElement(By.xpath("//p[starts-with(text(),'   I need a few details to calculate customised premium for you. Please share your ')]")).isDisplayed();
		if(calculatePremimum==true){
		Assert.assertTrue(true, "Customized premimum starts and text is verified");	
		}
		else{
			Assert.assertTrue(false, "calculate premium text is not verified");
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here....']")).sendKeys("ABCD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		boolean isDisplayed = driver.findElement(By.xpath("//p[starts-with(text(),'To know more about this term plan, please enter your ')]")).isDisplayed();
		if(isDisplayed==true){
			Assert.assertTrue(true, "Mobile number is displayed and verfied");
		}
		else{
			Assert.assertTrue(false, "Mobile number is not verified");
		}
		boolean checkboxEnabled = driver.findElement(By.xpath("//input[@checked='checked']")).isSelected();
		if(checkboxEnabled==true){
			Assert.assertTrue(true, "Checkbox is enabled and verified");
		}
		else{
			Assert.assertFalse(false,"Checkbox is not enable");
		}
		 WebElement linkIsDisplayed = driver.findElement(By.xpath("//a[@href='https://www.maxlifeinsurance.com/content/dam/neo/pdf/TermsAndConditions_Common_2017%2011%2014.pdf']"));
		 if(linkIsDisplayed.isDisplayed()==true){
			Assert.assertTrue(true, "Link is displayed");
		}
		else{
			Assert.assertTrue(false, "Link is not displayed or verified");
		}
		linkIsDisplayed.click();
		ArrayList<String> handleWindow = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(handleWindow.get(1));
		Thread.sleep(3000);
		driver.switchTo().window(handleWindow.get(0));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='XXXXXXXXXX']")).sendKeys("8802907956");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		
		//OPT Verification section
		
		WebElement OTPVerify = driver.findElement(By.xpath("//p[contains(text(),'Please enter the OTP you have received in mobile number')]"));
		if(OTPVerify.isDisplayed()==true){
			Assert.assertTrue(true);
		}
		else{
			Assert.assertTrue(false);
		}
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String OTP;   
        System.out.println("Please Enter the user OTP :: ");
        OTP= br.readLine();  
        driver.findElement(By.xpath("//input[@name='inputText']")).sendKeys(OTP);
        Thread.sleep(1000);
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(2000);
		boolean dateOfBirth = driver.findElement(By.xpath("//p[contains(text(),'Enter your date of birth in DD/MM/YYYY format')]")).isDisplayed();		
		if(dateOfBirth==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		driver.findElement(By.xpath("//div//input[@name='inputText']")).sendKeys("21");
		driver.findElement(By.xpath("//div//input[@name='inputText']")).sendKeys("10");
		driver.findElement(By.xpath("//div//input[@name='inputText']")).sendKeys("2000");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		boolean gender = driver.findElement(By.xpath("//p[contains(text(),'Please select your gender.')]")).isDisplayed();
		WebElement male = driver.findElement(By.xpath("//a[contains(text(),'Male')]"));
		if(gender==true && male.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		male.click();
		WebElement smokeAndTobaccoText = driver
				.findElement(By.xpath("//p[contains(text(),'Got it. Do you smoke or chew tobacco?')]"));
		if (smokeAndTobaccoText.isDisplayed() == true) {
			Assert.assertTrue(true, "Question is verified");
		} else {
			Assert.assertTrue(false, "Question is not verified");
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//a[contains(text(),'Yes')]")).click();
		WebElement emailVerify = driver.findElement(By.xpath("//p[text()='Please enter your email address (in abc@xyz.com format).']"));
		if(emailVerify.isDisplayed()==true){
			Assert.assertTrue(true);
		}
		else{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write text here...']")).sendKeys("rahul.singh1@qualtechedge.com");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		WebElement personalishedTextVerify = driver.findElement(By.xpath("//p[contains(text(),'Here is your personalised premium quote: .')]"));
		if(personalishedTextVerify.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		List<WebElement> printText = driver.findElements(By.xpath("//div[@class='chat bot chat-bot  col-sm-offset-10 col-xs-12' ]//p"));
		int size = printText.size();
		String getTextx[] = new String[size];
		if(size==5)
		{
			for(WebElement e:printText)
			{
				int i=0;
				System.out.println(getTextx[i] = e.getText());
			}		
		}
		else
		{
			Assert.assertFalse(true);
		}
		WebElement hrefElement = driver.findElement(By.xpath("//a[text()=' Click here ']"));
		if(hrefElement.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		hrefElement.click();
		String	expectedURL= "https://www.maxlifeinsurance.com/online-insurance-plans/online-term-plan-plus/get-quote/TCOTP";
		String actualURL = driver.getCurrentUrl();
		System.out.println(actualURL);
		Assert.assertEquals(actualURL, expectedURL, "Both URL are matcheding");
		ArrayList<String> arrayList= new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(arrayList.get(0));
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

	@AfterClass
	public void postCondition() {
		driver.quit();
	}
}
