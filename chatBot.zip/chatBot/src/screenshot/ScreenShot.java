package screenshot;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Formatter;

import javax.swing.text.DateFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenShot 
{

	public static void getPassedScreenShot(WebDriver driver, String TestCaseName) throws IOException
	
	{
		SimpleDateFormat formate=new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");
		Date date=new Date();
		String dat=formate.format(date);
		
		File file=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file,new File("E:/ChatBot ScreenShot/Passed_ScreenShot/"+TestCaseName+" "+dat+".png"));
	}
public static void getFailedScreenShot(WebDriver driver, String TestCaseName) throws IOException
	
	{
	SimpleDateFormat formate=new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");
	Date date=new Date();
	String dat=formate.format(date);
		File file=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file,new File("E:/ChatBot ScreenShot/Failed_ScreenShot/"+TestCaseName+"'_'"+dat+".png"));
	}

	
}
