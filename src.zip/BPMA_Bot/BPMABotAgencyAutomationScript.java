package BPMA_Bot;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Sleeper;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class BPMABotAgencyAutomationScript {
	WebDriver driver;
	
	@BeforeClass
	public void preConditions() throws IOException {
		System.setProperty("webdriver.chrome.driver", "D:\\Eclipse\\ChatBot\\All exe\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=hvhom1028&key3=IOS&key4=eapp");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}	
	
	@Test(priority = 1, enabled = true)
	public void AgencyMLILevelResponseForAllKPI() throws InterruptedException 
	{
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement helpWithFollowingOptions = driver
				.findElement(By.xpath("//p[contains(text(),'I can help you with following options')]"));
		if (hiHarsh.isDisplayed() == true && helpWithFollowingOptions.isDisplayed()) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		// Click on Business Number....
		WebElement BusinessNumberButton = driver.findElement(By.xpath("//a[contains(text(),'Business Numbers')]"));
		if (BusinessNumberButton.isDisplayed() == true) {
			BusinessNumberButton.click();
		} else {
			System.out.println("Business Number button is not validated/Displayed");
		}
		//WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()) 
		{
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		if (verifybiZUpdate.isDisplayed() == true) {
			Assert.assertTrue(true);
			verifybiZUpdate.click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			WebElement channel = driver.findElement(By.xpath("//p[contains(text(),'the Business update for MLI is')]"));
			if (channel.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("Channel is displayed and verified");
			} else {
				Assert.assertTrue(false);
				System.out.println("channel is not displayed or verified");
			}
		//All KPI Validation of MLI level
			driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For MLI:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for MLI is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='wip']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for MLI is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'At MTD level MLI has achieved')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='growth']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI has witnessed paid Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI Protection Penetration is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='nop']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for MLI')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='protection']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for MLI is:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For MLI:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for MLI ')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI has witnessed applied Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI has witnessed paid cases growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI has witnessed case size growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for MLI is Annual:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for MLI is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for MLI is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies MTD for MLI')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for MLI is')]")).isDisplayed();
		}
	}

	@Test(priority = 2, enabled = true)
	public void agencyChannelResponseForAllKPI() throws InterruptedException
	{
		Thread.sleep(2000);
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Agency is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}				
		//KPI validation starts here!!
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
			Thread.sleep(2000);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Agency:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Agency is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='wip']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Agency is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'At MTD level Agency has achieved')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='growth']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Agency has witnessed paid Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Agency Protection Penetration is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='nop']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Agency')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='protection']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Agency is:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Agency:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Agency ')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Agency has witnessed applied Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Agency has witnessed paid cases growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Agency channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Agency channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Agency has witnessed case size growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Agency is Annual:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Agency is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Agency is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies MTD for Agency')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Agency is')]")).isDisplayed();	
	}
	@Test(priority =3, enabled = true)
	public void SubChannelResponseForAllKPI() throws InterruptedException
	{
		Thread.sleep(2000);
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		// Enter Channel Name
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Agency is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}
		
		//Sub Channel starts here
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Defence");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement subChannelUpdate = driver.findElement(By.xpath("//p[contains(text(),'the Business update for SubChannel Defence is :')]"));
		if(subChannelUpdate.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
			Thread.sleep(2000);
			driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For SubChannel Defence:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for SubChannel Defence is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='wip']")).click();
			driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for SubChannel Defence is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'At MTD level SubChannel Defence has achieved')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='growth']")).click();
			driver.findElement(By.xpath("//p[contains(text(),'SubChannel Defence has witnessed paid Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'SubChannel Defence Protection Penetration is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='nop']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Defence')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='protection']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Defence is:')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For SubChannel Defence:')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Defence ')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Defence has witnessed applied Business growth of')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Defence has witnessed paid cases growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Defence channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Defence channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Defence has witnessed case size growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Defence is Annual:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Defence is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for SubChannel Defence is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies MTD for Defence')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Defence is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			//APC SubChannel starts here!!
			verifybiZUpdate.click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("APC");
			sendButton.click();
			WebElement APCsubChannelUpdate = driver.findElement(By.xpath("//p[contains(text(),'the Business update for SubChannel APC is :')]"));
			if(APCsubChannelUpdate.isDisplayed()==true)
			{
				Assert.assertTrue(true);
			}
			else
			{
				Assert.assertTrue(false);
			}
			driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For SubChannel APC')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for SubChannel APC is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='wip']")).click();
			driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for SubChannel APC is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'At MTD level SubChannel APC has achieved')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='growth']")).click();
			driver.findElement(By.xpath("//p[contains(text(),'SubChannel APC has witnessed paid Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'SubChannel APC Protection Penetration is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='nop']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for APC')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='protection']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for APC is:')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For SubChannel APC:')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for APC ')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'APC has witnessed applied Business growth of')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'APC has witnessed paid cases growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'APC channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'APC channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'APC has witnessed case size growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for APC is Annual:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for APC is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for SubChannel APC is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies MTD for APC')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for APC is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			//Greenfield SubChannel starts here!!
			verifybiZUpdate.click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Greenfield");
			sendButton.click();
			WebElement GreenfieldsubChannel = driver.findElement(By.xpath("//p[contains(text(),'the Business update for SubChannel Greenfield is :')]"));
			if(GreenfieldsubChannel.isDisplayed()==true)
			{
				Assert.assertTrue(true);
			}
			else
			{
				Assert.assertTrue(false);
			}
			driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For SubChannel Greenfield:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for SubChannel Greenfield is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='wip']")).click();	
			driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for SubChannel Greenfield is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'At MTD level SubChannel Greenfield has achieved')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='growth']")).click();
			driver.findElement(By.xpath("//p[contains(text(),'SubChannel Greenfield has witnessed paid Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'SubChannel Greenfield Protection Penetration is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='nop']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Greenfield')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='protection']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Greenfield is:')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For SubChannel Greenfield:')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Greenfield ')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Greenfield has witnessed applied Business growth of')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Greenfield has witnessed paid cases growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Greenfield channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Greenfield channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Greenfield has witnessed case size growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Greenfield is Annual:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Greenfield is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for SubChannel Greenfield is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies MTD for Greenfield')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Greenfield is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			//Office within Office (OWO) SubChannel starts here!!
			verifybiZUpdate.click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Office within Office");
			sendButton.click();
			WebElement OWOsubChannel = driver.findElement(By.xpath("//p[contains(text(),'the Business update for SubChannel Office within Office is :')]"));
			if(OWOsubChannel.isDisplayed()==true)
			{
				Assert.assertTrue(true);
			}
			else
			{
				Assert.assertTrue(false);
			}
			driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For SubChannel Office within Office:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for SubChannel Office within Office is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='wip']")).click();
			driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for SubChannel Office within Office is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'At MTD level SubChannel Office within Office has achieved')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='growth']")).click();
			driver.findElement(By.xpath("//p[contains(text(),'SubChannel Office within Office has witnessed paid Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'SubChannel Office within Office Protection Penetration is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='nop']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Office within Office')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='protection']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Office within Office is:')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For SubChannel Office within Office:')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Office within Office ')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Office within Office has witnessed applied Business growth of')]")).isDisplayed();
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Greenfield has witnessed paid cases growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Office within Office channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Office within Office channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Office within Office has witnessed case size growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Office within Office is Annual:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Office within Office is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for SubChannel Office within Office is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies MTD for Office within Office')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Office within Office is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				
	}		
			
	@Test(priority =4, enabled = true)
	public void AllSuperZoneResponseForAllKPI() throws InterruptedException
	{
		Thread.sleep(2000);
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		Thread.sleep(2000);
		// Enter Channel Name
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Agency is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}
		
		//Super Zone Starts here ..........!!
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement superZone1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Super Zone 1 is :')]"));
		if(superZone1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Super Zone 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Super Zone 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Super Zone 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Super Zone 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Super Zone 1')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Super Zone 1 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Super Zone 1:')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Super Zone 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Super Zone 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Super Zone 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Super Zone 1 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Super Zone 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Super Zone 1 is')]")).isDisplayed();
		verifybiZUpdate.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		sendButton.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement superZone2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Super Zone 2 is :')]"));
		if(superZone2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		verifybiZUpdate.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Super Zone 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Super Zone 2 is :')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Super Zone 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Super Zone 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 has witnessed paid Business growth of')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Super Zone 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Super Zone 2 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Super Zone 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Super Zone 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Super Zone 2 has witnessed case size growth of')]")).isDisplayed();				driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Super Zone 2 is Annual:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Super Zone 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Super Zone 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Super Zone 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Super Zone 2 is')]")).isDisplayed();
	}		
	
	@Test(priority =5, enabled = true)
	public void AllZonesResponseForAllKPI() throws InterruptedException
	{
		Thread.sleep(2000);
		
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		Thread.sleep(2000);
		// Enter Channel Name
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Agency is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}				
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement superZone1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Super Zone 1 is :')]"));
		if(superZone1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneWest1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone west 1 is :')]"));
		if(ZoneWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone west 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone west 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone west 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone west 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for west 1 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for west 1 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone west 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for west 1 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone west 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for west 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone west 1 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone west 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for west 1 Zone is')]")).isDisplayed();
	// North 1 starts here .............!!!!!!!!!!!!!!!
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneNorth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 1 is :')]"));
		if(ZoneNorth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone North 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone North 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone North 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone North 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for North 1 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for North 1 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone North 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for North 1 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone North 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for North 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone North 1 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone North 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for North 1 Zone is')]")).isDisplayed();
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneNorth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 2 is :')]"));
		if(ZoneNorth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone North 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone North 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone North 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone North 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for North 2 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for North 2 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone North 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for North 2 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone North 2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for North 2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone North 2 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone North 2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for North 2 Zone is')]")).isDisplayed();
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 3");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneNorth3 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone north 3 is :')]"));
		if(ZoneNorth3.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone north 3:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone north 3 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone north 3 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone north 3 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone north 3 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone north 3 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for north 3 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for north 3 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone north 3:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for north 3 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone north 3 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone north 3 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone north 3 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone north 3 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone north 3 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone north 3 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for north 3 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone north 3 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone north 3')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for north 3 Zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement superZone2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Super Zone 2 is :')]"));
		if(superZone2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("East");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneEast = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone east is :')]"));
		if(ZoneEast.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone east:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone east is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone east is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone east has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for east zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for east is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone east:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for east zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone east is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for east is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone east is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone east')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for east Zone is')]")).isDisplayed();
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneSouth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 1 is :')]"));
		if(ZoneSouth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone south 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone south 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone south 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone south 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for south 1 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for south 1 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone south 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for south 1 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone south 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for south 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone south 1 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone south 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for south 1 Zone is')]")).isDisplayed();
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneSouth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 2 is :')]"));
		if(ZoneSouth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone south 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone south 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone south 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone south 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for south 2 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for south 2 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone south 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for south 2 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone south 2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for south 2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone south 2 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone south 2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for south 2 Zone is')]")).isDisplayed();
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneWest2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone west 2 is :')]	"));
		if(ZoneWest2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone west 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone west 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone west 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone west 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for west 2 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for west 2 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone west 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for west 2 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone west 2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for west 2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone west 2 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone west 2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for west 2 Zone is')]")).isDisplayed();

	}		
	
	@Test(priority =6, enabled = true)
	public void AgencyAllRegionsResponseForAllKPI() throws InterruptedException
	{
		Thread.sleep(2000);
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		Thread.sleep(2000);
		// Enter Channel Name
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Agency is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement superZone1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Super Zone 1 is :')]"));
		if(superZone1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
	// North 1 starts here .............!!!!!!!!!!!!!!!
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneNorth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 1 is :')]"));
		if(ZoneNorth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionNorth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region REGION NORTH1 is :')]"));
		if(regionNorth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region REGION NORTH1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region REGION NORTH1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region REGION NORTH1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region REGION NORTH1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region REGION NORTH1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region REGION NORTH1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for REGION NORTH1')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for REGION NORTH1 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region REGION NORTH1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for REGION NORTH1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'REGION NORTH1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'REGION NORTH1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'REGION NORTH1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'REGION NORTH1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'REGION NORTH1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for REGION NORTH1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for REGION NORTH1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region REGION NORTH1 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for REGION NORTH1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for REGION NORTH1 is')]")).isDisplayed();	
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(ZoneNorth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North2");
		sendButton.click();
		Thread.sleep(2000);
		WebElement regionNorth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region North2 is :')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(regionNorth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region North2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region North2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region North2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region North2 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region North2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region North2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region North2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North2 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region North2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region North2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		sendButton.click();
		Thread.sleep(2000);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(ZoneNorth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}		
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North3");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionNorth3 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region North3 is :')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(regionNorth3.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);	
		}		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North3:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North3 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region North3 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region North3 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North3 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North3 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region North3')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region North3 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North3:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region North3 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North3 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North3 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North3 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North3 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North3 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region North3 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region North3 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North3 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region North3')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region North3 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//WebElement zoneNorth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 2 is :')]"));
		if(ZoneNorth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North4");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionNorth4 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region North4 is :')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(regionNorth4.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North4:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North4 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region North4 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region North4 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North4 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North4 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region North4')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region North4 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North4:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region North4 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North4 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North4 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North4 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North4 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North4 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region North4 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region North4 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North4 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region North4')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region North4 is')]")).isDisplayed();		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement zoneNorth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 2 is :')]"));
		if(zoneNorth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North5");
		sendButton.click();
		Thread.sleep(2000);
		WebElement regionNorth5 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region North5 is :')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(regionNorth5.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North5:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North5 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region North5 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region North5 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North5 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North5 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region North5')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region North5 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North5:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region North5 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North5 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North5 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North5 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North5 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North5 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region North5 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region North5 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North5 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region North5')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region North5 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//WebElement zoneNorth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 2 is :')]"));
		if(zoneNorth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}		
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North6");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionNorth6 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region North6 is :')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(regionNorth6.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North6:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North6 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region North6 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region North6 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North6 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North6 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region North6')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region North6 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North6:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region North6 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North6 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North6 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North6 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North6 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North6 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region North6 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region North6 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North6 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region North6')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region North6 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//WebElement zoneNorth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 2 is :')]"));
		if(zoneNorth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North7");
		sendButton.click();
		Thread.sleep(2000);
		WebElement regionNorth7 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region North7 is :')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(regionNorth7.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North7:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North7 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region North7 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region North7 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North7 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North7 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region North7')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region North7 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North7:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region North7 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North7 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North7 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North7 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North7 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North7 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region North7 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region North7 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North7 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region North7')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region North7 is')]")).isDisplayed();		
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(zoneNorth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North8");
		sendButton.click();
		Thread.sleep(2000);
		WebElement regionNorth8 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region North8 is :')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(regionNorth8.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North8:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North8 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region North8 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region North8 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North8 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North8 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region North8')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region North8 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North8:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region North8 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North8 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North8 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North8 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North8 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North8 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region North8 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region North8 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North8 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region North8')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region North8 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		verifybiZUpdate.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 3");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement zoneNorth3 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone north 3 is :')]"));
		if(zoneNorth3.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North9");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionNorth9 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region North9 is :')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(regionNorth9.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North9:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North9 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region North9 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region North9 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North8 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North9 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region North9')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region North9 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North9:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region North9 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North9 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North9 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North9 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North9 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North9 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region North9 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region North9 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North9 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region North9')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region North9 is')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 3");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//WebElement zoneNorth3 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 3 is :')]"));
		if(zoneNorth3.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North10");
		sendButton.click();
		Thread.sleep(2000);
		WebElement regionNorth10 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region North10 is :')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(regionNorth10.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North10:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North10 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region North10 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region North10 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North10 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region North10 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region North10')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region North10 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region North10:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region North10 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North10 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North10 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North10 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North10 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region North10 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region North10 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region North10 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region North10 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region North10')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region North10 is')]")).isDisplayed();
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(superZone1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
	// North 1 starts here .............!!!!!!!!!!!!!!!
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneWest1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone west 1 is :')]"));
		if(ZoneWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionWest1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region West1 is :')]"));
		if(regionWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region West1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region West1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region West1')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region West1 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region West1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region West1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region West1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West1 is :')]")).isDisplayed();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region West1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region West1 is')]")).isDisplayed();		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		verifybiZUpdate.click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(ZoneWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionWest2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region West2 is :')]"));
		if(regionWest2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region West2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region West2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region West2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region West2 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region West2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region West2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region West2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region West2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region West2 is')]")).isDisplayed();		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(ZoneWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West3");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionWest3 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region West3 is :')]"));
		if(regionWest3.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West3:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West3 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region West3 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region West3 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West3 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region West3')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region West3 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West3:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region West3 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West3 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West3 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West3 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West3 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West3 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region West3 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region West3 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West3 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region West3')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region West3 is')]")).isDisplayed();		
		driver.findElement(By.xpath("//img[@class='send']")).click();
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(ZoneWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West4");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionWest4 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region West4 is :')]"));
		if(regionWest4.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West4:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West4 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region West4 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region West4 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West4 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West4 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region West4')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region West4 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West4:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region West4 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West4 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West4 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West4 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West4 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West4 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region West4 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region West4 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West4 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region West4')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region West4 is')]")).isDisplayed();		
		driver.findElement(By.xpath("//img[@class='send']")).click();
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement superZone2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Super Zone 2 is :')]"));
		if(superZone2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
	// North 1 starts here .............!!!!!!!!!!!!!!!
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("east");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneEast = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone east is :')]"));
		if(ZoneEast.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region east1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionEast1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region REGION EAST 1 is :')]"));
		if(regionEast1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region REGION EAST 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region REGION EAST 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region REGION EAST 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region REGION EAST 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region REGION EAST 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region REGION EAST 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for REGION EAST 1')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for REGION EAST 1 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region REGION EAST 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for REGION EAST 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'REGION EAST 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'REGION EAST 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'REGION EAST 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'REGION EAST 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'REGION EAST 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for REGION EAST 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for REGION EAST 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region REGION EAST 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for REGION EAST 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for REGION EAST 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("east");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(ZoneEast.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region east2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionEast2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region East2 is :')]"));
		if(regionEast2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region East2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region East2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region East2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region East2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region East2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region East2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region East2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region East2 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region East2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region East2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region East2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region East2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region East2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region East2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region East2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region East2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region East2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region East2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region East2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region East2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(superZone2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
	// North 1 starts here .............!!!!!!!!!!!!!!!
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneWest2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone west 2 is :')]"));
		if(ZoneWest2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region west5");
		sendButton.click();
		sendButton.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionWest5 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region West5 is :')]"));
		if(regionWest5.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West5:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West5 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region West5 is')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region West5 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West5 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West5 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region West5')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region West5 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West5:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region West5 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West5 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West5 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West5 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West5 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West5 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region West5 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region West5 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West5 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region West5')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region West5 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west2");
		sendButton.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(ZoneWest2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region west6");
		sendButton.click();		
		WebElement regionWest6 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region West6 is :')]"));
		if(regionWest6.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West6:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West6 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region West6 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region West6 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West6 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West6 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region West6')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region West6 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West6:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region West6 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West6 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West6 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West6 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West6 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West6 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region West6 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region West6 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West6 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region West6')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region West6 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west2");
		sendButton.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(ZoneWest2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West7");
		sendButton.click();		
		WebElement regionWest7 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region West7 is :')]"));
		if(regionWest7.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West7:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West7 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region West7 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region West7 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West7 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West7 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region West7')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region West7 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West7:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region West7 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West7 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West7 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West7 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West7 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West7 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region West7 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region West7 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West7 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region West7')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region West7 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(ZoneWest2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West8");
		sendButton.click();
		Thread.sleep(2000);
		WebElement regionWest8 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region West8 is :')]"));
		if(regionWest8.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West8:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West8 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Region Region West8 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Region Region West8 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West8 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region Region West8 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Region West8')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Region West8 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Region Region West8:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Region West8 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West8 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West8 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West8 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West8 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Region West8 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Region West8 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Region West8 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Region Region West8 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Region West8')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Region West8 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	}
	@Test(priority = 7, enabled = true)
	public void AgencyGOForAllKPI() throws InterruptedException
	{
		Thread.sleep(2000);
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		Thread.sleep(2000);
		// Enter Channel Name
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Agency is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement superZone1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Super Zone 1 is :')]"));
		if(superZone1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
	// North 1 starts here .............!!!!!!!!!!!!!!!
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneWest1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone west 1 is :')]"));
		if(ZoneWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West3");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionWest1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region West3 is :')]"));
		if(regionWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AMU36");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement GO = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Office AMU36 is :')]"));
		if(GO.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Office AMU36:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Office AMU36 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Office AMU36 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Office AMU36 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AMU36 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AMU36 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Office AMU36')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Office AMU36 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Office AMU36:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Office AMU36 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AMU36 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AMU36 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AMU36 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AMU36 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AMU36 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Office AMU36 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Office AMU36 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Office AMU36 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Office AMU36')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Office AMU36 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if(superZone1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
	// North 1 starts here .............!!!!!!!!!!!!!!!
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneNorth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 1 is :')]"));
		if(ZoneNorth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionNorth3 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region North2 is :')]"));
		if(regionNorth3.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("APAT1");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement GOAPAT1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Office APAT1 is :')]"));
		if(GOAPAT1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Office APAT1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Office APAT1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Office APAT1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Office APAT1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office APAT1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office APAT1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Office APAT1')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Office APAT1 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Office APAT1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Office APAT1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office APAT1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office APAT1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office APAT1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office APAT1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office APAT1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Office APAT1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Office APAT1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Office APAT1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Office APAT1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Office APAT1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement superZone2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Super Zone 1 is :')]"));
		if(superZone2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West 2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement ZoneWest2= driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone west 2 is :')]"));
		if(ZoneWest2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West8");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement regionWest8 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Region Region West8 is :')]"));
		if(regionWest8.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AIND2");
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement GOAIND2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Office AIND2 is :')]"));
		if(GOAIND2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Office AIND2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Office AIND2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Office AIND2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Office AIND2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AIND2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AIND2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Office AIND2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Office AIND2 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Office AIND2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Office AIND2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AIND2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AIND2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AIND2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AIND2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Office AIND2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Office AIND2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Office AIND2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Office AIND2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Office AIND2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Office AIND2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}	
	@AfterClass
	public void postCondition() {
//		driver.quit();
	}
}
