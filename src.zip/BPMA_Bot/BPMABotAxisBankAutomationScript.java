package BPMA_Bot;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class BPMABotAxisBankAutomationScript {
	WebDriver driver;
	@BeforeClass
	public void preConditions() throws IOException {
		System.setProperty("webdriver.chrome.driver", "D:\\Eclipse\\ChatBot\\All exe\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=hvhom1028&key3=IOS&key4=eapp");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	@Test(priority=1, enabled=true)
	public void AxisBankMLILevelResponseForAllKPI() throws InterruptedException 
	{
		Thread.sleep(2000);
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement helpWithFollowingOptions = driver
				.findElement(By.xpath("//p[contains(text(),'I can help you with following options')]"));
		if (hiHarsh.isDisplayed() == true && helpWithFollowingOptions.isDisplayed()) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()) 
		{
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		if (verifybiZUpdate.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
			verifybiZUpdate.click();
			Thread.sleep(2000);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			WebElement channel = driver.findElement(By.xpath("//p[contains(text(),'the Business update for MLI is')]"));
			if (channel.isDisplayed() == true) 
			{
				Assert.assertTrue(true);
				System.out.println("Channel is displayed and verified");
			} 
			else 
			{
				Assert.assertTrue(false);
				System.out.println("channel is not displayed or verified");
			}
			//All KPI Validation of MLI level
			driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For MLI:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for MLI is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='wip']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for MLI is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'At MTD level MLI has achieved')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='growth']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI has witnessed paid Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI Protection Penetration is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='nop']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for MLI')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='protection']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for MLI is:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For MLI:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for MLI ')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI has witnessed applied Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI has witnessed paid cases growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'MLI has witnessed case size growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for MLI is Annual:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for MLI is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for MLI is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies MTD for MLI')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for MLI is')]")).isDisplayed();	
		}
	}
	@Test(priority = 2, enabled = true)
	public void axisBankChannelResponseForAllKPI() throws InterruptedException
	{
		Thread.sleep(2000);
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Axis");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for AXIS is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}				
		//KPI validation starts here!!
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
			Thread.sleep(2000);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For AXIS:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for AXIS is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='wip']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for AXIS is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'At MTD level AXIS has achieved')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='growth']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'AXIS has witnessed paid Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'AXIS Protection Penetration is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='nop']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Axis Bank is ')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//a[@data-value='protection']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Axis Bank is:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For AXIS:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Axis Bank ')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Axis Bank has witnessed applied Business growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Axis Bank has witnessed paid cases growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Axis Bank channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Axis Bank channel Case Size acheivement MTD:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Axis Bank has witnessed case size growth of')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Axis Bank is Annual:')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Axis Bank is')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for AXIS is :')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies MTD for Axis Bank')]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Axis Bank is')]")).isDisplayed();				
	}
	
	@Test(priority =3, enabled =true)
	public void AxisAllSuperZoneResponseForAllKPI() throws InterruptedException
	{
		Thread.sleep(2000);
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		Thread.sleep(2000);
		// Enter Channel Name
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Axis");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for AXIS is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}
		
		//Super Zone Starts here ..........!!
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("East Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement eastRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for East Region is :')]"));
		if(eastRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For East Region:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for East Region is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for East Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level East Region has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'East Region has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'East Region Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for East Region')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for East Region is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For East Region:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for East Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'East Region has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'East Region has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'East Region Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'East Region Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'East Region has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for East Region is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for East Region is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for East Region is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for East Region')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for East Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement westRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for West Region is :')]"));
		if(westRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For West Region:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for West Region is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for West Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level West Region has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'West Region has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'West Region Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for West Region')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for West Region is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For West Region:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for West Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'West Region has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'West Region has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'West Region Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'West Region Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'West Region has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for West Region is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for West Region is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for West Region is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for West Region')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for West Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement northRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]"));
		if(northRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For North Region:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for North Region is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for North Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level North Region has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'North Region has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'North Region Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for North Region')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for North Region is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For North Region:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for North Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'North Region has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'North Region has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'North Region Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'North Region Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'North Region has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for North Region is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for North Region is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for North Region is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for North Region')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for North Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement southRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for South Region is :')]"));
		if(southRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For South Region:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for South Region is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for South Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level South Region has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'South Region has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'South Region Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for South Region')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for South Region is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For South Region:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for South Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'South Region has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'South Region has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'South Region Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'South Region Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'South Region has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for South Region is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for South Region is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for South Region is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for South Region')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for South Region is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
	}

	
	@Test(priority =4, enabled= true)
	public void AxisAllZoneResponseForAllKPI() throws InterruptedException
	{
		Thread.sleep(4000);
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		Thread.sleep(2000);
		// Enter Channel Name
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Axis");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for AXIS is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}
		
		//Super Zone Starts here ..........!!
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("East Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement eastRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for East Region is :')]"));
		if(eastRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("East");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement eastZone = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone east is :')]"));
		if(eastZone.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone east:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone east is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone east is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone east has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for east zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for east is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone east:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for east zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone east has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone east is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for east is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone east is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone east')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for east Zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement zoneWest1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone west 1 is :')]"));
		if(zoneWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone west 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone west 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone west 1')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone west 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for west 1 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for west 1 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone west 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for west 1 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone west 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for west 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone west 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone west 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for west 1 Zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement zoneWest2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone west 2 is :')]"));
		if(zoneWest2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone west 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone west 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone west 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone west 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for west 2 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for west 2 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone west 2:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for west 2 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone west 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone west 2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for west 2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone west 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone west 2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for west 2 Zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement northRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]"));
		if(northRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneNorth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 1 is :')]"));
		if(zoneNorth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone North 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone North 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone North 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone North 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for North 1 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for North 1 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone North 1:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for North 1 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone North 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for North 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone North 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone North 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for North 1 Zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement zoneNorth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 2 is :')]"));
		if(zoneNorth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone North 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone North 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone North 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone North 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for North 2 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for North 2 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone North 2:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for North 2 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone North 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone North 2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for North 2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone North 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone North 2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for North 2 Zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement southRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for South Region is :')]"));
		if(southRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneSouth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 1 is :')]"));
		if(zoneSouth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone south 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone south 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone south 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone south 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for south 1 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for south 1 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone south 1:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for south 1 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone south 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for south 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone south 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone south 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for south 1 Zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneSouth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 2 is :')]"));
		if(zoneSouth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone south 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone south 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Zone south 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Zone south 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for south 2 zone')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for south 2 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Zone south 2:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for south 2 zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Zone south 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Zone south 2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for south 2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Zone south 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Zone south 2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for south 2 Zone is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	@Test(priority =5, enabled= true)
	public void AxisAllKeyMarketResponseForAllKPI() throws InterruptedException
	{
		Thread.sleep(2000);
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		Thread.sleep(2000);
		// Enter Channel Name
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Axis");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for AXIS is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}
		//Super Zone Starts here ..........!!
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("East Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement eastRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for East Region is :')]"));
		if(eastRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("East");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement eastZone = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone east is :')]"));
		if(eastZone.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Kolkata");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMKolkata = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Kolkata is :')]"));
		if(KMKolkata.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Kolkata:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Kolkata is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for KM Kolkata is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Kolkata has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Kolkata')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Kolkata is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Kolkata:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Kolkata is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Kolkata has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Kolkata is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Kolkata is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Kolkata is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Kolkata')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Kolkata is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM West Bengal");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMWestBengal = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM West Bengal is :')]"));
		if(KMWestBengal.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM West Bengal:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM West Bengal is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for KM West Bengal is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM West Bengal has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM West Bengal')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM West Bengal is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM West Bengal:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM West Bengal is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM West Bengal has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM West Bengal is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM West Bengal is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM West Bengal is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM West Bengal')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM West Bengal is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement zoneWest1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone west 1 is :')]"));
		if(zoneWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Mumbai");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement KMMumbai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Mumbai is :')]"));
		if(KMMumbai.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Mumbai:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Mumbai is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for KM Mumbai')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Mumbai has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Mumbai')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Mumbai is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Mumbai:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Mumbai is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'KM Mumbai has witnessed case size growth of')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Mumbai is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Mumbai is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Mumbai is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Mumbai')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Mumbai is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement northRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]"));
		if(northRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		WebElement zoneNorth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 1 is :')]"));
		if(zoneNorth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Delhi 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMDelhi1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Delhi 1 is :')]"));
		if(KMDelhi1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Delhi 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Delhi 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for KM Delhi 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Delhi 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Delhi 1')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Delhi 1 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Delhi 1:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Delhi 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Delhi 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Delhi 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Delhi 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Delhi 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Delhi 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Delhi 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//WebElement northRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]"));
		if(northRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneNorth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 2 is :')]"));
		if(zoneNorth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Punjab");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMPunjab = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Punjab is :')]"));
		if(KMPunjab.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Punjab:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Punjab is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for KM Punjab is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Punjab has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Punjab has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Punjab Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Punjab')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Punjab is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Punjab:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Punjab is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Punjab has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Punjab has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Punjab Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Punjab Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Punjab has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Punjab is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Punjab is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Punjab is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Punjab')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Punjab is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement southRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for South Region is :')]"));
		if(southRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneSouth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 1 is :')]"));
		if(zoneSouth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Bangalore");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMBanglore = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Bangalore is :')]"));
		if(KMBanglore.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Bangalore:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Bangalore is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for KM Bangalore is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Bangalore has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Bangalore')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Bangalore is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Bangalore:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Bangalore is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Bangalore has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Bangalore is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Bangalore is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Bangalore is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Bangalore')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Bangalore is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//WebElement southRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for South Region is :')]"));
		if(southRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneSouth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 2 is :')]"));
		if(zoneSouth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Chennai");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMChennai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Chennai is :')]"));
		if(KMChennai.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Chennai:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Chennai is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for KM Chennai is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level KM Chennai has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Chennai has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Chennai Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for KM Chennai')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for KM Chennai is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For KM Chennai:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for KM Chennai is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Chennai has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Chennai has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Chennai Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Chennai Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'KM Chennai has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for KM Chennai is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for KM Chennai is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for KM Chennai is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for KM Chennai')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for KM Chennai is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	@Test(priority =6, enabled= true)
	public void AxisAllCircleResponseForAllKPI() throws InterruptedException
	{
		Thread.sleep(2000);
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		Thread.sleep(2000);
		// Enter Channel Name
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Axis");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for AXIS is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}
		Thread.sleep(2000);
		//Super Zone Starts here ..........!!
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("East Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement eastRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for East Region is :')]"));
		if(eastRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("East");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement eastZone = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone east is :')]"));
		if(eastZone.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Kolkata");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMKolkata = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Kolkata is :')]"));
		if(KMKolkata.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Kolkata");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleKolkata = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Kolkata is :')]"));
		if(circleKolkata.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Kolkata:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Kolkata is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Circle Kolkata is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Circle Kolkata has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Kolkata has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Kolkata Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Circle Kolkata')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Circle Kolkata is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Kolkata:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Circle Kolkata is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Kolkata has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Kolkata has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Kolkata Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Kolkata Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Kolkata has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Circle Kolkata is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Circle Kolkata is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Kolkata is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Circle Kolkata')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Circle Kolkata is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM West Bengal");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMWestBengal = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM West Bengal is :')]"));
		if(KMWestBengal.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West Bengal 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleWestBengal2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle West Bengal 2 is :')]"));
		if(circleWestBengal2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle West Bengal 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle West Bengal 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Circle West Bengal 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Circle West Bengal 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle West Bengal 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle West Bengal 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Circle West Bengal 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Circle West Bengal 2 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle West Bengal 2:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Circle West Bengal 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle West Bengal 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle West Bengal 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle West Bengal 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle West Bengal 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle West Bengal 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Circle West Bengal 2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Circle West Bengal 2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle West Bengal 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Circle West Bengal 2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Circle West Bengal 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement zoneWest1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone west 1 is :')]"));
		if(zoneWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Mumbai");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement KMMumbai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Mumbai is :')]"));
		if(KMMumbai.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mumbai 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement circleMumbai1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Mumbai 1 is :')]"));
		if(circleMumbai1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Mumbai 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Mumbai 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Circle Mumbai 1')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Circle Mumbai 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Circle Mumbai 1')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Circle Mumbai 1 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Mumbai 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Circle Mumbai 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Circle Mumbai 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Circle Mumbai 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Mumbai 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Circle Mumbai 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Circle Mumbai 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Mumbai");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//WebElement KMMumbai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Mumbai is :')]"));
		if(KMMumbai.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mumbai 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement circleMumbai2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Mumbai 2 is :')]"));
		if(circleMumbai2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Mumbai 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Mumbai 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Circle Mumbai 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Circle Mumbai 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Circle Mumbai 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Circle Mumbai 2 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Mumbai 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Circle Mumbai 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Circle Mumbai 2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Circle Mumbai 2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Mumbai 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Circle Mumbai 2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Circle Mumbai 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement northRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]"));
		if(northRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);


		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		WebElement zoneNorth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 1 is :')]"));
		if(zoneNorth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Delhi 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		WebElement KMDelhi1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Delhi 1 is :')]"));
		if(KMDelhi1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South Delhi");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		WebElement circleSouthDelhi = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle south delhi is :')]"));
		if(circleSouthDelhi.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle south delhi:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle south delhi is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Circle south delhi is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Circle south delhi has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle south delhi has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle south delhi Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Circle south delhi')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Circle south delhi is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle south delhi:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Circle south delhi is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle south delhi has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle south delhi has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle south delhi Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle south delhi Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle south delhi has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Circle south delhi is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Circle south delhi is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle south delhi is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Circle south delhi')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Circle south delhi is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//WebElement northRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]"));
		if(northRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneNorth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 2 is :')]"));
		if(zoneNorth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Punjab");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMPunjab = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Punjab is :')]"));
		if(KMPunjab.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Punjab");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circlePunjab = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Punjab is :')]"));
		if(circlePunjab.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Punjab:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Punjab is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Circle Punjab is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Circle Punjab has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Punjab has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Punjab Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Circle Punjab')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Circle Punjab is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Punjab:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Circle Punjab is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Punjab has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Punjab has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Punjab Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Punjab Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Punjab has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Circle Punjab is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Circle Punjab is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Punjab is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Circle Punjab')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Circle Punjab is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement southRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for South Region is :')]"));
		if(southRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneSouth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 1 is :')]"));
		if(zoneSouth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Bangalore");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMBanglore = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Bangalore is :')]"));
		if(KMBanglore.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Bangalore 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleBanglore1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Bangalore 1 is :')]"));
		if(circleBanglore1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Bangalore 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Bangalore 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Circle Bangalore 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Circle Bangalore 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Circle Bangalore 1')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Circle Bangalore 1 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Bangalore 1:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Circle Bangalore 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Circle Bangalore 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Circle Bangalore 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Bangalore 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Circle Bangalore 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Circle Bangalore 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Bangalore");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		//WebElement KMBanglore = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Bangalore is :')]"));
		if(KMBanglore.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Bangalore 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleBanglore2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Bangalore 2 is :')]"));
		if(circleBanglore2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Bangalore 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Bangalore 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Circle Bangalore 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Circle Bangalore 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Circle Bangalore 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Circle Bangalore 2 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Bangalore 2:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Circle Bangalore 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Bangalore 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Circle Bangalore 2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Circle Bangalore 2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Bangalore 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Circle Bangalore 2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Circle Bangalore 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//WebElement southRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for South Region is :')]"));
		if(southRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneSouth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 2 is :')]"));
		if(zoneSouth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Chennai");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMChennai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Chennai is :')]"));
		if(KMChennai.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Chennai 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleChennai1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Chennai 1 is :')]"));
		if(circleChennai1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Chennai 1:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Chennai 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Circle Chennai 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Circle Chennai 1 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 1 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 1 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Circle Chennai 1')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Circle Chennai 1 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Chennai 1:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Circle Chennai 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 1 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 1 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 1 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 1 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 1 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Circle Chennai 1 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Circle Chennai 1 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Chennai 1 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Circle Chennai 1')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Circle Chennai 1 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Chennai");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		//WebElement KMChennai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Chennai is :')]"));
		if(KMChennai.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Chennai 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleChennai2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Chennai 2 is :')]"));
		if(circleChennai2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Chennai 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Chennai 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Circle Chennai 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Circle Chennai 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Circle Chennai 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Circle Chennai 2 is:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Chennai 2:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Circle Chennai 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Circle Chennai 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Circle Chennai 2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Circle Chennai 2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Chennai 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Circle Chennai 2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Circle Chennai 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
	}
	@Test(priority =7, enabled= true)
	public void AxisAllClusterResponseForAllKPI() throws InterruptedException
	{
		Thread.sleep(3000);
		WebElement verifybiZUpdate = driver.findElement(By.xpath("//a[contains(text(),'Biz Update')]"));
		verifybiZUpdate.click();
		Thread.sleep(2000);
		// Enter Channel Name
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Axis");
		WebElement sendButton = driver.findElement(By.xpath("//img[@class='send']"));
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement channelData = driver.findElement(By.xpath("//p[contains(text(),'the Business update for AXIS is :')]"));
		if(channelData.isDisplayed()==true)
		{
			Assert.assertTrue(true);
			System.out.println("Sub Channel is data is displayed and verified");
		}
		else
		{
			Assert.assertTrue(false);
			System.out.println("Sub channel is not displayed");
		}
		
		//Super Zone Starts here ..........!!
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("East Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement eastRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for East Region is :')]"));
		if(eastRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("East");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement eastZone = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone east is :')]"));
		if(eastZone.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Kolkata");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMKolkata = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Kolkata is :')]"));
		if(KMKolkata.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Kolkata");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleKolkata = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Kolkata is :')]"));
		if(circleKolkata.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Kolkata Greater");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(3000);
		WebElement clusterKolkataGreater = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Cluster Kolkata Greater is :')]"));
		if(clusterKolkataGreater.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(4000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Kolkata Greater:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Kolkata Greater is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Cluster Kolkata Greater is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Cluster Kolkata Greater has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Kolkata Greater has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Kolkata Greater Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Kolkata Greater')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Kolkata Greater is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Kolkata Greater:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Kolkata Greater is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Kolkata Greater has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Kolkata Greater has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Kolkata Greater Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Kolkata Greater Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Kolkata Greater has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Kolkata Greater is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Kolkata Greater is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Kolkata Greater is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Kolkata Greater')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Kolkata Greater is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM West Bengal");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMWestBengal = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM West Bengal is :')]"));
		if(KMWestBengal.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West Bengal 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleWestBengal2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle West Bengal 2 is :')]"));
		if(circleWestBengal2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Baharampur");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement clusterBaharampur = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Cluster Baharampur is :')]"));
		if(clusterBaharampur.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Baharampur:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Baharampur is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Cluster Baharampur is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Cluster Baharampur has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Baharampur has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Baharampur Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Baharampur')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Baharampur is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Baharampur:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Baharampur is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Baharampur has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Baharampur has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Baharampur Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Baharampur Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Baharampur has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Baharampur is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Baharampur is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Baharampur is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Baharampur')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Baharampur is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement zoneWest1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone west 1 is :')]"));
		if(zoneWest1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Mumbai");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement KMMumbai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Mumbai is :')]"));
		if(KMMumbai.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mumbai 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement circleMumbai1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Mumbai 1 is :')]"));
		if(circleMumbai1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Andheri 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement clusterAndheri2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Cluster Andheri 2 is :')]"));
		if(clusterAndheri2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Andheri 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Andheri 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Cluster Andheri 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Cluster Andheri 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Andheri 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Andheri 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Andheri 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Andheri 2 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Andheri 2:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Andheri 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Andheri 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Andheri 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Andheri 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Andheri 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Andheri 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Andheri 2 is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Andheri 2 is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Andheri 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Andheri 2')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Andheri 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
//		verifybiZUpdate.click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Mumbai");
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		sendButton.click();
//		Thread.sleep(2000);
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		//WebElement KMMumbai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Mumbai is :')]"));
//		if(KMMumbai.isDisplayed()==true)
//		{
//			Assert.assertTrue(true);
//		}
//		else
//		{
//			Assert.assertTrue(false);
//		}
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mumbai 2");
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		sendButton.click();
//		Thread.sleep(2000);
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		WebElement circleMumbai2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Mumbai 2 is :')]"));
//		if(circleMumbai2.isDisplayed()==true)
//		{
//			Assert.assertTrue(true);
//		}
//		else
//		{
//			Assert.assertTrue(false);
//		}
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Mumbai 2:')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Mumbai 2 is :')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Circle Mumbai 2')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Circle Mumbai 2 has achieved')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 has witnessed paid Business growth of')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 Protection Penetration is')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Circle Mumbai 2')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Circle Mumbai 2 is:')]")).isDisplayed();
//		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Circle Mumbai 2:')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Circle Mumbai 2 is')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 has witnessed applied Business growth of')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 has witnessed paid cases growth of')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 Case Size acheivement MTD:')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 Case Size acheivement MTD:')]")).isDisplayed();				
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Circle Mumbai 2 has witnessed case size growth of')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Circle Mumbai 2 is Annual:')]")).isDisplayed();				
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Circle Mumbai 2 is')]")).isDisplayed();				
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Circle Mumbai 2 is :')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Circle Mumbai 2')]")).isDisplayed();				
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Circle Mumbai 2 is')]")).isDisplayed();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement northRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]"));
		if(northRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneNorth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 1 is :')]"));
		if(zoneNorth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Delhi 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMDelhi1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Delhi 1 is :')]"));
		if(KMDelhi1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South Delhi 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		WebElement clusterSouthDelhi2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Cluster South Delhi 2 is :')]"));
		if(clusterSouthDelhi2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster South Delhi 2:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster South Delhi 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Cluster South Delhi 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Cluster South Delhi 2 has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster South Delhi 2 has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster South Delhi 2 Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for South Delhi 2')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for South Delhi 2 is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster South Delhi 2:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for South Delhi 2 is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'South Delhi 2 has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'South Delhi 2 has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'South Delhi 2 Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'South Delhi 2 Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'South Delhi 2 has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for South Delhi 2 is Annual:')]")).isDisplayed();
	//	-----------bug(for is)- missing south delhi 2
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for South Delhi 2 is')]")).isDisplayed(); 
	//	FTD data shows.		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster South Delhi 2 is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for South Delhi 2')]")).isDisplayed();				
	//	goes to MLI
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
//		driver.findElement(By.xpath("//img[@class='send']")).click();
//		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for South Delhi 2 is')]")).isDisplayed();
	//	Bug- Goes to MLI level
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		Thread.sleep(4000);
		verifybiZUpdate.click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(4000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//WebElement northRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for North Region is :')]"));
		if(northRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(4000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(4000);
		WebElement zoneNorth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone North 2 is :')]"));
		if(zoneNorth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Punjab");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMPunjab = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Punjab is :')]"));
		if(KMPunjab.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Punjab");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circlePunjab = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Punjab is :')]"));
		if(circlePunjab.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}

		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Patiala");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement clusterPatiala = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Cluster Patiala is :')]"));
		if(clusterPatiala.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Patiala:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Patiala is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Cluster Patiala is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Cluster Patiala has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Patiala has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Patiala Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Patiala')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Patiala is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Patiala:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Patiala is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Patiala has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Patiala has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Patiala Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Patiala Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Patiala has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Patiala is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Patiala is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Patiala is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Patiala')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Patiala is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);				
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement southRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for South Region is :')]"));
		if(southRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneSouth1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 1 is :')]"));
		if(zoneSouth1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Bangalore");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMBanglore = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Bangalore is :')]"));
		if(KMBanglore.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Bangalore 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleBanglore1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Bangalore 1 is :')]"));
		if(circleBanglore1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Yelahanka");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement clusterYelahanka = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Cluster Yelahanka is :')]"));
		if(clusterYelahanka.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Yelahanka:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Yelahanka is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Cluster Yelahanka is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Cluster Yelahanka has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Yelahanka has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Yelahanka Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Yelahanka')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Yelahanka is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Yelahanka:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Yelahanka is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Yelahanka has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Yelahanka has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Yelahanka Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Yelahanka Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Yelahanka has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Yelahanka is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Yelahanka is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Yelahanka is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Yelahanka')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Yelahanka is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Bangalore");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		//WebElement KMBanglore = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Bangalore is :')]"));
		if(KMBanglore.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Bangalore 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleBanglore2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Bangalore 2 is :')]"));
		if(circleBanglore2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Indiranagar");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement clusterIndiranagar = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Cluster Indiranagar is :')]"));
		if(clusterIndiranagar.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Indiranagar:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Indiranagar is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Cluster Indiranagar is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Cluster Indiranagar has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Indiranagar has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Indiranagar Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Indiranagar')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Indiranagar is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Indiranagar:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Indiranagar is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Indiranagar has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Indiranagar has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Indiranagar Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Indiranagar Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Indiranagar has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Indiranagar is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Indiranagar is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Indiranagar is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Indiranagar')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Indiranagar is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South Region");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//WebElement southRegion = driver.findElement(By.xpath("//p[contains(text(),'the Business update for South Region is :')]"));
		if(southRegion.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("South 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement zoneSouth2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Zone south 2 is :')]"));
		if(zoneSouth2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Chennai");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement KMChennai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Chennai is :')]"));
		if(KMChennai.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Chennai 1");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleChennai1 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Chennai 1 is :')]"));
		if(circleChennai1.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adyar");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement clusterAdyar = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Cluster Adyar is :')]"));
		if(clusterAdyar.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Adyar:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Adyar is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Cluster Adyar is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Cluster Adyar has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Adyar has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster Adyar Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for Adyar')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for Adyar is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster Adyar:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for Adyar is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Adyar has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Adyar has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Adyar Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Adyar Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Adyar has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for Adyar is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for Adyar is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster Adyar is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for Adyar')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for Adyar is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);		
		verifybiZUpdate.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("KM Chennai");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		//WebElement KMChennai = driver.findElement(By.xpath("//p[contains(text(),'the Business update for KM Chennai is :')]"));
		if(KMChennai.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Chennai 2");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement circleChennai2 = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Circle Chennai 2 is :')]"));
		if(circleChennai2.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("George Town");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		sendButton.click();
		Thread.sleep(2000);
		WebElement clusterGeorgeTown = driver.findElement(By.xpath("//p[contains(text(),'the Business update for Cluster George Town is :')]"));
		if(clusterGeorgeTown.isDisplayed()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='Applied Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster George Town:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@data-value='Paid Business']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster George Town is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='wip']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Current WIP as of ') and contains(text(),'for Cluster George Town is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='achievement']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'At MTD level Cluster George Town has achieved')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='growth']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster George Town has witnessed paid Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='penetration']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Cluster George Town Protection Penetration is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='nop']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid cases MTD for George')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the MTD Protection business for George Town is:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business AFYP MTD For Cluster George Town:')]")).isDisplayed();
		driver.findElement(By.xpath("//a[@data-value='protection']")).click();
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Adj. IFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied Business Adj IFYP MTD for George Town is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'George Town has witnessed applied Business growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Paid Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'George Town has witnessed paid cases growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size AFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'George Town Case Size acheivement MTD:')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Case Size Achievement");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'George Town Case Size acheivement MTD:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Growth Case Size");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'George Town has witnessed case size growth of')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Mode Mix");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Mode mix ratio for George Town is Annual:')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Applied Cases");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Applied cases MTD for George Town is')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Adj. MFYP");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'Paid AdjMFYP Business MTD for Cluster George Town is :')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("NTU");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the count of NTU policies for George Town')]")).isDisplayed();				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Hubhold");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[contains(text(),'the total Hub hold cases for George Town is')]")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);				
	}
	@AfterMethod
	public void tearDown(){
		//driver.quit();
	}
}
