package BPMA_Insta_IssuanceKPI_Automation_Script;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Insta_IssuanceNonProtectionNonMedMedKPI_AutomationScript_Agency {
WebDriver driver;
    
	@BeforeClass
	public void PreCondition() throws InterruptedException
	{	
		System.setProperty("webdriver.chrome.driver", "D:/Eclipse/ChatBot/Jars/chromedriver.exe");
		driver= new ChromeDriver();
		driver.navigate().to("https://botuat.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=hvhom1028&key3=IOS&key4=eapp");
		driver.manage().timeouts().pageLoadTimeout(100, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Thread.sleep(3000);
	}
	
	@Test(priority=1, enabled=true)
	public void InstaIssuanceKPIResponseforchannelAgency() throws InterruptedException
	{
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement helpWithFollowingOptions = driver.findElement(By.xpath("//p[contains(text(),' I can help you with following options')]"));
		if(hiHarsh.isDisplayed()==true && helpWithFollowingOptions.isDisplayed()==true){
			Assert.assertTrue(true);
		}
		else{
			Assert.assertFalse(false);
		}
		Thread.sleep(1000);
		WebElement businessNumber = driver.findElement(By.xpath("//a[text()='Business Numbers']"));
		if(businessNumber.isDisplayed()==true){
			businessNumber.click();
		}
		else{
			Assert.assertFalse(false);
		}
		Thread.sleep(2000);
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS); 
		// Thread.sleep(1000);
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance Med");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDForMLI = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for MLI is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') "
						+ "and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :')]"));		
		if (InstaIssuanceMTDForMLI.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDForMLI = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for MLI is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') "
						+ "and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :')]"));		
		if (InstaIssuanceFTDForMLI.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
//		WebElement InstaIssuanceFTDDataForMLI = driver.findElement(By.xpath
//				("//li[contains(@class,'other ng-scope' )][3]//p"));
//		Object extractFTDdataOfMLI = ((WebElement) driver).getAttribute(InstaIssuanceFTDDataForMLI.toString());
//		
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDForMLI = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDForMLI.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		WebElement InstaIssuanceYTDForAgency = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		WebElement InstaIssuanceMTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') "
						+ "and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') "
						+ "and contains(text(),'Insta-Issuance 6hrs :') and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=2, enabled=true)
	public void InstaIssuanceDefaultKPIResponseforAllSubChannels() throws InterruptedException
	{
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance Med");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceYTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("OWO");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOWOSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office within Office is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOWOSubchannel = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOWOSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office within Office is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Greenfield");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGreenfieldSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Greenfield is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGreenfieldSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGreenfieldSubchannel = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGreenfieldSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGreenfieldSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Greenfield is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGreenfieldSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("APC");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForAPCSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for APC is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForAPCSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForAPCSubchannel = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForAPCSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForAPCSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for APC is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForAPCSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForAPCSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Defence");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForDefenceSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Defence is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForDefenceSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForDefenceSubchannel = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForDefenceSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForDefenceSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Defence is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForDefenceSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}	
	}
	
	@Test(priority=3, enabled=true)
	public void InstaIssuanceKPIResponseforAllSuperZones() throws InterruptedException
	{
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance Med");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("OWO");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOWOSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office within Office is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForSuperZone1 = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOWOSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("APC");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForAPCSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for APC is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForAPCSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForSubchannelAPCAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelAPCAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForSubchannelAPCAndSuperZone1 = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSubchannelAPCAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSubchannelAPCAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelAPCAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Defence");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForDefenceSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Defence is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForDefenceSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSubchannelDefenceAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelDefenceAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForSubchannelDefenceAndSuperZone1 = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSubchannelDefenceAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForSubchannelDefenceAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelDefenceAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Greenfield");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		WebElement InstaIssuanceFTDResponseForGreenfieldSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Greenfield is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGreenfieldSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForSubchannelGreenfieldAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelGreenfieldAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForSubchannelGreenfieldAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSubchannelGreenfieldAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSubchannelGreenfieldAndSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelGreenfieldAndSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("OWO");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOWOSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOWOSubchanne2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOWOSubchanne2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("APC");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		if (InstaIssuanceFTDResponseForAPCSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSubchannelAPCAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelAPCAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForSubchannelAPCAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSubchannelAPCAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForSubchannelAPCAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelAPCAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Defence");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForDefenceSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Defence is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));	
		if (InstaIssuanceFTDResponseForDefenceSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForSubchannelDefenceAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelDefenceAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForSubchannelDefenceAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSubchannelDefenceAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSubchannelDefenceAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelDefenceAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Greenfield");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGreenfieldSubchannel = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Greenfield is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));
		if (InstaIssuanceMTDResponseForGreenfieldSubchannel.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSubchannelGreenfieldAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSubchannelGreenfieldAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForSubchannelGreenfieldAndSuperZone2 = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSubchannelGreenfieldAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForSubchannelGreenfieldAndSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSubchannelGreenfieldAndSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}		
	}
	@Test(priority=4, enabled=true)
	public void InstaIssuanceKPIResponseforAllZones() throws InterruptedException
	{
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance Med");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForwest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone west 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForwest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForWest1 = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForwest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Zone west 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForwest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForwest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone North 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Zone North 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone North 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone North 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone north 3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Zone north 3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		if (InstaIssuanceFTDResponseForNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("east");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForEastZone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone east is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForEastZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForEastZone = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForEastZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForEastZone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Zone east is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForEastZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForEastZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone west 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Zone west 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("south");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSouthZone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone south is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSouthZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForSouthZone = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSouthZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForSouthZone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Zone south is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSouthZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForSouthZone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("south 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSouth2Zone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone south 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSouth2Zone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForSouth2Zone = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForSouth2Zone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForSouth2Zone = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Zone south 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForSouth2Zone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForSouth2Zone.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	}
	
	@Test(priority=5, enabled=true)
	public void InstaIssuanceKPIResponseforAllRegions() throws InterruptedException
	{
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance Med");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDForAgency= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForwest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone west 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForwest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest3 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest4 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone North 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for REGION NORTH1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for REGION NORTH1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth4 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone North 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth5 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North6");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth6 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North7");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth7 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North8");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth8 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North8 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth8 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth8 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North8 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone north 3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North9");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth9 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North9 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth9 = driver.findElement(By.xpath("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth9.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth9 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North9 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth9.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth9.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North10");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth10 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North10 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth10.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionNorth10 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionNorth10.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionNorth10 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region North10 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionNorth10.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth10.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("east");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForEast = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone east is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForEast.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region East 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionEast1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for REGION EAST 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionEast1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionEast1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionEast1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionEast1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for REGION EAST 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionEast1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionEast1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region East2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionEast2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region East2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionEast2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionEast2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionEast2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionEast2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region East2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionEast2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionEast2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone west 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest5= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest5 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West6");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest6 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceFTDResponseForRegionWest6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West7");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest7 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West8");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest8 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West8 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionWest8 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionWest8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionWest8 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region West8 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionWest8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("south");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSouth = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone south is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSouth.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for REGION SOUTH 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for REGION SOUTH 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth2= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth3= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth3 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("south2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSouth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone south 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth4= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth4 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth5= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth5 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South6");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth6= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth6 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South7");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth7= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForRegionSouth7 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForRegionSouth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForRegionSouth7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Region South7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForRegionSouth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionSouth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}	
	}
	
	@Test(priority=6, enabled=true)
	public void InstaIssuancEKPIResponseforAllGOs() throws InterruptedException
	{
		WebElement hiHarsh = driver.findElement(By.xpath("//p[text()='Hi Harsh']"));
		WebElement howCanIHelp = driver.findElement(By.xpath("//p[contains(text(),'how can i help you with business KPI')]"));
		if (hiHarsh.isDisplayed() == true && howCanIHelp.isDisplayed()==true) 
		{
			Assert.assertTrue(true);
		} 
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Insta-Issuance Med");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Agency");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDForAgency = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Agency is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDForAgency.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSuperZone1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);				
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForwest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone west 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForwest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AAHM4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOABRU1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AAHM4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOABRU1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOABRU1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOABRU1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOABRU1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AAHM4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOABRU1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOABRU1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AGND1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAGND1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AGND1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAGND1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAGND1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAGND1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAGND1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AGND1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAGND1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOABRU1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("west 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);	
		if (InstaIssuanceMTDResponseForwest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ASUR2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOASUR2= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ASUR2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOASUR2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOASUR2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOASUR2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOASUR2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ASUR2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOASUR2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOASUR2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AJMN1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAJMN1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AJMN1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAJMN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAJMN1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAJMN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAJMN1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AJMN1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAJMN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAJMN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AMU33");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAMU33= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AMU33 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAMU33.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAMU33 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAMU33.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAMU33 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AMU33 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAMU33.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAMU33.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AJMN1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
//		WebElement InstaIssuanceMTDResponseForGOAJMN1= driver.findElement(By.xpath
//				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AJMN1 is:') "
//						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
//						+ "and contains(text(),'Insta-Issuance 12hrs :') "
//						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAJMN1.isDisplayed() == true) 
			
		
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
//		WebElement InstaIssuanceYTDResponseForGOAJMN1 = driver.findElement(By.xpath
//				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAJMN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
//		WebElement InstaIssuanceFTDResponseForGOAJMN1 = driver.findElement(By.xpath
//				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AJMN1 is:') "
//						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
//						+ "and contains(text(),'Insta-Issuance 12hrs :') "
//						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAJMN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAJMN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionWest4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AAHM5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAAHM5= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AAHM5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAAHM5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAAHM5 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAAHM5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAAHM5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AAHM5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAAHM5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAAHM5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceMTDResponseForNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone North 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));
		Thread.sleep(1000);	
		if (InstaIssuanceMTDResponseForNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for REGION NORTH1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ADL21");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOADL21= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ADL21 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOADL21.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOADL21 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOADL21.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOADL21 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ADL21 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOADL21.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOADL21.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ADEL3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOADEL3= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ADEL3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOADEL3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOADEL3 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOADEL3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOADEL3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ADEL3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOADEL3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOADEL3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//		WebElement InstaIssuanceMTDResponseForNorth1 = driver.findElement(By.xpath
//				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone North 1 is:') "
//						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
//						+ "and contains(text(),'Insta-Issuance 12hrs :') "
//						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));
		Thread.sleep(1000);	
		if (InstaIssuanceMTDResponseForNorth1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AAMR1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAAMR1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AAMR1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAAMR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAAMR1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAAMR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAAMR1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AAMR1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAAMR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAAMR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ALUD1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOALUD1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ALUD1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOALUD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOALUD1= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOALUD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOALUD1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ALUD1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOALUD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOALUD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceMTDResponseForRegionNorth3= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ADEL4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOADEL4= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ADEL4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOADEL4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOADEL4 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOADEL4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOADEL4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ADEL4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOADEL4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOADEL4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ADEL6");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOADEL6= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ADEL6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOADEL6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOADEL6= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOADEL6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOADEL6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ALUD1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOADEL6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOADEL6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceMTDResponseForRegionNorth4= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AKUL1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAKUL1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AKUL1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAKUL1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAKUL1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAKUL1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAKUL1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AKUL1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAKUL1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAKUL1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ASRI1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOASRI1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ASRI1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOASRI1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOASRI1= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOASRI1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOASRI1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ASRI1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOASRI1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOASRI1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceMTDResponseForNorth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone North 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));
		Thread.sleep(1000);	
		if (InstaIssuanceMTDResponseForNorth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceMTDResponseForRegionNorth5= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AGZB2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAGZB2= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AGZB2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAGZB2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAGZB2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAGZB2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAGZB2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AGZB2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAGZB2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAGZB2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ANOI3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOANOI3= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ANOI3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOANOI3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOANOI3= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOANOI3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOANOI3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ANOI3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOANOI3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOANOI3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North6");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceMTDResponseForRegionNorth6= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ALUC1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOALUC1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ALUC1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOALUC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOALUC1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOALUC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOALUC1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ALUC1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOALUC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOALUC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AMRD1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAMRD1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AMRD1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAMRD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAMRD1= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAMRD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAMRD1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AMRD1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAMRD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAMRD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North7");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceMTDResponseForRegionNorth7= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AKAN1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAKAN1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AKAN1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAKAN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAKAN1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAKAN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAKAN1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AKAN1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAKAN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAGZB2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AALH1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAALH1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AALH1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAALH1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAALH1= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAALH1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAALH1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AALH1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAALH1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAALH1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North8");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceMTDResponseForRegionNorth8= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North8 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AMER1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAMER1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AMER1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAMER1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAMER1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAMER1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAMER1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AMER1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAMER1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAMER1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AHLD1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAHLD1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AHLD1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAHLD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAHLD1= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAHLD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAHLD1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AHLD1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAHLD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAHLD1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("North 3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceMTDResponseForNorth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone north 3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));
		Thread.sleep(1000);	
		if (InstaIssuanceMTDResponseForNorth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North9");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceMTDResponseForRegionNorth9= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North9 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth9.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AJPR1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAJPR1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AJPR1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAJPR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAJPR1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAJPR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAJPR1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AJPR1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAJPR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAJPR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AKOT1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAKOT1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AKOT1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAKOT1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAKOT1= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAKOT1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAKOT1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AKOT1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAKOT1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAKOT1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region North10");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement InstaIssuanceMTDResponseForRegionNorth10= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region North10 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForRegionNorth10.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("APNP1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAPNP1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office APNP1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAPNP1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAPNP1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAPNP1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAPNP1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office APNP1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAPNP1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAPNP1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AYMN1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForGOAYMN1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AYMN1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForGOAYMN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForGOAYMN1= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForGOAYMN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForGOAYMN1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AYMN1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForGOAYMN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForGOAYMN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Super Zone 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSuperZone2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Super Zone 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSuperZone2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("east");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForEast = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone east is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForEast.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region East 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionEast1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for REGION EAST 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionEast1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AGUW1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeAGUW1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AGUW1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeAGUW1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeAGUW1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeAGUW1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeAGUW1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AGUW1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeAGUW1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeAGUW1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region East 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionEast2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region East2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionEast2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ARAN1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeARAN1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ARAN1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeARAN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeARAN1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeARAN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeARAN1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ARAN1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeARAN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeARAN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("West 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForwest2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone west 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForwest2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ADUR1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeADUR1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ADUR1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeADUR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeADUR1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeADUR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeADUR1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ADUR1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeADUR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeADUR1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West6");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ANAN1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeANAN1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ANAN1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeANAN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeANAN1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeANAN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeANAN1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ADUR1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeANAN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeANAN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}

		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West7");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AKLP1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeAKLP1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AKLP1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeAKLP1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeAKLP1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeAKLP1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeAKLP1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AKLP1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeAKLP1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeAKLP1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region West8");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionWest8 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region West8 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionWest8.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AUJN1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeAUJN1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AUJN1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeAUJN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeAUJN1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeAUJN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeAUJN1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AKLP1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeAUJN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeAUJN1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("south");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSouth = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone south is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSouth.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South 1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSOUTH1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for REGION SOUTH 1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSOUTH1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AKOC1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeAKOC1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AKOC1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeAKOC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeAKOC1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeAKOC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeAKOC1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AKOC1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeAKOC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeAKOC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("APNJ1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeAPNJ1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office APNJ1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeAPNJ1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeAPNJ1 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeAPNJ1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeAPNJ1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office APNJ1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeAPNJ1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeAPNJ1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South3");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth3 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South3 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth3.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ABAN2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeABAN2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ABAN2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeABAN2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeABAN2 = driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeABAN2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeABAN2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ABAN2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeABAN2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeABAN2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("south 2");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForSouth2 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Zone south 2 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForSouth2.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South4");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth4 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South4 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth4.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AHYD5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeAHYD5= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AHYD5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeAHYD5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeAHYD5= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeAHYD5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeAHYD5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AHYD5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeAHYD5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeAHYD5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}

		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AKNC1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeAKNC1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AKNC1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeAKNC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeAKNC1= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeAKNC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeAKNC1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AKNC1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeAKNC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeAKNC1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South6");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth6 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South6 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth6.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("ACHE5");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeACHE5= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office ACHE5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeACHE5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeACHE5= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeACHE5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeACHE5 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office ACHE5 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeACHE5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeACHE5.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("Region South7");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForRegionSouth7 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Region South7 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForRegionSouth7.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("AVZG1");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceMTDResponseForOfficeAVZG1= driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) MTD for Office AVZG1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceMTDResponseForOfficeAVZG1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("YTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
		Thread.sleep(1000);
		WebElement InstaIssuanceYTDResponseForOfficeAVZG1= driver.findElement(By.xpath
				("//p[contains(text(),'YTD data will be available from next financial year.')]"));		
		if (InstaIssuanceYTDResponseForOfficeAVZG1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("FTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		WebElement InstaIssuanceFTDResponseForOfficeAVZG1 = driver.findElement(By.xpath
				("//p[contains(text(),'Insta-Issuance (Non Protection Non Med & Med) FTD for Office AVZG1 is:') "
						+ "and contains(text(),'Insta-Issuance : NOP') and contains(text(),'Insta-Issuance 6hrs :') "
						+ "and contains(text(),'Insta-Issuance 12hrs :') "
						+ "and contains(text(),'Insta-Issuance 24hrs :')]"));		
		if (InstaIssuanceFTDResponseForOfficeAVZG1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here...']")).sendKeys("MTD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(1000);
		if (InstaIssuanceMTDResponseForOfficeAVZG1.isDisplayed() == true) 
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}		
	}
	
	
	@AfterClass
	public void PostConditions()
	{
		//driver.quit();
	}
}
