package CodeFirst;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.text.TabSet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.ScreenshotException;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import screenshot.ScreenShot;

public class CalculateMyPremium {
	WebDriver driver;
	
	@BeforeClass
	public void PreConditions() throws IOException {
		System.setProperty("webdriver.chrome.driver", "D:\\Eclipse\\ChatBot\\All exe\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://bot.maxlifeinsurance.com/term-insurance-calculator");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test(priority = 1)
	public void verifyHeader() throws IOException {
		try{
		Thread.sleep(1000);	
		String ExpectedHeader = "Calculate my premium";
		String actualheader = driver.findElement(By.xpath("//h1[text()='Calculate my premium']")).getText();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		if (ExpectedHeader.equalsIgnoreCase(actualheader) == true) 
		{
			System.out.println("actual header and expected header are matched and passed");
			Reporter.log("Header are matched and result is passed");
		} else {
			System.out.println("Actual and expected header are not matched and verification failed");
			Reporter.log("Haader are not same and mismatched");
		}
		ScreenShot.getPassedScreenShot(driver, "verifyHeader");
		}
		catch (Exception e) {
			ScreenShot.getFailedScreenShot(driver, "verifyHeader");
		}
	}

	@Test(priority = 2)
	public void verifyText() throws IOException {
		try{
		driver.navigate().refresh();	
		Thread.sleep(1000);
		boolean welcomeElement = driver
				.findElement(By
						.xpath("//p[contains(text(),'Hi, Thanks for showing interest in Max Life Term insurance. I am your online assistant. ')]"))
				.isDisplayed();
		if (welcomeElement == true) {
			Assert.assertTrue(true, "Welcome message is displayed and verified");
		} else {
			Assert.assertTrue(false, "Webelement is not verifed");
		}
		ScreenShot.getPassedScreenShot(driver, "verifyText");
		}
		catch (Exception e) {
			ScreenShot.getFailedScreenShot(driver, "verifyText");
		}
		}

	@Test(priority = 3)
	public void verifyButton() throws IOException {
		try{
		driver.navigate().refresh();
		Thread.sleep(2000);
		List<WebElement> listOfWebelement = driver.findElements(By.xpath("//li[@class='item ng-scope']"));
		String[] elements = new String[listOfWebelement.size()];
		int integer = listOfWebelement.size();
		if (integer == 2) {
			int i = 0;
			for (WebElement e : listOfWebelement) {
				System.out.println(elements[i] = e.getText());
			}
			Assert.assertTrue(true, "Webelements are iteratated and printed in console");
		} else {
			Assert.assertTrue(false, "webelements are not printed in console");
		}
		ScreenShot.getPassedScreenShot(driver, "verifyButton");
		}
		catch (Exception e) {
			ScreenShot.getFailedScreenShot(driver, "verifyButton");
		}
	}

	@Test(priority = 4)
	public void selectedOptionVisibility() throws IOException {
		try{
		driver.navigate().refresh();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement selectedOption = driver.findElement(By.xpath("//a[contains(text(),'Male')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		// selectedOption.click();
		boolean optionSelected = driver.findElement(By.xpath("//a[contains(text(),'Male')]")).isDisplayed();
		if (optionSelected == true) {
			Assert.assertTrue(true, "Male option is displayed");
		} else {
			Assert.assertTrue(false, "No option has been displayed");
		}
		ScreenShot.getPassedScreenShot(driver, "selectedOptionVisibility");
		}
		catch (Exception e) {
			ScreenShot.getFailedScreenShot(driver, "selectedOptionVisibility");
		}
	}

	@Test(priority = 5)
	public void smokeAndTobaccoText() throws IOException {
		try{
		driver.navigate().refresh();
		Thread.sleep(2000);
		WebElement selectedOption = driver.findElement(By.xpath("//a[contains(text(),'Male')]"));
		selectedOption.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean smokeAndTobaccoText = driver
				.findElement(By.xpath("//p[contains(text(),'Got it. Do you smoke or chew tobacco?')]")).isDisplayed();
		if (smokeAndTobaccoText == true) {
			Assert.assertTrue(true, "Question is verified");
		} else {
			Assert.assertTrue(false, "Question is not verified");
		}
		ScreenShot.getPassedScreenShot(driver, "smokeAndTobaccoText");
		}
		catch (Exception e) {
			ScreenShot.getFailedScreenShot(driver, "smokeAndTobaccoText");
		}
	}

	@Test(priority = 6)
	public void verifyYesNoText() throws InterruptedException, IOException {
		try{
		driver.navigate().refresh();
		Thread.sleep(2000);	
		WebElement selectedOption = driver.findElement(By.xpath("//a[contains(text(),'Male')]"));
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		selectedOption.click();
		List<WebElement> allLinks = driver.findElements(By.xpath("//a"));
		String[] links = new String[allLinks.size()];
		int linkSize = allLinks.size();
		if (linkSize == 2) {
			int i = 0;
			for (WebElement e : allLinks) {
				System.out.println(links[i] = e.getText());
			}
			Assert.assertTrue(true, "Yes or No quesition has been verfied and printed in console");
		} else {
			Assert.assertTrue(false, "Yes or not question has not been verfied");
		}
		driver.findElement(By.xpath("//a[contains(text(),'No')]")).click();
		WebElement yearSlider = driver.findElement(By.xpath("//span[@aria-valuenow='1984']"));
		Actions act = new Actions(driver);
		Action action = (Action) act.dragAndDropBy(yearSlider, -10, 0).build();
		action.perform();
		// driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class='btn-round']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean checkDisplayElement = driver
				.findElement(By.xpath("//p[text()='Great. Here is your personalised premium quote: .']")).isDisplayed();
		if (checkDisplayElement == true) {
			Assert.assertTrue(true, "Check message is displayed");
		} else {
			Assert.assertTrue(false, "Element is not displayed");
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement verifyData = driver
				.findElement(By.xpath("//div[@class='chat-bubble no-img clearfix ng-scope'][3]/div"));
		boolean chechedverifyData = verifyData.isDisplayed();
		if (chechedverifyData == true) {
			Assert.assertTrue(true, "Text is displayed and checked");
			System.out.println(verifyData.getText());
		} else {
			Assert.assertFalse(false, "Text is not displayed or verified");
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean nameElement = driver.findElement(By.xpath("//p[text()=' Please share your ']")).isDisplayed();
		if (nameElement == true) {
			Assert.assertTrue(true, "Enter your name is displayed");
		} else {
			Assert.assertFalse(false, "Enter your  name is not displayed");
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here....']")).sendKeys("ABCD");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		boolean enterEmailText = driver
				.findElement(By.xpath("//p[text()='Please enter your email address (in abc@xyz.com format).']"))
				.isDisplayed();
		if (enterEmailText == true) {
			Assert.assertTrue(true, "Enter your email text is displayed");
		} else {
			Assert.assertFalse(false, "Enter your email text is not displayed");
		}
		driver.findElement(By.xpath("//input[@placeholder='Write your text here....']")).sendKeys("dummy@gmail.com");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		WebElement checkbox = driver.findElement(By.xpath("//input[@checked='checked']"));
		if (checkbox.isEnabled() == true) {
			Assert.assertTrue(true, "Checkbox is enabled");
		} else {
			Assert.assertFalse(false, "checkbox is not enabled");
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@placeholder='Write your text here....']")).sendKeys("9999999999");
		driver.findElement(By.xpath("//img[@class='send']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement verifyEelement = driver
				.findElement(By.xpath("//p[text()='To customize your term plan click here: ']"));
		if (verifyEelement.isDisplayed() == true) {
			Assert.assertTrue(true, "Element is present");
		} else {
			Assert.assertFalse(false, "Element is not present");
		}
		WebElement proceedButton = driver.findElement(By.xpath("//a[contains(text(),'Proceed')]"));
		if (proceedButton.isDisplayed() == true) {
			Assert.assertTrue(true, "Message is displayed");
		} else {
			Assert.assertFalse(false, "Message is not displayed");
		}
		proceedButton.click();
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(0));
		driver.switchTo().window(tabs.get(1));
		ScreenShot.getPassedScreenShot(driver, "verifyYesNoText");
		}
		catch (Exception e) {
			ScreenShot.getPassedScreenShot(driver, "verifyYesNoText");
		}
	}

	@AfterClass
	public void postCondition() {
		driver.quit();
	}
}
