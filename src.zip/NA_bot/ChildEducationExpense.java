package NA_bot;

import static org.testng.Assert.assertFalse;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.ScreenshotException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import screenshot.ScreenShot;

public class ChildEducationExpense {
	WebDriver driver;
	String name = "Abcd";

	// PreCondition starts here
	@BeforeClass
	public void PreConditions() throws IOException {
			System.setProperty("webdriver.chrome.driver", "E:\\chatBot\\exeFolder\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.get("https://bot.maxlifeinsurance.com/need-analysis");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	// First TestCase starts here
	@Test
	public void verifyTextEnabled() throws IOException {
		try{
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement verify = driver.findElement(By.xpath("//p[text()=' How much do I need to save?']"));
		boolean xpathDisplayed = verify.isDisplayed();
		if (xpathDisplayed == true) {
			System.out.println(xpathDisplayed);
			Reporter.log("Webelement is Displayed");
		} else {
			Reporter.log("WebElement is not Displayed");
		}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Test
	public void childEducationTabTestScripts() throws IOException, InterruptedException {
		try{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//p[text()=' How much do I need to save?']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[contains(text(),'Proceed') or @class='jss1106']")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		WebElement webelement = driver.findElement(By.xpath("//p[text()=' What is your name?']"));
		boolean verify = webelement.isDisplayed();
		if (verify == true) {
			System.out.println("Proceed button is displayed");
			webelement.click();
			Reporter.log("Proceed butten clicked");
			WebElement verifyElement = driver.findElement(By.xpath("//p[text()=' What is your name?']"));
			driver.findElement(By.xpath("//input[@type='text']")).sendKeys("ABCD");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			boolean check = driver.findElement(By.xpath("//p[contains(text(),' How old are you,')]")).isDisplayed();
			if (check == true) {
				System.out.println("How old are you question has been verified");
			} else {
				System.out.println("webelement is not verifed");
			}
			boolean checkwebelement = driver.findElement(By.xpath("//input[@value='30']")).isDisplayed();
			if (checkwebelement == true) {
				System.out.println("Element is present and verfied");
			} else {

				Reporter.log("Element is not present");
			}
			driver.findElement(By.xpath("//img[@class='send']")).click();
			boolean displayed = driver.findElement(By.xpath("//p[contains(text(),' your mobile number?')]"))
					.isDisplayed();
			if (displayed == true) {
				Reporter.log("Mobile number is present and verfied");
			} else {

				Reporter.log("Mobile number is not verfied");
			}
			driver.findElement(By.xpath("//input[@placeholder='XXXXXXXXXX']")).sendKeys("9999999999");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			boolean childNameWebelement = driver.findElement(By.xpath("//p[contains(text(),' What is your child')]"))
					.isDisplayed();
			if (childNameWebelement == true) {
				Reporter.log("Child's name is displayed and verfied");
			} else {
				Reporter.log("Child's name is not verfied");
			}
			driver.findElement(By.xpath("//input[@placeholder='Write here....']")).sendKeys("name");
			driver.findElement(By.xpath("//img[@class='send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			boolean childNameDisplayed = driver.findElement(By.xpath("//p[contains(text(),' How old is,')]"))
					.isDisplayed();
			if (childNameDisplayed == true) {
				Reporter.log("Child's age is verified");
			} else {
				Reporter.log("Child's age is not verified");
			}
			boolean defaultAge = driver.findElement(By.xpath("//input[@value='14']")).isDisplayed();
			if (defaultAge == true) {
				Reporter.log("Default age is verified");
			} else {
				Reporter.log("Default age in not verfied");
			}
			driver.findElement(By.xpath("//img[@class='send']")).click();
			
			boolean saveElement = driver.findElement(By.xpath("//p[text()=' You want to save for. . .']")).isDisplayed();
			
			WebElement graduationElement = driver.findElement(By.xpath("//span[text()=' Graduation']"));
			if(saveElement==true && graduationElement.isDisplayed()== true)
			{
				Assert.assertTrue(true, "Message is verified");
			}
			else{
				Assert.assertFalse(true, "message is not verified");
			}
			Thread.sleep(2000);
			graduationElement.click();
			WebElement saveLawElement = driver.findElement(By.xpath("//span[text()=' Law']"));
			if(saveLawElement.isDisplayed()==true){
				Assert.assertTrue(true, "Webelement is displayed");
			}
			else{
				assertFalse(true, "Webelement is not displayed");
			}
			saveLawElement.click();
			WebElement countrytext = driver.findElement(By.xpath("//span[text()=' India']"));
			countrytext.click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//button[@type='submit']")).click();
			boolean courseStartAge = driver.findElement(By.xpath("//p[text()='Course Start Age']")).isDisplayed();
			if(courseStartAge==true){
				Assert.assertTrue(true, "webelement is verified");
			}
			else{
				Assert.assertTrue(false, "Webelement is not display");
			}
			driver.findElement(By.xpath("//button[@type='submit']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			boolean amountDisplayed = driver.findElement(By.xpath("//input[@value='100000']")).isDisplayed();
			if(amountDisplayed ==true){
				Assert.assertTrue(true);
			}
			else
			{
				Assert.assertTrue(false);				
			}
			driver.findElement(By.xpath("//button[@type='submit']")).click();
			WebElement inflationRate = driver.findElement(By.xpath("//p[contains(text(),' Inflation rate, which will impact the education cost, should be (8%). Do you want to edit this?')]"));
			if(inflationRate.isDisplayed()==true)
			{
				Assert.assertTrue(true);
			}	
			else
			{
			Assert.assertTrue(false);	
			}
			Thread.sleep(1000);
			driver.findElement(By.xpath("//span[text()='No']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			boolean rateOfReturn = driver.findElement(By.xpath("//p[text()=' Rate of return on your money should be (8%). Do you want to edit this?']")).isDisplayed();
			if(rateOfReturn==true)
			{
				Assert.assertTrue(true);
			}
			else
			{
				Assert.assertTrue(false);
			}
			driver.findElement(By.xpath("//span[text()='No']")).click();
			WebElement riskPerformance = driver.findElement(By.xpath("//p[text()=' What is your risk preference when investing money?']"));
			if(riskPerformance.isDisplayed()==true)
			{
				Assert.assertTrue(true);
			}
			else
			{
				Assert.assertFalse(true);
			}
			WebElement mediumRisk = driver.findElement(By.xpath("//span[text()=' Medium']"));
			if(mediumRisk.isDisplayed()==true)
			{
				Assert.assertTrue(true);
			}
			else
			{
				Assert.assertFalse(false);
			}
			mediumRisk.click();
			WebElement thankYouVerify = driver.findElement(By.xpath("//p[contains(text(),'Thank you ')]"));
			WebElement personalised = driver.findElement(By.xpath("//p[contains(text(),' Here is your personalised financial summary.')]"));
			if(thankYouVerify.isDisplayed()==true && personalised.isDisplayed()==true)
			{
				Assert.assertTrue(true);
			}
			else
			{
				Assert.assertFalse(true);
			}
			List<WebElement> verifyResult = driver.findElements(By.xpath("//div[@class='nameAndMonth']//span"));
			int counts = verifyResult.size();
			String showCounts[] = new String[counts];
			if (counts == 5)
			{
				int i = 0;
				for (WebElement e : verifyResult) {
					System.out.println(showCounts[i] = e.getText());
				}
			}
			else
			{
				Assert.assertTrue(false, "Result count not displayed");
			}
			boolean detailsElement = driver.findElement(By.xpath("//div[text()='Details']")).isDisplayed();
			WebElement seeDetailsElement = driver.findElement(By.xpath("//div[@class='seePlanBtn']"));
			if(detailsElement==true && seeDetailsElement.isDisplayed()==true){
				Assert.assertTrue(true, "Both webelement is verified");
			}
			else{
				Assert.assertFalse(true, "One or both Webelement is not displayed");
			}
			Thread.sleep(1000);
			seeDetailsElement.click();
			List<WebElement> seeDetailsAllElements = driver.findElements(By.xpath("//div[@class='chat bot productdetail']//div//p"));
			int findSize = seeDetailsAllElements.size();
			String storeSeeDetailsAllElements[] =new String[findSize]; 
			if(findSize==5){
				int i=0;
				for(WebElement e: seeDetailsAllElements){
					System.out.println(storeSeeDetailsAllElements[i]= e.getText());
				}
			}
			else{
				Assert.assertTrue(false, "Guranteed income plan has not been verified");
			}
			WebElement knowMoreElement = driver.findElement(By.xpath("//a[text()='Know More']"));
			WebElement getACall = driver.findElement(By.xpath("//p[text()='Get A Call']"));
			if(knowMoreElement.isDisplayed()==true && getACall.isDisplayed()==true){
				Assert.assertTrue(true, "Knonw More and Get A Call webelement is verified");
			}
			else
			{
				Assert.assertTrue(false, "Knonw More and Get A Call webelement is not verified");
			}
			Thread.sleep(2000);
			getACall.click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			WebElement shareEmail = driver.findElement(By.xpath("//p[contains(text(),'Please share your Email id and press send to receive a detailed copy of your financial needs analysis result')]"));
			if(shareEmail.isDisplayed()==true){
				Assert.assertTrue(true, "Webelement is displayed and verified");
			}
			else
			{
			Assert.assertTrue(false, "Webelement is not displayed");	
			}	
			WebElement emailIDElement = driver.findElement(By.xpath("//input[@placeholder='example@gmail.com']"));
			emailIDElement.sendKeys("abcd@gmail.com");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*//p[text()='Send']")).click();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//  boolean thankYouElement = driver.findElement(By.xpath("//div[@class='chat-bubble clearfix']//p[contains(text(),'Thank you ')]")).isDisplayed();
			WebElement startANewJourny = driver.findElement(By.xpath("//span[text()='Start a new journey']"));
			if(startANewJourny.isDisplayed()==true){
				Assert.assertTrue(true, "Element is verified");
			}
			else{
				Assert.assertTrue(false, "Webelement is not verified");
			}
			Thread.sleep(2000);
			startANewJourny.click();
		}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

	@AfterClass
	public void postCondition() {
		driver.quit();
	}
}
