package RA_Bot;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class RABot {

	public WebDriver driver;

	@BeforeClass
	public void PreCondition() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/All exe/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();

	}

	@Test(priority = 1)
	public void RABotAgencyUser_Ankush() throws InterruptedException {

		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=a.agr0349&key3=IOS&key4=eapp");
			Thread.sleep(8000);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendButton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAnkush = driver.findElement(By.xpath("//p[text()='Hi Ankush']"));
			WebElement howCanIHelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAnkush.isDisplayed() == true && howCanIHelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// First KPI- BIG Update starts Here

			nameElement.sendKeys("Renewal Premium");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			// JavascriptExecutor js = (JavascriptExecutor)driver;
			// js.executeScript("arguments[0].click",sendButton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement RenewalPremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (RenewalPremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("Verified for Renewal Premium KPI");
			} else {
				Assert.assertTrue(false);
				System.out.println("Not verified for Renewal Premium KPI");
			}

			// Next KPI's

			nameElement.sendKeys("Premium Due");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumDue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumDue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Collection");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement CollectionWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total collected amount for this month is Rs')]"));
			if (CollectionWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("No of policies NTUed");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NoOfPoliciesNTUedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Policy Pack Delivery Status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PolicyPackDeliveryStatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (PolicyPackDeliveryStatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Medical Category for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MedicalCategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (MedicalCategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Fund Value of the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement FundValueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (FundValueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameElement.sendKeys("ECS date for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ECSdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ECSdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Welcome Calling status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement WelcomeCallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (WelcomeCallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("13M Persistency");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MPersistency = driver.findElement(
					By.xpath("//p[contains(text(),'Your 13M Persistency acheivement is 0% for collected amount Rs')]"));
			if (MPersistency.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Wip cases");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (Wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Applied FYP");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement AppliedFYP = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (AppliedFYP.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Plan Achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PlanAchievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement YTD is :')]"));
			if (PlanAchievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Promotion");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[1]"));
			if (Promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Performance");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Performance = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[2]"));
			if (Performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("GPA");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement GPA = driver.findElement(By.xpath("//p[contains(text(),'Your GPA score is :')]"));
			if (GPA.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Recruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Recruitment count MTD is ')]"));
			if (Recruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment count YTD is ')]"));
			if (QualityRecruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment Plan achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitmentPlanachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment achievement YTD is ')]"));
			if (QualityRecruitmentPlanachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("NAT Done");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NATDone = driver.findElement(By.xpath("//p[contains(text(),'Your NAT count FTD is :0')]"));
			if (NATDone.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Paid Business");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PaidBusiness = driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
			if (PaidBusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception caught");
		}

	}

	@Test(priority = 2)
	public void RABotAgencyUser_Ankit() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=a.sah0173&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendButton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAnkit = driver.findElement(By.xpath("//p[text()='Hi Ankit']"));
			WebElement howCanIHelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAnkit.isDisplayed() == true && howCanIHelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// First KPI- BIG Update starts Here

			nameElement.sendKeys("Renewal Premium");
			sendButton.click();
			// JavascriptExecutor js = (JavascriptExecutor)driver;
			// js.executeScript("arguments[0].click",sendButton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement RenewalPremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (RenewalPremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("Verified for Renewal Premium KPI");
			} else {
				Assert.assertTrue(false);
				System.out.println("Not verified for Renewal Premium KPI");
			}

			// Next KPI's

			nameElement.sendKeys("Premium Due");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumDue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumDue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Collection");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement CollectionWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total collected amount for this month is Rs')]"));
			if (CollectionWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("No of policies NTUed");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NoOfPoliciesNTUedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Policy Pack Delivery Status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PolicyPackDeliveryStatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (PolicyPackDeliveryStatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Medical Category for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MedicalCategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (MedicalCategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Fund Value of the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement FundValueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (FundValueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameElement.sendKeys("ECS date for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ECSdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ECSdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Welcome Calling status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement WelcomeCallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (WelcomeCallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("13M Persistency");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MPersistency = driver.findElement(
					By.xpath("//p[contains(text(),'Your 13M Persistency acheivement is 0% for collected amount Rs')]"));
			if (MPersistency.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Wip cases");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (Wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Applied FYP");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement AppliedFYP = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (AppliedFYP.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Plan Achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PlanAchievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement YTD is :')]"));
			if (PlanAchievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Promotion");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[1]"));
			if (Promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Performance");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Performance = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[2]"));
			if (Performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("GPA");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement GPA = driver.findElement(By.xpath("//p[contains(text(),'Your GPA score is :')]"));
			if (GPA.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Recruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Recruitment count MTD is ')]"));
			if (Recruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment count YTD is ')]"));
			if (QualityRecruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment Plan achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitmentPlanachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment achievement YTD is ')]"));
			if (QualityRecruitmentPlanachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("NAT Done");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NATDone = driver.findElement(By.xpath("//p[contains(text(),'Your NAT count FTD is :0')]"));
			if (NATDone.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Paid Business");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PaidBusiness = driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
			if (PaidBusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception caught");
		}

	}

	@Test(priority = 3)
	public void RABotAgencyUser_Atul() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=aaamb0205&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendButton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAtul = driver.findElement(By.xpath("//p[text()='Hi Atul']"));
			WebElement howCanIHelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAtul.isDisplayed() == true && howCanIHelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// First KPI- BIG Update starts Here

			nameElement.sendKeys("Renewal Premium");
			sendButton.click();
			// JavascriptExecutor js = (JavascriptExecutor)driver;
			// js.executeScript("arguments[0].click",sendButton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement RenewalPremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (RenewalPremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("Verified for Renewal Premium KPI");
			} else {
				Assert.assertTrue(false);
				System.out.println("Not verified for Renewal Premium KPI");
			}

			// Next KPI's

			nameElement.sendKeys("Premium Due");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumDue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumDue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Collection");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement CollectionWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total collected amount for this month is Rs')]"));
			if (CollectionWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("No of policies NTUed");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NoOfPoliciesNTUedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Policy Pack Delivery Status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PolicyPackDeliveryStatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (PolicyPackDeliveryStatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Medical Category for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MedicalCategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (MedicalCategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Fund Value of the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement FundValueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (FundValueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameElement.sendKeys("ECS date for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ECSdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ECSdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Welcome Calling status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement WelcomeCallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (WelcomeCallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("13M Persistency");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MPersistency = driver.findElement(
					By.xpath("//p[contains(text(),'Your 13M Persistency acheivement is 0% for collected amount Rs')]"));
			if (MPersistency.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Wip cases");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (Wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Applied FYP");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement AppliedFYP = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (AppliedFYP.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Plan Achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PlanAchievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement YTD is :')]"));
			if (PlanAchievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Promotion");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[1]"));
			if (Promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Performance");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Performance = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[2]"));
			if (Performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("GPA");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement GPA = driver.findElement(By.xpath("//p[contains(text(),'Your GPA score is :')]"));
			if (GPA.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Recruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Recruitment count MTD is ')]"));
			if (Recruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment count YTD is ')]"));
			if (QualityRecruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment Plan achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitmentPlanachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment achievement YTD is ')]"));
			if (QualityRecruitmentPlanachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("NAT Done");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NATDone = driver.findElement(By.xpath("//p[contains(text(),'Your NAT count FTD is :0')]"));
			if (NATDone.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Paid Business");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PaidBusiness = driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
			if (PaidBusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception caught");
		}
	}

	@Test(priority = 4)
	public void RABotAgencyUser_Ankur() {
		try {
			driver.navigate().to(
					"https://botuat.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=aabul0157&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendButton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAnkur = driver.findElement(By.xpath("//p[text()='Hi Ankur']"));
			WebElement howCanIHelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAnkur.isDisplayed() == true && howCanIHelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// First KPI- BIG Update starts Here

			nameElement.sendKeys("Renewal Premium");
			sendButton.click();
			// JavascriptExecutor js = (JavascriptExecutor)driver;
			// js.executeScript("arguments[0].click",sendButton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement RenewalPremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (RenewalPremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("Verified for Renewal Premium KPI");
			} else {
				Assert.assertTrue(false);
				System.out.println("Not verified for Renewal Premium KPI");
			}

			// Next KPI's

			nameElement.sendKeys("Premium Due");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumDue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumDue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Collection");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement CollectionWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total collected amount for this month is Rs')]"));
			if (CollectionWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("No of policies NTUed");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NoOfPoliciesNTUedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Policy Pack Delivery Status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PolicyPackDeliveryStatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (PolicyPackDeliveryStatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Medical Category for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MedicalCategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (MedicalCategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Fund Value of the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement FundValueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (FundValueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameElement.sendKeys("ECS date for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ECSdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ECSdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Welcome Calling status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement WelcomeCallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (WelcomeCallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("13M Persistency");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MPersistency = driver.findElement(
					By.xpath("//p[contains(text(),'Your 13M Persistency acheivement is 0% for collected amount Rs')]"));
			if (MPersistency.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Wip cases");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (Wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Applied FYP");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement AppliedFYP = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (AppliedFYP.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Plan Achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PlanAchievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement YTD is :')]"));
			if (PlanAchievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Promotion");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[1]"));
			if (Promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Performance");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Performance = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[2]"));
			if (Performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("GPA");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement GPA = driver.findElement(By.xpath("//p[contains(text(),'Your GPA score is :')]"));
			if (GPA.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Recruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Recruitment count MTD is ')]"));
			if (Recruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment count YTD is ')]"));
			if (QualityRecruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment Plan achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitmentPlanachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment achievement YTD is ')]"));
			if (QualityRecruitmentPlanachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("NAT Done");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NATDone = driver.findElement(By.xpath("//p[contains(text(),'Your NAT count FTD is :0')]"));
			if (NATDone.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Paid Business");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PaidBusiness = driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
			if (PaidBusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception caught");
		}

	}

	@Test(priority = 5)
	public void RABotAgencyUser_Amit() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=aadel3194&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendButton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAmit = driver.findElement(By.xpath("//p[text()='Hi Amit']"));
			WebElement howCanIHelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAmit.isDisplayed() == true && howCanIHelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// First KPI- BIG Update starts Here

			nameElement.sendKeys("Renewal Premium");
			sendButton.click();
			// JavascriptExecutor js = (JavascriptExecutor)driver;
			// js.executeScript("arguments[0].click",sendButton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement RenewalPremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (RenewalPremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("Verified for Renewal Premium KPI");
			} else {
				Assert.assertTrue(false);
				System.out.println("Not verified for Renewal Premium KPI");
			}

			// Next KPI's

			nameElement.sendKeys("Premium Due");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumDue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumDue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Collection");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement CollectionWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total collected amount for this month is Rs')]"));
			if (CollectionWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("No of policies NTUed");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NoOfPoliciesNTUedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Policy Pack Delivery Status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PolicyPackDeliveryStatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (PolicyPackDeliveryStatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Medical Category for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MedicalCategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (MedicalCategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Fund Value of the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement FundValueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (FundValueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameElement.sendKeys("ECS date for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ECSdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ECSdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Welcome Calling status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement WelcomeCallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (WelcomeCallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("13M Persistency");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MPersistency = driver.findElement(
					By.xpath("//p[contains(text(),'Your 13M Persistency acheivement is 0% for collected amount Rs')]"));
			if (MPersistency.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Wip cases");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (Wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Applied FYP");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement AppliedFYP = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (AppliedFYP.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Plan Achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PlanAchievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement YTD is :')]"));
			if (PlanAchievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Promotion");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[1]"));
			if (Promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Performance");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Performance = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[2]"));
			if (Performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("GPA");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement GPA = driver.findElement(By.xpath("//p[contains(text(),'Your GPA score is :')]"));
			if (GPA.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Recruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Recruitment count MTD is ')]"));
			if (Recruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment count YTD is ')]"));
			if (QualityRecruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment Plan achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitmentPlanachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment achievement YTD is ')]"));
			if (QualityRecruitmentPlanachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("NAT Done");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NATDone = driver.findElement(By.xpath("//p[contains(text(),'Your NAT count FTD is :0')]"));
			if (NATDone.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Paid Business");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PaidBusiness = driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
			if (PaidBusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception caught");
		}

	}

	@Test(priority = 6)
	public void RABotAgencyUser_Anusha() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=aafccn0529&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendButton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAnusha = driver.findElement(By.xpath("//p[text()='Hi Anusha']"));
			WebElement howCanIHelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAnusha.isDisplayed() == true && howCanIHelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// First KPI- BIG Update starts Here

			nameElement.sendKeys("Renewal Premium");
			sendButton.click();
			// JavascriptExecutor js = (JavascriptExecutor)driver;
			// js.executeScript("arguments[0].click",sendButton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement RenewalPremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (RenewalPremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("Verified for Renewal Premium KPI");
			} else {
				Assert.assertTrue(false);
				System.out.println("Not verified for Renewal Premium KPI");
			}

			// Next KPI's

			nameElement.sendKeys("Premium Due");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumDue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumDue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Collection");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement CollectionWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total collected amount for this month is Rs')]"));
			if (CollectionWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("No of policies NTUed");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NoOfPoliciesNTUedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Policy Pack Delivery Status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PolicyPackDeliveryStatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (PolicyPackDeliveryStatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Medical Category for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MedicalCategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (MedicalCategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Fund Value of the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement FundValueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (FundValueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameElement.sendKeys("ECS date for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ECSdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ECSdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Welcome Calling status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement WelcomeCallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (WelcomeCallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("13M Persistency");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MPersistency = driver.findElement(
					By.xpath("//p[contains(text(),'Your 13M Persistency acheivement is 0% for collected amount Rs')]"));
			if (MPersistency.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Wip cases");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (Wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Applied FYP");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement AppliedFYP = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (AppliedFYP.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Plan Achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PlanAchievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement YTD is :')]"));
			if (PlanAchievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Promotion");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[1]"));
			if (Promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Performance");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Performance = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[2]"));
			if (Performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("GPA");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement GPA = driver.findElement(By.xpath("//p[contains(text(),'Your GPA score is :')]"));
			if (GPA.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Recruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Recruitment count MTD is ')]"));
			if (Recruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment count YTD is ')]"));
			if (QualityRecruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment Plan achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitmentPlanachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment achievement YTD is ')]"));
			if (QualityRecruitmentPlanachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("NAT Done");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NATDone = driver.findElement(By.xpath("//p[contains(text(),'Your NAT count FTD is :0')]"));
			if (NATDone.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Paid Business");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PaidBusiness = driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
			if (PaidBusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception caught");
		}
	}

	@Test(priority = 7)
	public void RABotAgencyUser_Anubhav() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=aahdw0124&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendButton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAnubhav = driver.findElement(By.xpath("//p[text()='Hi Anubhav']"));
			WebElement howCanIHelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAnubhav.isDisplayed() == true && howCanIHelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// First KPI- BIG Update starts Here

			nameElement.sendKeys("Renewal Premium");
			sendButton.click();
			// JavascriptExecutor js = (JavascriptExecutor)driver;
			// js.executeScript("arguments[0].click",sendButton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement RenewalPremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (RenewalPremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("Verified for Renewal Premium KPI");
			} else {
				Assert.assertTrue(false);
				System.out.println("Not verified for Renewal Premium KPI");
			}

			// Next KPI's

			nameElement.sendKeys("Premium Due");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumDue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumDue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Collection");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement CollectionWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total collected amount for this month is Rs')]"));
			if (CollectionWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("No of policies NTUed");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NoOfPoliciesNTUedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Policy Pack Delivery Status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PolicyPackDeliveryStatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (PolicyPackDeliveryStatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Medical Category for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MedicalCategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (MedicalCategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Fund Value of the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement FundValueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (FundValueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameElement.sendKeys("ECS date for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ECSdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ECSdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Welcome Calling status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement WelcomeCallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (WelcomeCallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("13M Persistency");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MPersistency = driver.findElement(
					By.xpath("//p[contains(text(),'Your 13M Persistency acheivement is 0% for collected amount Rs')]"));
			if (MPersistency.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Wip cases");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (Wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Applied FYP");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement AppliedFYP = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (AppliedFYP.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Plan Achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PlanAchievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement YTD is :')]"));
			if (PlanAchievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Promotion");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[1]"));
			if (Promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Performance");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Performance = driver
					.findElement(By.xpath("(//p[contains(text(),'your Quality Recruitment count is')])[2]"));
			if (Performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("GPA");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement GPA = driver.findElement(By.xpath("//p[contains(text(),'Your GPA score is :')]"));
			if (GPA.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Recruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Recruitment count MTD is ')]"));
			if (Recruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitment = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment count YTD is ')]"));
			if (QualityRecruitment.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Quality Recruitment Plan achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement QualityRecruitmentPlanachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Quality Recruitment achievement YTD is ')]"));
			if (QualityRecruitmentPlanachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("NAT Done");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NATDone = driver.findElement(By.xpath("//p[contains(text(),'Your NAT count FTD is :0')]"));
			if (NATDone.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Paid Business");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PaidBusiness = driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
			if (PaidBusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception caught");
		}
	}

	@Test(priority = 8)
	public void RABotAxisuser_Ajjam() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=aaall0225&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameelement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendbutton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiajjam = driver.findElement(By.xpath("//p[text()='Hi Ajjam']"));
			WebElement howcanihelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiajjam.isDisplayed() == true && howcanihelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// first kpi- big update starts here

			nameelement.sendKeys("renewal premium");
			sendbutton.click();
			// javascriptexecutor js = (javascriptexecutor)driver;
			// js.executescript("arguments[0].click",sendbutton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement renewalpremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (renewalpremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("verified for renewal premium kpi");
			} else {
				Assert.assertTrue(false);
				System.out.println("not verified for renewal premium kpi");
			}

			// next kpi's

			nameelement.sendKeys("premium due");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumdue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumdue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("no of policies ntued");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement noofpoliciesntuedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (noofpoliciesntuedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("policy pack delivery status");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement policypackdeliverystatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (policypackdeliverystatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("medical category for the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement medicalcategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (medicalcategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("fund value of the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement fundvalueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (fundvalueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameelement.sendKeys("ecs date for the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ecsdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ecsdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("welcome calling status");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement welcomecallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (welcomecallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("wip cases");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("applied fyp");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement appliedfyp = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (appliedfyp.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("plan achievement");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement planachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement MTD is')]"));
			if (planachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("promotion");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'Your Plan Achievement MTD is')])[1]"));
			if (promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("performance");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement performance = driver
					.findElement(By.xpath("//p[contains(text(),'Your rolling 12 month adj.MFYP is')]"));
			if (performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("promotion shortfall");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement promotionshortfall = driver.findElement(
					By.xpath("//p[contains(text(),'Your shortfall in rolling 12 month adj. MFYP is Rs.')]"));
			if (promotionshortfall.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("paid business");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement paidbusiness = driver
					.findElement(By.xpath("(//p[contains(text(),'Your Total Adj.MFYP is FTD :')])[1]"));
			if (paidbusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("activation");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement activation = driver.findElement(By.xpath("//p[contains(text(),'Activation ')]"));
			if (activation.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("activation plan");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement activationplan = driver.findElement(By.xpath("//p[contains(text(),'Activation Plan is')]"));
			if (activationplan.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception caught");
		}
	}

	@Test(priority = 9)
	public void RABotAxisUser_Atul() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=aabby4331&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameelement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendbutton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAtul = driver.findElement(By.xpath("//p[text()='Hi Atul']"));
			WebElement howcanihelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAtul.isDisplayed() == true && howcanihelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// first kpi- big update starts here

			nameelement.sendKeys("renewal premium");
			sendbutton.click();
			// javascriptexecutor js = (javascriptexecutor)driver;
			// js.executescript("arguments[0].click",sendbutton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement renewalpremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (renewalpremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("verified for renewal premium kpi");
			} else {
				Assert.assertTrue(false);
				System.out.println("not verified for renewal premium kpi");
			}

			// next kpi's

			nameelement.sendKeys("premium due");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumdue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumdue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("no of policies ntued");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement noofpoliciesntuedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (noofpoliciesntuedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("policy pack delivery status");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement policypackdeliverystatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (policypackdeliverystatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("medical category for the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement medicalcategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (medicalcategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("fund value of the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement fundvalueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (fundvalueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameelement.sendKeys("ecs date for the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ecsdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ecsdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("welcome calling status");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement welcomecallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (welcomecallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("wip cases");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("applied fyp");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement appliedfyp = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (appliedfyp.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("plan achievement");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement planachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement MTD is')]"));
			if (planachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("promotion");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'Your Plan Achievement MTD is')])[1]"));
			if (promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("performance");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement performance = driver
					.findElement(By.xpath("//p[contains(text(),'Your rolling 12 month adj.MFYP is')]"));
			if (performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("promotion shortfall");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement promotionshortfall = driver.findElement(
					By.xpath("//p[contains(text(),'Your shortfall in rolling 12 month adj. MFYP is Rs.')]"));
			if (promotionshortfall.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("paid business");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement paidbusiness = driver
					.findElement(By.xpath("(//p[contains(text(),'Your Total Adj.MFYP is FTD :')])[1]"));
			if (paidbusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("activation");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement activation = driver.findElement(By.xpath("//p[contains(text(),'Activation ')]"));
			if (activation.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("activation plan");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement activationplan = driver.findElement(By.xpath("//p[contains(text(),'Activation Plan is')]"));
			if (activationplan.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception caught");
		}
	}

	@Test(priority = 10)
	public void RABotAxisUser_Anil() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=aabpl0365&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameelement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendbutton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAnil = driver.findElement(By.xpath("//p[text()='Hi Anil']"));
			WebElement howcanihelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAnil.isDisplayed() == true && howcanihelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// first kpi- big update starts here

			nameelement.sendKeys("renewal premium");
			sendbutton.click();
			// javascriptexecutor js = (javascriptexecutor)driver;
			// js.executescript("arguments[0].click",sendbutton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement renewalpremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (renewalpremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("verified for renewal premium kpi");
			} else {
				Assert.assertTrue(false);
				System.out.println("not verified for renewal premium kpi");
			}

			// next kpi's

			nameelement.sendKeys("premium due");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumdue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumdue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("no of policies ntued");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement noofpoliciesntuedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (noofpoliciesntuedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("policy pack delivery status");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement policypackdeliverystatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (policypackdeliverystatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("medical category for the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement medicalcategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (medicalcategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("fund value of the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement fundvalueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (fundvalueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameelement.sendKeys("ecs date for the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ecsdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ecsdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("welcome calling status");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement welcomecallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (welcomecallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("wip cases");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("applied fyp");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement appliedfyp = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (appliedfyp.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("plan achievement");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement planachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement MTD is')]"));
			if (planachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("promotion");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'Your Plan Achievement MTD is')])[1]"));
			if (promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("performance");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement performance = driver
					.findElement(By.xpath("//p[contains(text(),'Your rolling 12 month adj.MFYP is')]"));
			if (performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("promotion shortfall");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement promotionshortfall = driver.findElement(
					By.xpath("//p[contains(text(),'Your shortfall in rolling 12 month adj. MFYP is Rs.')]"));
			if (promotionshortfall.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("paid business");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement paidbusiness = driver
					.findElement(By.xpath("(//p[contains(text(),'Your Total Adj.MFYP is FTD :')])[1]"));
			if (paidbusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("activation");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement activation = driver.findElement(By.xpath("//p[contains(text(),'Activation ')]"));
			if (activation.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("activation plan");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement activationplan = driver.findElement(By.xpath("//p[contains(text(),'Activation Plan is')]"));
			if (activationplan.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception caught");
		}
	}

	@Test(priority = 11)
	public void RABotAxisUser_Anurag() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=aabpl0530&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameelement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendbutton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAnurag = driver.findElement(By.xpath("//p[text()='Hi Anurag']"));
			WebElement howcanihelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAnurag.isDisplayed() == true && howcanihelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// first kpi- big update starts here

			nameelement.sendKeys("renewal premium");
			sendbutton.click();
			// javascriptexecutor js = (javascriptexecutor)driver;
			// js.executescript("arguments[0].click",sendbutton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement renewalpremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (renewalpremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("verified for renewal premium kpi");
			} else {
				Assert.assertTrue(false);
				System.out.println("not verified for renewal premium kpi");
			}

			// next kpi's

			nameelement.sendKeys("premium due");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumdue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumdue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("no of policies ntued");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement noofpoliciesntuedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (noofpoliciesntuedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("policy pack delivery status");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement policypackdeliverystatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (policypackdeliverystatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("medical category for the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement medicalcategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (medicalcategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("fund value of the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement fundvalueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (fundvalueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameelement.sendKeys("ecs date for the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ecsdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ecsdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("welcome calling status");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement welcomecallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (welcomecallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("wip cases");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("applied fyp");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement appliedfyp = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (appliedfyp.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("plan achievement");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement planachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement MTD is')]"));
			if (planachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("promotion");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'Your Plan Achievement MTD is')])[1]"));
			if (promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("performance");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement performance = driver
					.findElement(By.xpath("//p[contains(text(),'Your rolling 12 month adj.MFYP is')]"));
			if (performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("promotion shortfall");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement promotionshortfall = driver.findElement(
					By.xpath("//p[contains(text(),'Your shortfall in rolling 12 month adj. MFYP is Rs.')]"));
			if (promotionshortfall.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("paid business");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement paidbusiness = driver
					.findElement(By.xpath("(//p[contains(text(),'Your Total Adj.MFYP is FTD :')])[1]"));
			if (paidbusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("activation");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement activation = driver.findElement(By.xpath("//p[contains(text(),'Activation ')]"));
			if (activation.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("activation plan");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement activationplan = driver.findElement(By.xpath("//p[contains(text(),'Activation Plan is')]"));
			if (activationplan.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception caught");
		}
	}

	@Test(priority = 12)
	public void RABotAxisUser_Abhishek() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=aacha0910&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameelement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendbutton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAbhishek = driver.findElement(By.xpath("//p[text()='Hi Abhishek']"));
			WebElement howcanihelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAbhishek.isDisplayed() == true && howcanihelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// first kpi- big update starts here

			nameelement.sendKeys("renewal premium");
			sendbutton.click();
			// javascriptexecutor js = (javascriptexecutor)driver;
			// js.executescript("arguments[0].click",sendbutton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement renewalpremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (renewalpremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("verified for renewal premium kpi");
			} else {
				Assert.assertTrue(false);
				System.out.println("not verified for renewal premium kpi");
			}

			// next kpi's

			nameelement.sendKeys("premium due");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumdue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumdue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("no of policies ntued");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement noofpoliciesntuedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (noofpoliciesntuedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("policy pack delivery status");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement policypackdeliverystatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (policypackdeliverystatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("medical category for the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement medicalcategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (medicalcategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("fund value of the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement fundvalueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (fundvalueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameelement.sendKeys("ecs date for the policy");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ecsdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ecsdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("welcome calling status");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement welcomecallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (welcomecallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("wip cases");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("applied fyp");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement appliedfyp = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (appliedfyp.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("plan achievement");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement planachievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement MTD is')]"));
			if (planachievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("promotion");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'Your Plan Achievement MTD is')])[1]"));
			if (promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("performance");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement performance = driver
					.findElement(By.xpath("//p[contains(text(),'Your rolling 12 month adj.MFYP is')]"));
			if (performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("promotion shortfall");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement promotionshortfall = driver.findElement(
					By.xpath("//p[contains(text(),'Your shortfall in rolling 12 month adj. MFYP is Rs.')]"));
			if (promotionshortfall.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("paid business");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement paidbusiness = driver
					.findElement(By.xpath("(//p[contains(text(),'Your Total Adj.MFYP is FTD :')])[1]"));
			if (paidbusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("activation");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement activation = driver.findElement(By.xpath("//p[contains(text(),'Activation ')]"));
			if (activation.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameelement.sendKeys("activation plan");
			sendbutton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement activationplan = driver.findElement(By.xpath("//p[contains(text(),'Activation Plan is')]"));
			if (activationplan.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception caught");
		}
	}

	@Test(priority = 13)
	public void RABotCATUser_Aijaz() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=aaind0603&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendButton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAijaz = driver.findElement(By.xpath("//p[text()='Hi Aijaz']"));
			WebElement howCanIHelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAijaz.isDisplayed() == true && howCanIHelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// First KPI- BIG Update starts Here

			nameElement.sendKeys("Renewal Premium");
			sendButton.click();
			// JavascriptExecutor js = (JavascriptExecutor)driver;
			// js.executeScript("arguments[0].click",sendButton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement RenewalPremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (RenewalPremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("Verified for Renewal Premium KPI");
			} else {
				Assert.assertTrue(false);
				System.out.println("Not verified for Renewal Premium KPI");
			}

			// Next KPI's

			nameElement.sendKeys("Premium Due");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumDue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumDue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("12 month rolling Collection");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement monthrollingCollection = driver
					.findElement(By.xpath("//p[contains(text(),'Your total 12 month rolling collected amount is')]"));
			if (monthrollingCollection.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("No of policies NTUed");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NoOfPoliciesNTUedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Policy Pack Delivery Status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PolicyPackDeliveryStatus = driver
					.findElement(By.xpath("//p[contains(text(),'The policy pack for policy')]"));
			if (PolicyPackDeliveryStatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Medical Category for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MedicalCategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (MedicalCategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Fund Value of the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement FundValueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (FundValueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameElement.sendKeys("ECS date for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ECSdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ECSdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Welcome Calling status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement WelcomeCallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (WelcomeCallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Wip cases");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (Wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Applied FYP");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement AppliedFYP = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (AppliedFYP.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Plan Achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PlanAchievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement MTD is')]"));
			if (PlanAchievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Promotion");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'for 6 months cycle Your Weighted MFYP is Rs.')])[1]"));
			if (Promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Performance");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Performance = driver
					.findElement(By.xpath("(//p[contains(text(),'for 6 months cycle Your Weighted MFYP is Rs.')])[2]"));
			if (Performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Paid Business");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PaidBusiness = driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
			if (PaidBusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception caught");
		}
	}

	@Test(priority = 14)
	public void RABotCATUser_Akshad() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=AASOL0233&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendButton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAkshad = driver.findElement(By.xpath("//p[text()='Hi Akshad']"));
			WebElement howCanIHelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAkshad.isDisplayed() == true && howCanIHelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// First KPI- BIG Update starts Here

			nameElement.sendKeys("Renewal Premium");
			sendButton.click();
			// JavascriptExecutor js = (JavascriptExecutor)driver;
			// js.executeScript("arguments[0].click",sendButton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement RenewalPremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (RenewalPremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("Verified for Renewal Premium KPI");
			} else {
				Assert.assertTrue(false);
				System.out.println("Not verified for Renewal Premium KPI");
			}

			// Next KPI's

			nameElement.sendKeys("Premium Due");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumDue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumDue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("12 month rolling Collection");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement monthrollingCollection = driver
					.findElement(By.xpath("//p[contains(text(),'Your total 12 month rolling collected amount is')]"));
			if (monthrollingCollection.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("No of policies NTUed");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NoOfPoliciesNTUedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Policy Pack Delivery Status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PolicyPackDeliveryStatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (PolicyPackDeliveryStatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Medical Category for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MedicalCategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (MedicalCategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Fund Value of the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement FundValueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (FundValueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameElement.sendKeys("ECS date for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ECSdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ECSdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Welcome Calling status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement WelcomeCallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (WelcomeCallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Wip cases");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (Wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Applied FYP");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement AppliedFYP = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (AppliedFYP.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Plan Achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PlanAchievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement MTD is')]"));
			if (PlanAchievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Promotion");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'for 6 months cycle Your Weighted MFYP is Rs')])[1]"));
			if (Promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Performance");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Performance = driver
					.findElement(By.xpath("(//p[contains(text(),'for 6 months cycle Your Weighted MFYP is Rs.')])[2]"));
			if (Performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Paid Business");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PaidBusiness = driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
			if (PaidBusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception caught");
		}
	}

	@Test(priority = 15)
	public void RABotCATUser_Akanksha() {
		try {
			driver.navigate().to(
					"https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=ABBBy6214&key3=IOS&key4=eapp");
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			Thread.sleep(8000);
			WebElement nameElement = driver.findElement(By.xpath("//input[@name='inputText']"));
			WebElement sendButton = driver.findElement(By.xpath("//img[@alt='send_icon']"));
			WebElement hiAkanksha = driver.findElement(By.xpath("//p[text()='Hi Akanksha']"));
			WebElement howCanIHelp = driver.findElement(By.xpath(
					"//p[contains(text(),'Please select Help in case you need detailed information regarding KPIs or keywords you can ask from the bot.')]"));
			if (hiAkanksha.isDisplayed() == true && howCanIHelp.isDisplayed()) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			// First KPI- BIG Update starts Here

			nameElement.sendKeys("Renewal Premium");
			sendButton.click();
			// JavascriptExecutor js = (JavascriptExecutor)driver;
			// js.executeScript("arguments[0].click",sendButton );

			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement RenewalPremium = driver
					.findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A is Rs')]"));
			if (RenewalPremium.isDisplayed() == true) {
				Assert.assertTrue(true);
				System.out.println("Verified for Renewal Premium KPI");
			} else {
				Assert.assertTrue(false);
				System.out.println("Not verified for Renewal Premium KPI");
			}

			// Next KPI's

			nameElement.sendKeys("Premium Due");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement premiumDue = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Premium due in this month is Rs.')]"));
			if (premiumDue.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("12 month rolling Collection");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement monthrollingCollection = driver
					.findElement(By.xpath("//p[contains(text(),'Your total 12 month rolling collected amount is')]"));
			if (monthrollingCollection.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("No of policies NTUed");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement NoOfPoliciesNTUedWebElements = driver
					.findElement(By.xpath("//p[contains(text(),'Your total count of NTU policies is')]"));
			if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Policy Pack Delivery Status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PolicyPackDeliveryStatus = driver.findElement(
					By.xpath("//p[contains(text(),'The policy pack for policy N/A has been delivered on N/A')]"));
			if (PolicyPackDeliveryStatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Medical Category for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement MedicalCategoryforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'Policy N/A falls under N/A')]"));
			if (MedicalCategoryforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Fund Value of the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement FundValueofthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
			if (FundValueofthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}

			nameElement.sendKeys("ECS date for the policy");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement ECSdateforthepolicy = driver
					.findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is N/A')]"));
			if (ECSdateforthepolicy.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Welcome Calling status");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement WelcomeCallingstatus = driver
					.findElement(By.xpath("//p[contains(text(),'The Welcome Calling status for Policy')]"));
			if (WelcomeCallingstatus.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Wip cases");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Wipcases = driver.findElement(By.xpath("//p[contains(text(),'Your current WIP is')]"));
			if (Wipcases.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Applied FYP");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement AppliedFYP = driver
					.findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD :')]"));
			if (AppliedFYP.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Plan Achievement");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PlanAchievement = driver
					.findElement(By.xpath("//p[contains(text(),'Your Plan Achievement MTD is')]"));
			if (PlanAchievement.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Promotion");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Promotion = driver
					.findElement(By.xpath("(//p[contains(text(),'for 6 months cycle Your Weighted MFYP is Rs')])[1]"));
			if (Promotion.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Performance");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement Performance = driver
					.findElement(By.xpath("(//p[contains(text(),'for 6 months cycle Your Weighted MFYP is Rs.')])[2]"));
			if (Performance.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
			nameElement.sendKeys("Paid Business");
			sendButton.click();
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			WebElement PaidBusiness = driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
			if (PaidBusiness.isDisplayed() == true) {
				Assert.assertTrue(true);
			} else {
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception caught");
		}
	}

	// @Test(priority = 16)
	// public void RABotCATUser_Anupam() {
	// try {
	// driver.navigate().to(
	// "https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=adind0622&key3=IOS&key4=eapp");
	// driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	// Thread.sleep(8000);
	// WebElement nameElement =
	// driver.findElement(By.xpath("//input[@name='inputText']"));
	// WebElement sendButton =
	// driver.findElement(By.xpath("//img[@alt='send_icon']"));
	// WebElement hiAnupam = driver.findElement(By.xpath("//p[text()='Hi
	// Akshad']"));
	// WebElement howCanIHelp = driver.findElement(By.xpath(
	// "//p[contains(text(),'Please select Help in case you need detailed
	// information regarding KPIs or keywords you can ask from the bot.')]"));
	// if (hiAnupam.isDisplayed() == true && howCanIHelp.isDisplayed()) {
	// Assert.assertTrue(true);
	// }
	// else {
	// Assert.assertTrue(false);
	// }
	//
	// // First KPI- BIG Update starts Here
	//
	// nameElement.sendKeys("Renewal Premium");
	// sendButton.click();
	// // JavascriptExecutor js = (JavascriptExecutor)driver;
	// // js.executeScript("arguments[0].click",sendButton );
	//
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement RenewalPremium = driver
	// .findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A
	// is Rs')]"));
	// if (RenewalPremium.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// System.out.println("Verified for Renewal Premium KPI");
	// } else {
	// Assert.assertTrue(false);
	// System.out.println("Not verified for Renewal Premium KPI");
	// }
	//
	// // Next KPI's
	//
	// nameElement.sendKeys("Premium Due");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement premiumDue = driver
	// .findElement(By.xpath("//p[contains(text(),'Your total Premium due in
	// this month is Rs.')]"));
	// if (premiumDue.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("12 month rolling Collection");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement monthrollingCollection = driver
	// .findElement(By.xpath("//p[contains(text(),'Your total 12 month rolling
	// collected amount is')]"));
	// if (monthrollingCollection.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("No of policies NTUed");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement NoOfPoliciesNTUedWebElements = driver
	// .findElement(By.xpath("//p[contains(text(),'Your total count of NTU
	// policies is')]"));
	// if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Policy Pack Delivery Status");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement PolicyPackDeliveryStatus = driver.findElement(
	// By.xpath("//p[contains(text(),'The policy pack for policy N/A has been
	// delivered on N/A')]"));
	// if (PolicyPackDeliveryStatus.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Medical Category for the policy");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement MedicalCategoryforthepolicy = driver
	// .findElement(By.xpath("//p[contains(text(),'Policy N/A falls under
	// N/A')]"));
	// if (MedicalCategoryforthepolicy.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Fund Value of the policy");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement FundValueofthepolicy = driver
	// .findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
	// if (FundValueofthepolicy.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	//
	// nameElement.sendKeys("ECS date for the policy");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement ECSdateforthepolicy = driver
	// .findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is
	// N/A')]"));
	// if (ECSdateforthepolicy.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Welcome Calling status");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement WelcomeCallingstatus = driver
	// .findElement(By.xpath("//p[contains(text(),'The Welcome Calling status
	// for Policy')]"));
	// if (WelcomeCallingstatus.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Wip cases");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement Wipcases =
	// driver.findElement(By.xpath("//p[contains(text(),'Your current WIP
	// is')]"));
	// if (Wipcases.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Applied FYP");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement AppliedFYP = driver
	// .findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD
	// :')]"));
	// if (AppliedFYP.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Plan Achievement");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement PlanAchievement = driver
	// .findElement(By.xpath("//p[contains(text(),'Your Plan Achievement MTD
	// is')]"));
	// if (PlanAchievement.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Promotion");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement Promotion = driver
	// .findElement(By.xpath("(//p[contains(text(),'for 6 months cycle Your
	// Weighted MFYP is Rs')])[1]"));
	// if (Promotion.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Performance");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement Performance = driver
	// .findElement(By.xpath("(//p[contains(text(),'for 6 months cycle Your
	// Weighted MFYP is Rs.')])[2]"));
	// if (Performance.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Paid Business");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement PaidBusiness =
	// driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
	// if (PaidBusiness.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// System.out.println("Exception caught");
	// }
	// }
	// @Test(priority = 17)
	// public void RABotCATUser_Anisha() {
	// try {
	// driver.navigate().to(
	// "https://bot.maxlifeinsurance.com/empapp?key1=authorize_eapp_001&key2=afmrt0310&key3=IOS&key4=eapp");
	// driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	// Thread.sleep(8000);
	// WebElement nameElement =
	// driver.findElement(By.xpath("//input[@name='inputText']"));
	// WebElement sendButton =
	// driver.findElement(By.xpath("//img[@alt='send_icon']"));
	// WebElement hiAnisha = driver.findElement(By.xpath("//p[text()='Hi
	// Akshad']"));
	// WebElement howCanIHelp = driver.findElement(By.xpath(
	// "//p[contains(text(),'Please select Help in case you need detailed
	// information regarding KPIs or keywords you can ask from the bot.')]"));
	// if (hiAnisha.isDisplayed() == true && howCanIHelp.isDisplayed()) {
	// Assert.assertTrue(true);
	// }
	// else {
	// Assert.assertTrue(false);
	// }
	//
	// // First KPI- BIG Update starts Here
	//
	// nameElement.sendKeys("Renewal Premium");
	// sendButton.click();
	// // JavascriptExecutor js = (JavascriptExecutor)driver;
	// // js.executeScript("arguments[0].click",sendButton );
	//
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement RenewalPremium = driver
	// .findElement(By.xpath("//p[contains(text(),'The renewal Premium for N/A
	// is Rs')]"));
	// if (RenewalPremium.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// System.out.println("Verified for Renewal Premium KPI");
	// } else {
	// Assert.assertTrue(false);
	// System.out.println("Not verified for Renewal Premium KPI");
	// }
	//
	// // Next KPI's
	//
	// nameElement.sendKeys("Premium Due");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement premiumDue = driver
	// .findElement(By.xpath("//p[contains(text(),'Your total Premium due in
	// this month is Rs.')]"));
	// if (premiumDue.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("12 month rolling Collection");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement monthrollingCollection = driver
	// .findElement(By.xpath("//p[contains(text(),'Your total 12 month rolling
	// collected amount is')]"));
	// if (monthrollingCollection.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("No of policies NTUed");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement NoOfPoliciesNTUedWebElements = driver
	// .findElement(By.xpath("//p[contains(text(),'Your total count of NTU
	// policies is')]"));
	// if (NoOfPoliciesNTUedWebElements.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Policy Pack Delivery Status");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement PolicyPackDeliveryStatus = driver.findElement(
	// By.xpath("//p[contains(text(),'The policy pack for policy N/A has been
	// delivered on N/A')]"));
	// if (PolicyPackDeliveryStatus.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Medical Category for the policy");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement MedicalCategoryforthepolicy = driver
	// .findElement(By.xpath("//p[contains(text(),'Policy N/A falls under
	// N/A')]"));
	// if (MedicalCategoryforthepolicy.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Fund Value of the policy");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement FundValueofthepolicy = driver
	// .findElement(By.xpath("//p[contains(text(),'the fund value against')]"));
	// if (FundValueofthepolicy.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	//
	// nameElement.sendKeys("ECS date for the policy");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement ECSdateforthepolicy = driver
	// .findElement(By.xpath("//p[contains(text(),'The ECS date for N/A is
	// N/A')]"));
	// if (ECSdateforthepolicy.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Welcome Calling status");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement WelcomeCallingstatus = driver
	// .findElement(By.xpath("//p[contains(text(),'The Welcome Calling status
	// for Policy')]"));
	// if (WelcomeCallingstatus.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Wip cases");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement Wipcases =
	// driver.findElement(By.xpath("//p[contains(text(),'Your current WIP
	// is')]"));
	// if (Wipcases.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Applied FYP");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement AppliedFYP = driver
	// .findElement(By.xpath("//p[contains(text(),'Your total Applied FYP is FTD
	// :')]"));
	// if (AppliedFYP.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Plan Achievement");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement PlanAchievement = driver
	// .findElement(By.xpath("//p[contains(text(),'Your Plan Achievement MTD
	// is')]"));
	// if (PlanAchievement.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Promotion");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement Promotion = driver
	// .findElement(By.xpath("(//p[contains(text(),'for 6 months cycle Your
	// Weighted MFYP is Rs')])[1]"));
	// if (Promotion.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Performance");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement Performance = driver
	// .findElement(By.xpath("(//p[contains(text(),'for 6 months cycle Your
	// Weighted MFYP is Rs.')])[2]"));
	// if (Performance.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// nameElement.sendKeys("Paid Business");
	// sendButton.click();
	// driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	// WebElement PaidBusiness =
	// driver.findElement(By.xpath("(//p[@class='botResponse'])[14]"));
	// if (PaidBusiness.isDisplayed() == true) {
	// Assert.assertTrue(true);
	// } else {
	// Assert.assertTrue(false);
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// System.out.println("Exception caught");
	// }
	// }
	@AfterClass
	public void postCondtition() {
		// driver.close();
	}
}
