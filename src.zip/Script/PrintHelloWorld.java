package Script;

import java.util.Timer;

import org.openqa.selenium.WebDriver;

public class PrintHelloWorld {
	public WebDriver driver;
	 public static void main(String[] args) throws InterruptedException 
	 {
		 Integer String=12;
		 System.out.println(String);
		 
		 //RunEverySeconds runEverySecond = new RunEverySeconds();
	        Timer timer = new Timer();
	        timer.schedule(new RunEverySeconds(), 0,1000);
	 }

}
